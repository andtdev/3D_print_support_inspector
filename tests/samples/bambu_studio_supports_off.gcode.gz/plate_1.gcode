; HEADER_BLOCK_START
; BambuStudio 02.08.02.61
; model printing time: 31m 57s; total estimated time: 31m 58s
; total layer number: 70
; total filament length [mm] : 1272.04
; total filament volume [cm^3] : 3059.62
; total filament weight [g] : 0.00
; filament_density: 0
; filament_diameter: 1.75
; max_z_height: 14.00
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 0
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = zig-zag
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 25
; brim_object_gap = 0
; brim_type = auto_brim
; brim_width = 0
; chamber_temperatures = 0
; change_filament_gcode = 
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; complete_print_exhaust_fan_speed = 80
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.025
; counter_coef_3 = -0.11
; counter_limit_max = 0.05
; counter_limit_min = -0.04
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 6000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL A1"
; default_jerk = 0
; default_print_profile = 0.20mm Standard @BBL A1
; deretraction_speed = 0
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 60
; elefant_foot_compensation = 0.075
; embedding_wall_into_infill = 0
; enable_arc_fitting = 0
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 0
; enable_support = 0
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 45
; eng_plate_temp_initial_layer = 45
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 56.5
; extruder_clearance_height_to_lid = 256
; extruder_clearance_height_to_rod = 25
; extruder_clearance_max_radius = 73
; extruder_colour = ""
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_printable_height = 0
; extruder_type = Direct Drive
; fan_cooling_layer_time = 80
; fan_direction = undefine
; fan_max_speed = 80
; fan_min_speed = 60
; farthest_point_timelapse = 0
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 0
; filament_bridge_speed = 25
; filament_change_length = 10
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 10
; filament_cost = 0
; filament_density = 0
; filament_dev_ams_drying_ams_limitations = ""
; filament_dev_ams_drying_heat_distortion_temperature = 0
; filament_dev_ams_drying_temperature = 0
; filament_dev_ams_drying_time = 0
; filament_dev_chamber_drying_bed_temperature = 0
; filament_dev_chamber_drying_time = 0
; filament_dev_drying_cooling_temperature = 0
; filament_dev_drying_softening_temperature = 0
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = " "
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 1
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = ""
; filament_is_mixed = 0
; filament_is_support = 0
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 2
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 0
; filament_overhang_3_4_speed = 0
; filament_overhang_4_4_speed = 0
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 0
; filament_prime_volume = 45
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 10
; filament_scarf_gap = 0
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Generic PLA @BBL A1"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = " "
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = (Undefined)
; filament_volume_map = 0
; filename_format = [input_filename_base].gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 30
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 17.4
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 226x224,256x224,256x256,226x256
; hole_coef_1 = 0
; hole_coef_2 = -0.025
; hole_coef_3 = 0.28
; hole_limit_max = 0.25
; hole_limit_min = 0.08
; hot_plate_temp = 65
; hot_plate_temp_initial_layer = 65
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 0
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 300
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 60
; initial_layer_jerk = 9
; initial_layer_line_width = 0.4
; initial_layer_print_height = 0.2
; initial_layer_speed = 30
; initial_layer_travel_acceleration = 500
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.4
; inner_wall_speed = 60
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0
; internal_solid_infill_line_width = 0.4
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 100
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0
; ironing_pattern = zig-zag
; ironing_spacing = 0.1
; ironing_speed = 20
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = 
; layer_height = 0.2
; line_width = 0.4
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = M104 S0 ; turn off temperature\nG28 X0  ; home X axis\nM84     ; disable motors\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 25
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 12000,12000
; machine_max_acceleration_retracting = 1500,1250
; machine_max_acceleration_travel = 1500,1250
; machine_max_acceleration_x = 6000,6000
; machine_max_acceleration_y = 6000,6000
; machine_max_acceleration_z = 1500,1500
; machine_max_force_Y = 0
; machine_max_jerk_e = 3,3
; machine_max_jerk_x = 10,10
; machine_max_jerk_y = 10,10
; machine_max_jerk_z = 0.2,0.4
; machine_max_printed_mass = 0
; machine_max_speed_e = 120,120
; machine_max_speed_x = 500,200
; machine_max_speed_y = 500,200
; machine_max_speed_z = 30,30
; machine_min_extruding_rate = 0,0
; machine_min_travel_rate = 0,0
; machine_pause_gcode = 
; machine_prepare_compensation_time = 260
; machine_start_gcode = G28 ; home all axes\nG1 Z5 F5000 ; lift nozzle\n
; machine_switch_extruder_time = 5
; machine_unload_filament_time = 0
; master_extruder_id = 1
; max_bridge_length = 10
; max_layer_height = 0
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.07
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.76
; nozzle_temperature = 200
; nozzle_temperature_initial_layer = 200
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = stainless_steel
; nozzle_volume = 92
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 500
; outer_wall_jerk = 9
; outer_wall_line_width = 0
; outer_wall_speed = 60
; overhang_1_4_speed = 0
; overhang_2_4_speed = 0
; overhang_3_4_speed = 0
; overhang_4_4_speed = 0
; overhang_fan_speed = 100
; overhang_fan_threshold = 95%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab A1 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = 0.20mm Standard @BBL A1
; printable_area = 0x0,200x0,200x200,0x200
; printable_height = 256
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab A1
; printer_notes = 
; printer_settings_id = Bambu Lab A1 0.4 nozzle
; printer_structure = i3
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 0
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 0
; resolution = 0.01
; retract_before_wipe = 100%
; retract_length_toolchange = 10
; retract_lift_above = 0
; retract_lift_below = 255
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 0
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 10
; retraction_length = 0.8
; retraction_minimum_travel = 2
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 0
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.4
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.4
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 1
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 5
; slow_down_min_speed = 10
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 80
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 20%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.4
; sparse_infill_pattern = cubic
; sparse_infill_speed = 100
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 35
; supertack_plate_temp_initial_layer = 35
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 0
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 3
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.1
; support_ironing_speed = 20
; support_line_width = 0.4
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 0
; support_remove_small_overhang = 1
; support_speed = 80
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = normal(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 100
; template_custom_gcode = 
; textured_plate_temp = 65
; textured_plate_temp_initial_layer = 65
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = 
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 4
; top_one_wall_type = all top
; top_shell_layers = 4
; top_shell_thickness = 0.6
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 500
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.4
; top_surface_pattern = zig-zag
; top_surface_speed = 100
; top_z_overrides_xy_distance = 0
; travel_acceleration = 500
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 700
; travel_speed_z = 0
; tree_support_branch_angle = 40
; tree_support_branch_diameter = 5
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = ""
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = arachne
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 0
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Spiral Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R31
M201 X6000 Y6000 Z1500 E5000
M203 X500 Y500 Z30 E120
M204 P12000 R1500 T12000
M205 X10.00 Y10.00 Z0.20 E3.00
M106 S0
M190 S35 ; set bed temperature and wait for it to be reached
M104 S200 ; set nozzle temperature
; FEATURE: Custom
G28 ; home all axes
G1 Z5 F5000 ; lift nozzle
; MACHINE_START_GCODE_END
;VT0 H-1
M109 S200 ; set nozzle temperature and wait for it to be reached
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
M106 S0
G1 E-.8 F1800
G1 X76.212 Y89.755 F42000
M204 S500
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Skirt
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S300
G1 X77.245 Y88.957 E.03874
G1 X78 Y88.821 E.02279
G1 X122 Y88.821 E1.30642
G1 X123.245 Y89.212 E.03875
G1 X124.043 Y90.245 E.03874
G1 X124.179 Y91 E.02279
G1 X124.179 Y109 E.53444
G1 X123.788 Y110.245 E.03875
G1 X122.755 Y111.043 E.03874
G1 X122 Y111.179 E.02279
G1 X78 Y111.179 E1.30642
G1 X76.755 Y110.788 E.03875
G1 X75.957 Y109.755 E.03874
G1 X75.821 Y109 E.02279
G1 X75.821 Y91 E.53444
G1 X76.194 Y89.812 E.03696
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.462 J1.126 P1  F42000
G1 X121.368 Y108.368 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S300
G1 X78.632 Y108.368 E1.26885
G1 X78.632 Y91.632 E.4969
G1 X121.368 Y91.632 E1.26885
G1 X121.368 Y100 E.24845
G1 X121.368 Y108.308 E.24667
M204 S500
G1 X121.725 Y108.725 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S300
G1 X78.275 Y108.725 E1.29005
G1 X78.275 Y91.275 E.5181
G1 X121.725 Y91.275 E1.29005
G1 X121.725 Y100 E.25905
G1 X121.725 Y108.665 E.25727
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I1.217 J0 P1  F42000
G1 X121.225 Y92.502
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.40239
G1 F1669.124
M204 S300
G1 X120.659 Y91.936 E.02394
G1 X120.151 Y91.936 E.0152
G1 X121.064 Y92.85 E.03863
G1 X121.064 Y93.358 E.01519
G1 X119.642 Y91.936 E.06012
G1 X119.134 Y91.936 E.01519
G1 X121.064 Y93.866 E.08161
G1 X121.064 Y94.375 E.0152
G1 X118.625 Y91.936 E.1031
G1 X118.117 Y91.936 E.0152
G1 X121.064 Y94.883 E.12459
G1 X121.064 Y95.391 E.01519
G1 X117.609 Y91.936 E.14608
G1 X117.1 Y91.936 E.01519
G1 X121.064 Y95.9 E.16757
G1 X121.064 Y96.408 E.0152
G1 X116.592 Y91.936 E.18906
G1 X116.084 Y91.936 E.0152
G1 X121.064 Y96.916 E.21055
G1 X121.064 Y97.425 E.0152
G1 X115.575 Y91.936 E.23203
G1 X115.067 Y91.936 E.01519
G1 X121.064 Y97.933 E.25352
G1 X121.064 Y98.442 E.0152
G1 X114.558 Y91.936 E.27501
G1 X114.05 Y91.936 E.0152
M73 P1 R31
G1 X121.064 Y98.95 E.2965
G1 X121.064 Y99.458 E.0152
G1 X113.542 Y91.936 E.31799
G1 X113.033 Y91.936 E.0152
G1 X121.064 Y99.967 E.33948
G1 X121.064 Y100.475 E.0152
G1 X112.525 Y91.936 E.36097
G1 X112.017 Y91.936 E.0152
G1 X121.064 Y100.983 E.38246
G1 X121.064 Y101.492 E.0152
G1 X111.508 Y91.936 E.40395
G1 X111 Y91.936 E.0152
G1 X121.064 Y102 E.42544
G1 X121.064 Y102.508 E.0152
G1 X110.492 Y91.936 E.44693
G1 X109.983 Y91.936 E.0152
G1 X121.064 Y103.017 E.46842
G1 X121.064 Y103.525 E.0152
G1 X109.475 Y91.936 E.4899
G1 X108.966 Y91.936 E.0152
G1 X121.064 Y104.034 E.51139
G1 X121.064 Y104.542 E.01519
G1 X108.458 Y91.936 E.53288
G1 X107.95 Y91.936 E.0152
G1 X121.064 Y105.05 E.55437
G1 X121.064 Y105.559 E.0152
G1 X107.441 Y91.936 E.57586
G1 X106.933 Y91.936 E.0152
G1 X121.064 Y106.067 E.59735
G1 X121.064 Y106.575 E.01519
G1 X106.425 Y91.936 E.61884
G1 X105.916 Y91.936 E.01519
G1 X121.064 Y107.084 E.64033
G1 X121.064 Y107.592 E.0152
G1 X105.408 Y91.936 E.66182
G1 X104.899 Y91.936 E.0152
G1 X121.028 Y108.064 E.68178
G1 X120.52 Y108.064 E.0152
G1 X104.391 Y91.936 E.68178
G1 X103.883 Y91.936 E.01519
G1 X120.012 Y108.064 E.68178
G1 X119.503 Y108.064 E.0152
G1 X103.374 Y91.936 E.68178
G1 X102.866 Y91.936 E.0152
G1 X118.995 Y108.064 E.68178
G1 X118.487 Y108.064 E.0152
G1 X102.358 Y91.936 E.68178
G1 X101.849 Y91.936 E.01519
G1 X117.978 Y108.064 E.68178
G1 X117.47 Y108.064 E.0152
G1 X101.341 Y91.936 E.68178
G1 X100.833 Y91.936 E.0152
G1 X116.961 Y108.064 E.68178
G1 X116.453 Y108.064 E.0152
M73 P2 R31
G1 X100.324 Y91.936 E.68178
G1 X99.816 Y91.936 E.01519
G1 X115.945 Y108.064 E.68178
G1 X115.436 Y108.064 E.0152
G1 X99.307 Y91.936 E.68178
G1 X98.799 Y91.936 E.0152
G1 X114.928 Y108.064 E.68178
G1 X114.42 Y108.064 E.0152
G1 X98.291 Y91.936 E.68178
G1 X97.782 Y91.936 E.01519
G1 X113.911 Y108.064 E.68178
G1 X113.403 Y108.064 E.0152
G1 X97.274 Y91.936 E.68178
G1 X96.766 Y91.936 E.0152
G1 X112.894 Y108.064 E.68178
G1 X112.386 Y108.064 E.0152
G1 X96.257 Y91.936 E.68178
G1 X95.749 Y91.936 E.0152
G1 X111.878 Y108.064 E.68178
G1 X111.369 Y108.064 E.0152
G1 X95.241 Y91.936 E.68178
G1 X94.732 Y91.936 E.0152
G1 X110.861 Y108.064 E.68178
G1 X110.353 Y108.064 E.01519
G1 X94.224 Y91.936 E.68178
G1 X93.715 Y91.936 E.0152
G1 X109.844 Y108.064 E.68178
G1 X109.336 Y108.064 E.0152
G1 X93.207 Y91.936 E.68178
G1 X92.699 Y91.936 E.0152
G1 X108.828 Y108.064 E.68178
G1 X108.319 Y108.064 E.01519
G1 X92.19 Y91.936 E.68178
G1 X91.682 Y91.936 E.0152
G1 X107.811 Y108.064 E.68178
G1 X107.302 Y108.064 E.0152
G1 X91.174 Y91.936 E.68178
G1 X90.665 Y91.936 E.0152
G1 X106.794 Y108.064 E.68178
G1 X106.286 Y108.064 E.01519
G1 X90.157 Y91.936 E.68178
G1 X89.648 Y91.936 E.0152
G1 X105.777 Y108.064 E.68178
G1 X105.269 Y108.064 E.0152
M73 P3 R31
G1 X89.14 Y91.936 E.68178
G1 X88.632 Y91.936 E.01519
M73 P3 R30
G1 X104.761 Y108.064 E.68178
G1 X104.252 Y108.064 E.01519
G1 X88.123 Y91.936 E.68178
G1 X87.615 Y91.936 E.0152
G1 X103.744 Y108.064 E.68178
G1 X103.236 Y108.064 E.0152
G1 X87.107 Y91.936 E.68178
G1 X86.598 Y91.936 E.01519
G1 X102.727 Y108.064 E.68178
G1 X102.219 Y108.064 E.0152
G1 X86.09 Y91.936 E.68178
G1 X85.582 Y91.936 E.0152
G1 X101.71 Y108.064 E.68178
G1 X101.202 Y108.064 E.0152
G1 X85.073 Y91.936 E.68178
G1 X84.565 Y91.936 E.01519
G1 X100.694 Y108.064 E.68178
G1 X100.185 Y108.064 E.0152
G1 X84.056 Y91.936 E.68178
G1 X83.548 Y91.936 E.0152
G1 X99.677 Y108.064 E.68178
G1 X99.169 Y108.064 E.0152
G1 X83.04 Y91.936 E.68178
G1 X82.531 Y91.936 E.01519
G1 X98.66 Y108.064 E.68178
G1 X98.152 Y108.064 E.0152
G1 X82.023 Y91.936 E.68178
G1 X81.515 Y91.936 E.0152
G1 X97.643 Y108.064 E.68178
G1 X97.135 Y108.064 E.0152
G1 X81.006 Y91.936 E.68178
G1 X80.498 Y91.936 E.0152
G1 X96.627 Y108.064 E.68178
G1 X96.118 Y108.064 E.0152
G1 X79.989 Y91.936 E.68178
G1 X79.481 Y91.936 E.0152
G1 X95.61 Y108.064 E.68178
G1 X95.102 Y108.064 E.01519
G1 X78.973 Y91.936 E.68178
G1 X78.936 Y91.936 E.00111
M73 P4 R30
G1 X78.936 Y92.407 E.01408
G1 X94.593 Y108.064 E.66187
G1 X94.085 Y108.064 E.0152
G1 X78.936 Y92.915 E.64038
G1 X78.936 Y93.423 E.0152
G1 X93.577 Y108.064 E.61889
G1 X93.068 Y108.064 E.01519
G1 X78.936 Y93.932 E.5974
G1 X78.936 Y94.44 E.01519
G1 X92.56 Y108.064 E.57591
G1 X92.051 Y108.064 E.0152
G1 X78.936 Y94.949 E.55442
G1 X78.936 Y95.457 E.0152
G1 X91.543 Y108.064 E.53293
G1 X91.035 Y108.064 E.01519
G1 X78.936 Y95.965 E.51144
G1 X78.936 Y96.474 E.01519
G1 X90.526 Y108.064 E.48995
G1 X90.018 Y108.064 E.0152
G1 X78.936 Y96.982 E.46846
G1 X78.936 Y97.49 E.0152
G1 X89.51 Y108.064 E.44697
G1 X89.001 Y108.064 E.01519
G1 X78.936 Y97.999 E.42549
G1 X78.936 Y98.507 E.0152
G1 X88.493 Y108.064 E.404
G1 X87.984 Y108.064 E.0152
G1 X78.936 Y99.016 E.38251
G1 X78.936 Y99.524 E.0152
G1 X87.476 Y108.064 E.36102
G1 X86.968 Y108.064 E.01519
G1 X78.936 Y100.032 E.33953
G1 X78.936 Y100.541 E.0152
G1 X86.459 Y108.064 E.31804
G1 X85.951 Y108.064 E.0152
G1 X78.936 Y101.049 E.29655
G1 X78.936 Y101.557 E.0152
G1 X85.443 Y108.064 E.27506
G1 X84.934 Y108.064 E.0152
G1 X78.936 Y102.066 E.25357
G1 X78.936 Y102.574 E.0152
G1 X84.426 Y108.064 E.23208
G1 X83.918 Y108.064 E.0152
G1 X78.936 Y103.082 E.21059
G1 X78.936 Y103.591 E.0152
G1 X83.409 Y108.064 E.1891
G1 X82.901 Y108.064 E.0152
G1 X78.936 Y104.099 E.16762
G1 X78.936 Y104.608 E.0152
G1 X82.392 Y108.064 E.14613
G1 X81.884 Y108.064 E.0152
G1 X78.936 Y105.116 E.12464
G1 X78.936 Y105.624 E.01519
G1 X81.376 Y108.064 E.10315
G1 X80.867 Y108.064 E.0152
G1 X78.936 Y106.133 E.08166
G1 X78.936 Y106.641 E.0152
G1 X80.359 Y108.064 E.06017
G1 X79.851 Y108.064 E.0152
G1 X78.936 Y107.149 E.03868
G1 X78.936 Y107.658 E.01519
G1 X79.503 Y108.225 E.02398
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
M106 S153
; open powerlost recovery
M1003 S1
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.006 J1.217 P1  F42000
G1 X121.443 Y108.443 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
M73 P5 R30
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z.8 I1.217 J0 P1  F42000
G1 X120.576 Y108.3
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40113
G1 F1674.995
M204 S6000
G1 X121.139 Y107.737 E.02374
G1 X121.139 Y107.23 E.01509
G1 X120.23 Y108.139 E.03831
G1 X119.723 Y108.139 E.01509
G1 X121.139 Y106.723 E.05965
G1 X121.139 Y106.217 E.01509
G1 X119.217 Y108.139 E.08099
G1 X118.71 Y108.139 E.01509
G1 X121.139 Y105.71 E.10233
G1 X121.139 Y105.204 E.01509
G1 X118.204 Y108.139 E.12366
G1 X117.697 Y108.139 E.01509
G1 X121.139 Y104.697 E.145
G1 X121.139 Y104.19 E.01509
G1 X117.19 Y108.139 E.16634
G1 X116.684 Y108.139 E.01509
G1 X121.139 Y103.684 E.18768
G1 X121.139 Y103.177 E.01509
G1 X116.177 Y108.139 E.20902
G1 X115.671 Y108.139 E.01509
G1 X121.139 Y102.671 E.23036
G1 X121.139 Y102.164 E.01509
G1 X115.164 Y108.139 E.2517
G1 X114.658 Y108.139 E.01509
G1 X121.139 Y101.658 E.27304
G1 X121.139 Y101.151 E.01509
G1 X114.151 Y108.139 E.29437
G1 X113.644 Y108.139 E.01509
G1 X121.139 Y100.644 E.31571
G1 X121.139 Y100.138 E.01509
G1 X113.138 Y108.139 E.33705
G1 X112.631 Y108.139 E.01509
G1 X121.139 Y99.631 E.35839
G1 X121.139 Y99.125 E.01509
G1 X112.125 Y108.139 E.37973
G1 X111.618 Y108.139 E.01509
G1 X121.139 Y98.618 E.40107
G1 X121.139 Y98.111 E.01509
G1 X111.111 Y108.139 E.42241
G1 X110.605 Y108.139 E.01509
G1 X121.139 Y97.605 E.44375
G1 X121.139 Y97.098 E.01509
G1 X110.098 Y108.139 E.46508
G1 X109.592 Y108.139 E.01509
G1 X121.139 Y96.592 E.48642
G1 X121.139 Y96.085 E.01509
G1 X109.085 Y108.139 E.50776
G1 X108.578 Y108.139 E.01509
G1 X121.139 Y95.579 E.5291
G1 X121.139 Y95.072 E.01509
G1 X108.072 Y108.139 E.55044
G1 X107.565 Y108.139 E.01509
G1 X121.139 Y94.565 E.57178
G1 X121.139 Y94.059 E.01509
G1 X107.059 Y108.139 E.59312
G1 X106.552 Y108.139 E.01509
G1 X121.139 Y93.552 E.61446
G1 X121.139 Y93.046 E.01509
G1 X106.046 Y108.139 E.63579
G1 X105.539 Y108.139 E.01509
G1 X121.139 Y92.539 E.65713
G1 X121.139 Y92.032 E.01509
G1 X105.032 Y108.139 E.67847
G1 X104.526 Y108.139 E.01509
M73 P6 R30
G1 X120.805 Y91.861 E.68571
G1 X120.298 Y91.861 E.01509
G1 X104.019 Y108.139 E.68571
G1 X103.513 Y108.139 E.01509
G1 X119.792 Y91.861 E.68571
G1 X119.285 Y91.861 E.01509
G1 X103.006 Y108.139 E.68571
G1 X102.499 Y108.139 E.01509
M73 P6 R29
G1 X118.778 Y91.861 E.68571
G1 X118.272 Y91.861 E.01509
G1 X101.993 Y108.139 E.68571
G1 X101.486 Y108.139 E.01509
G1 X117.765 Y91.861 E.68571
G1 X117.259 Y91.861 E.01509
G1 X100.98 Y108.139 E.68571
G1 X100.473 Y108.139 E.01509
G1 X116.752 Y91.861 E.68571
G1 X116.245 Y91.861 E.01509
G1 X99.967 Y108.139 E.68571
G1 X99.46 Y108.139 E.01509
G1 X115.739 Y91.861 E.68571
G1 X115.232 Y91.861 E.01509
G1 X98.953 Y108.139 E.68571
G1 X98.447 Y108.139 E.01509
G1 X114.726 Y91.861 E.68571
G1 X114.219 Y91.861 E.01509
G1 X97.94 Y108.139 E.68571
G1 X97.434 Y108.139 E.01509
G1 X113.713 Y91.861 E.68571
G1 X113.206 Y91.861 E.01509
G1 X96.927 Y108.139 E.68571
G1 X96.42 Y108.139 E.01509
G1 X112.699 Y91.861 E.68571
G1 X112.193 Y91.861 E.01509
G1 X95.914 Y108.139 E.68571
G1 X95.407 Y108.139 E.01509
G1 X111.686 Y91.861 E.68571
G1 X111.18 Y91.861 E.01509
G1 X94.901 Y108.139 E.68571
G1 X94.394 Y108.139 E.01509
G1 X110.673 Y91.861 E.68571
G1 X110.166 Y91.861 E.01509
G1 X93.888 Y108.139 E.68571
G1 X93.381 Y108.139 E.01509
M73 P7 R29
G1 X109.66 Y91.861 E.68571
G1 X109.153 Y91.861 E.01509
G1 X92.874 Y108.139 E.68571
G1 X92.368 Y108.139 E.01509
G1 X108.647 Y91.861 E.68571
G1 X108.14 Y91.861 E.01509
G1 X91.861 Y108.139 E.68571
G1 X91.355 Y108.139 E.01509
G1 X107.633 Y91.861 E.68571
G1 X107.127 Y91.861 E.01509
G1 X90.848 Y108.139 E.68571
G1 X90.341 Y108.139 E.01509
G1 X106.62 Y91.861 E.68571
G1 X106.114 Y91.861 E.01509
G1 X89.835 Y108.139 E.68571
G1 X89.328 Y108.139 E.01509
G1 X105.607 Y91.861 E.68571
G1 X105.101 Y91.861 E.01509
G1 X88.822 Y108.139 E.68571
G1 X88.315 Y108.139 E.01509
G1 X104.594 Y91.861 E.68571
G1 X104.087 Y91.861 E.01509
G1 X87.808 Y108.139 E.68571
G1 X87.302 Y108.139 E.01509
G1 X103.581 Y91.861 E.68571
G1 X103.074 Y91.861 E.01509
G1 X86.795 Y108.139 E.68571
G1 X86.289 Y108.139 E.01509
G1 X102.568 Y91.861 E.68571
G1 X102.061 Y91.861 E.01509
G1 X85.782 Y108.139 E.68571
G1 X85.276 Y108.139 E.01509
G1 X101.554 Y91.861 E.68571
G1 X101.048 Y91.861 E.01509
G1 X84.769 Y108.139 E.68571
G1 X84.262 Y108.139 E.01509
G1 X100.541 Y91.861 E.68571
G1 X100.035 Y91.861 E.01509
G1 X83.756 Y108.139 E.68571
G1 X83.249 Y108.139 E.01509
G1 X99.528 Y91.861 E.68571
G1 X99.022 Y91.861 E.01509
G1 X82.743 Y108.139 E.68571
G1 X82.236 Y108.139 E.01509
G1 X98.515 Y91.861 E.68571
G1 X98.008 Y91.861 E.01509
M73 P8 R29
G1 X81.729 Y108.139 E.68571
G1 X81.223 Y108.139 E.01509
G1 X97.502 Y91.861 E.68571
G1 X96.995 Y91.861 E.01509
G1 X80.716 Y108.139 E.68571
G1 X80.21 Y108.139 E.01509
G1 X96.489 Y91.861 E.68571
G1 X95.982 Y91.861 E.01509
G1 X79.703 Y108.139 E.68571
G1 X79.197 Y108.139 E.01509
G1 X95.475 Y91.861 E.68571
G1 X94.969 Y91.861 E.01509
G1 X78.861 Y107.969 E.67853
G1 X78.861 Y107.462 E.01509
G1 X94.462 Y91.861 E.65719
G1 X93.956 Y91.861 E.01509
G1 X78.861 Y106.956 E.63585
G1 X78.861 Y106.449 E.01509
G1 X93.449 Y91.861 E.61451
G1 X92.942 Y91.861 E.01509
G1 X78.861 Y105.943 E.59317
G1 X78.861 Y105.436 E.01509
G1 X92.436 Y91.861 E.57183
G1 X91.929 Y91.861 E.01509
G1 X78.861 Y104.929 E.55049
G1 X78.861 Y104.423 E.01509
G1 X91.423 Y91.861 E.52915
G1 X90.916 Y91.861 E.01509
G1 X78.861 Y103.916 E.50782
G1 X78.861 Y103.41 E.01509
G1 X90.41 Y91.861 E.48648
G1 X89.903 Y91.861 E.01509
G1 X78.861 Y102.903 E.46514
G1 X78.861 Y102.396 E.01509
G1 X89.396 Y91.861 E.4438
G1 X88.89 Y91.861 E.01509
G1 X78.861 Y101.89 E.42246
G1 X78.861 Y101.383 E.01509
G1 X88.383 Y91.861 E.40112
G1 X87.877 Y91.861 E.01509
G1 X78.861 Y100.877 E.37978
G1 X78.861 Y100.37 E.01509
G1 X87.37 Y91.861 E.35844
G1 X86.863 Y91.861 E.01509
G1 X78.861 Y99.863 E.33711
G1 X78.861 Y99.357 E.01509
G1 X86.357 Y91.861 E.31577
G1 X85.85 Y91.861 E.01509
G1 X78.861 Y98.85 E.29443
G1 X78.861 Y98.344 E.01509
G1 X85.344 Y91.861 E.27309
G1 X84.837 Y91.861 E.01509
G1 X78.861 Y97.837 E.25175
G1 X78.861 Y97.331 E.01509
G1 X84.331 Y91.861 E.23041
G1 X83.824 Y91.861 E.01509
G1 X78.861 Y96.824 E.20907
G1 X78.861 Y96.317 E.01509
G1 X83.317 Y91.861 E.18773
G1 X82.811 Y91.861 E.01509
G1 X78.861 Y95.811 E.16639
G1 X78.861 Y95.304 E.01509
G1 X82.304 Y91.861 E.14506
G1 X81.798 Y91.861 E.01509
G1 X78.861 Y94.798 E.12372
G1 X78.861 Y94.291 E.01509
G1 X81.291 Y91.861 E.10238
G1 X80.784 Y91.861 E.01509
M73 P9 R29
G1 X78.861 Y93.784 E.08104
G1 X78.861 Y93.278 E.01509
G1 X80.278 Y91.861 E.0597
G1 X79.771 Y91.861 E.01509
G1 X78.861 Y92.771 E.03836
G1 X78.861 Y92.265 E.01509
G1 X79.425 Y91.7 E.02379
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.8 I-.45 J1.131 P1  F42000
G1 X121.443 Y108.443 Z.8
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
M73 P9 R28
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z1 I1.217 J0 P1  F42000
G1 X121.3 Y92.424
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40113
G1 F1674.995
M204 S6000
G1 X120.737 Y91.861 E.02374
G1 X120.23 Y91.861 E.01509
G1 X121.139 Y92.77 E.03831
G1 X121.139 Y93.277 E.01509
G1 X119.723 Y91.861 E.05965
G1 X119.217 Y91.861 E.01509
G1 X121.139 Y93.783 E.08099
G1 X121.139 Y94.29 E.01509
G1 X118.71 Y91.861 E.10233
G1 X118.204 Y91.861 E.01509
G1 X121.139 Y94.796 E.12366
G1 X121.139 Y95.303 E.01509
G1 X117.697 Y91.861 E.145
G1 X117.19 Y91.861 E.01509
G1 X121.139 Y95.81 E.16634
G1 X121.139 Y96.316 E.01509
G1 X116.684 Y91.861 E.18768
G1 X116.177 Y91.861 E.01509
G1 X121.139 Y96.823 E.20902
G1 X121.139 Y97.329 E.01509
G1 X115.671 Y91.861 E.23036
G1 X115.164 Y91.861 E.01509
G1 X121.139 Y97.836 E.2517
G1 X121.139 Y98.342 E.01509
G1 X114.658 Y91.861 E.27304
G1 X114.151 Y91.861 E.01509
G1 X121.139 Y98.849 E.29437
G1 X121.139 Y99.356 E.01509
G1 X113.644 Y91.861 E.31571
G1 X113.138 Y91.861 E.01509
G1 X121.139 Y99.862 E.33705
G1 X121.139 Y100.369 E.01509
G1 X112.631 Y91.861 E.35839
G1 X112.125 Y91.861 E.01509
G1 X121.139 Y100.875 E.37973
G1 X121.139 Y101.382 E.01509
G1 X111.618 Y91.861 E.40107
G1 X111.111 Y91.861 E.01509
G1 X121.139 Y101.889 E.42241
G1 X121.139 Y102.395 E.01509
G1 X110.605 Y91.861 E.44375
G1 X110.098 Y91.861 E.01509
G1 X121.139 Y102.902 E.46508
G1 X121.139 Y103.408 E.01509
G1 X109.592 Y91.861 E.48642
G1 X109.085 Y91.861 E.01509
G1 X121.139 Y103.915 E.50776
G1 X121.139 Y104.422 E.01509
G1 X108.579 Y91.861 E.5291
G1 X108.072 Y91.861 E.01509
M73 P10 R28
G1 X121.139 Y104.928 E.55044
G1 X121.139 Y105.435 E.01509
G1 X107.565 Y91.861 E.57178
G1 X107.059 Y91.861 E.01509
G1 X121.139 Y105.941 E.59312
G1 X121.139 Y106.448 E.01509
G1 X106.552 Y91.861 E.61446
G1 X106.046 Y91.861 E.01509
G1 X121.139 Y106.954 E.63579
G1 X121.139 Y107.461 E.01509
G1 X105.539 Y91.861 E.65713
G1 X105.032 Y91.861 E.01509
G1 X121.139 Y107.968 E.67847
G1 X121.139 Y108.139 E.00512
G1 X120.805 Y108.139 E.00997
G1 X104.526 Y91.861 E.68571
G1 X104.019 Y91.861 E.01509
G1 X120.298 Y108.139 E.68571
G1 X119.792 Y108.139 E.01509
G1 X103.513 Y91.861 E.68571
G1 X103.006 Y91.861 E.01509
G1 X119.285 Y108.139 E.68571
G1 X118.778 Y108.139 E.01509
G1 X102.499 Y91.861 E.68571
G1 X101.993 Y91.861 E.01509
G1 X118.272 Y108.139 E.68571
G1 X117.765 Y108.139 E.01509
G1 X101.486 Y91.861 E.68571
G1 X100.98 Y91.861 E.01509
G1 X117.259 Y108.139 E.68571
G1 X116.752 Y108.139 E.01509
G1 X100.473 Y91.861 E.68571
G1 X99.967 Y91.861 E.01509
G1 X116.245 Y108.139 E.68571
G1 X115.739 Y108.139 E.01509
G1 X99.46 Y91.861 E.68571
G1 X98.953 Y91.861 E.01509
G1 X115.232 Y108.139 E.68571
G1 X114.726 Y108.139 E.01509
G1 X98.447 Y91.861 E.68571
G1 X97.94 Y91.861 E.01509
G1 X114.219 Y108.139 E.68571
G1 X113.713 Y108.139 E.01509
G1 X97.434 Y91.861 E.68571
G1 X96.927 Y91.861 E.01509
G1 X113.206 Y108.139 E.68571
G1 X112.699 Y108.139 E.01509
G1 X96.42 Y91.861 E.68571
G1 X95.914 Y91.861 E.01509
M73 P11 R28
G1 X112.193 Y108.139 E.68571
G1 X111.686 Y108.139 E.01509
G1 X95.407 Y91.861 E.68571
G1 X94.901 Y91.861 E.01509
G1 X111.18 Y108.139 E.68571
G1 X110.673 Y108.139 E.01509
G1 X94.394 Y91.861 E.68571
G1 X93.888 Y91.861 E.01509
G1 X110.166 Y108.139 E.68571
G1 X109.66 Y108.139 E.01509
G1 X93.381 Y91.861 E.68571
G1 X92.874 Y91.861 E.01509
G1 X109.153 Y108.139 E.68571
G1 X108.647 Y108.139 E.01509
G1 X92.368 Y91.861 E.68571
G1 X91.861 Y91.861 E.01509
G1 X108.14 Y108.139 E.68571
G1 X107.633 Y108.139 E.01509
G1 X91.355 Y91.861 E.68571
G1 X90.848 Y91.861 E.01509
G1 X107.127 Y108.139 E.68571
G1 X106.62 Y108.139 E.01509
G1 X90.341 Y91.861 E.68571
G1 X89.835 Y91.861 E.01509
G1 X106.114 Y108.139 E.68571
G1 X105.607 Y108.139 E.01509
G1 X89.328 Y91.861 E.68571
G1 X88.822 Y91.861 E.01509
G1 X105.101 Y108.139 E.68571
G1 X104.594 Y108.139 E.01509
G1 X88.315 Y91.861 E.68571
G1 X87.809 Y91.861 E.01509
G1 X104.087 Y108.139 E.68571
G1 X103.581 Y108.139 E.01509
G1 X87.302 Y91.861 E.68571
G1 X86.795 Y91.861 E.01509
G1 X103.074 Y108.139 E.68571
G1 X102.568 Y108.139 E.01509
G1 X86.289 Y91.861 E.68571
G1 X85.782 Y91.861 E.01509
G1 X102.061 Y108.139 E.68571
G1 X101.554 Y108.139 E.01509
G1 X85.276 Y91.861 E.68571
G1 X84.769 Y91.861 E.01509
M73 P12 R28
G1 X101.048 Y108.139 E.68571
G1 X100.541 Y108.139 E.01509
G1 X84.262 Y91.861 E.68571
G1 X83.756 Y91.861 E.01509
G1 X100.035 Y108.139 E.68571
G1 X99.528 Y108.139 E.01509
G1 X83.249 Y91.861 E.68571
G1 X82.743 Y91.861 E.01509
G1 X99.022 Y108.139 E.68571
G1 X98.515 Y108.139 E.01509
G1 X82.236 Y91.861 E.68571
G1 X81.729 Y91.861 E.01509
G1 X98.008 Y108.139 E.68571
G1 X97.502 Y108.139 E.01509
G1 X81.223 Y91.861 E.68571
G1 X80.716 Y91.861 E.01509
G1 X96.995 Y108.139 E.68571
G1 X96.489 Y108.139 E.01509
G1 X80.21 Y91.861 E.68571
G1 X79.703 Y91.861 E.01509
M73 P12 R27
G1 X95.982 Y108.139 E.68571
G1 X95.475 Y108.139 E.01509
G1 X79.197 Y91.861 E.68571
G1 X78.861 Y91.861 E.01001
G1 X78.861 Y92.031 E.00508
G1 X94.969 Y108.139 E.67853
G1 X94.462 Y108.139 E.01509
G1 X78.861 Y92.538 E.65719
G1 X78.861 Y93.044 E.01509
G1 X93.956 Y108.139 E.63585
G1 X93.449 Y108.139 E.01509
G1 X78.861 Y93.551 E.61451
G1 X78.861 Y94.058 E.01509
G1 X92.943 Y108.139 E.59317
G1 X92.436 Y108.139 E.01509
G1 X78.861 Y94.564 E.57183
G1 X78.861 Y95.071 E.01509
G1 X91.929 Y108.139 E.55049
G1 X91.423 Y108.139 E.01509
G1 X78.861 Y95.577 E.52915
G1 X78.861 Y96.084 E.01509
G1 X90.916 Y108.139 E.50782
G1 X90.41 Y108.139 E.01509
G1 X78.861 Y96.59 E.48648
G1 X78.861 Y97.097 E.01509
G1 X89.903 Y108.139 E.46514
G1 X89.396 Y108.139 E.01509
G1 X78.861 Y97.604 E.4438
G1 X78.861 Y98.11 E.01509
G1 X88.89 Y108.139 E.42246
G1 X88.383 Y108.139 E.01509
M73 P13 R27
G1 X78.861 Y98.617 E.40112
G1 X78.861 Y99.123 E.01509
G1 X87.877 Y108.139 E.37978
G1 X87.37 Y108.139 E.01509
G1 X78.861 Y99.63 E.35844
G1 X78.861 Y100.137 E.01509
G1 X86.863 Y108.139 E.33711
G1 X86.357 Y108.139 E.01509
G1 X78.861 Y100.643 E.31577
G1 X78.861 Y101.15 E.01509
G1 X85.85 Y108.139 E.29443
G1 X85.344 Y108.139 E.01509
G1 X78.861 Y101.656 E.27309
G1 X78.861 Y102.163 E.01509
G1 X84.837 Y108.139 E.25175
G1 X84.331 Y108.139 E.01509
G1 X78.861 Y102.669 E.23041
G1 X78.861 Y103.176 E.01509
G1 X83.824 Y108.139 E.20907
G1 X83.317 Y108.139 E.01509
G1 X78.861 Y103.683 E.18773
G1 X78.861 Y104.189 E.01509
G1 X82.811 Y108.139 E.16639
G1 X82.304 Y108.139 E.01509
G1 X78.861 Y104.696 E.14506
G1 X78.861 Y105.202 E.01509
G1 X81.798 Y108.139 E.12372
G1 X81.291 Y108.139 E.01509
G1 X78.861 Y105.709 E.10238
G1 X78.861 Y106.216 E.01509
G1 X80.784 Y108.139 E.08104
G1 X80.278 Y108.139 E.01509
G1 X78.861 Y106.722 E.0597
G1 X78.861 Y107.229 E.01509
G1 X79.771 Y108.139 E.03836
G1 X79.265 Y108.139 E.01509
G1 X78.7 Y107.575 E.02379
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.2
M106 S188.7
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1 I-.025 J1.217 P1  F42000
G1 X121.443 Y108.443 Z1
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.2 I1.217 J0 P1  F42000
G1 X98.757 Y107.782
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X97.329 Y107.782 E.04241
G1 X101.5 Y92.218 E.47843
G1 X100.593 Y92.218 E.02693
G1 X116.157 Y107.782 E.65355
G1 X119.51 Y107.782 E.09954
G1 X120.782 Y103.033 E.14599
G1 X120.782 Y100.562 E.07336
G1 X93.836 Y107.782 E.82828
G1 X93.433 Y107.782 E.01199
G1 X78.861 Y93.198 E.61214
G1 X79.043 Y93.247 E.00562
M73 P14 R27
G1 X78.861 Y93.929 E.02097
G1 X78.861 Y95.16 E.03654
G1 X89.84 Y92.218 E.33749
G1 X90.409 Y92.218 E.01691
G1 X86.239 Y107.782 E.47843
G1 X85.858 Y107.782 E.01131
G1 X78.861 Y100.785 E.29382
G1 X78.861 Y100.705 E.00238
G1 X110.535 Y92.218 E.97362
G1 X112.59 Y92.218 E.06102
G1 X108.419 Y107.782 E.47843
G1 X108.582 Y107.782 E.00484
G1 X93.018 Y92.218 E.65355
G1 X95.954 Y92.218 E.0872
G1 X91.784 Y107.782 E.47843
G1 X90.356 Y107.782 E.04241
M204 S500
G1 X82.122 Y107.782 F42000
G1 F1680.297
M204 S6000
G1 X80.694 Y107.782 E.04241
G1 X84.864 Y92.218 E.47843
G1 X85.443 Y92.218 E.01718
G1 X101.007 Y107.782 E.65355
G1 X102.874 Y107.782 E.05543
G1 X107.045 Y92.218 E.47843
G1 X108.167 Y92.218 E.03333
G1 X120.782 Y104.833 E.5297
G1 X120.782 Y106.107 E.03785
G1 X114.531 Y107.782 E.19215
G1 X113.965 Y107.782 E.01683
G1 X118.135 Y92.218 E.47843
G1 X115.742 Y92.218 E.07105
G1 X120.782 Y97.258 E.21163
G1 X120.782 Y95.017 E.06653
G1 X79.218 Y106.154 E1.27764
G1 X79.218 Y105.036 E.03321
G1 X78.918 Y104.956 E.0092
M204 S500
G1 X78.887 Y98.453 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38292
G1 F1764.706
M204 S6000
G1 X78.887 Y96.498 E.05529
M204 S500
G1 X79.216 Y93.293 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X79.218 Y92.596 E.02069
G1 X79.319 Y92.218 E.01163
G1 X80.747 Y92.218 E.04241
M204 S500
G1 X78.888 Y92.864 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.382998
G1 F1764.302
M204 S6000
G1 X78.957 Y92.34 E.01495
G1 X78.887 Y92.039 E.00872
G1 X78.913 Y91.914 E.00363
G1 X79.039 Y91.887 E.00363
G1 X120.961 Y91.887 E1.18544
G1 X121.086 Y91.914 E.00363
G1 X121.113 Y92.039 E.00363
G1 X121.113 Y107.961 E.45022
G1 X121.086 Y108.087 E.00363
G1 X120.961 Y108.113 E.00363
G1 X79.039 Y108.113 E1.18544
G1 X78.913 Y108.087 E.00363
G1 X78.887 Y107.961 E.00363
G1 X78.887 Y105.349 E.07385
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
M106 S0
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.2 I-.088 J1.214 P1  F42000
G1 X121.443 Y108.443 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
M73 P15 R27
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.4 I1.217 J0 P1  F42000
G1 X118.783 Y91.705
G1 Z1
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40173
; LAYER_HEIGHT: 0.4
M106 S255
G1 F946.723
M204 S6000
G1 X121.093 Y92.323 E.12603
G1 X121.093 Y92.791 E.02465
G1 X117.793 Y91.907 E.18002
G1 X116.048 Y91.907 E.09198
G1 X121.093 Y93.259 E.27524
G1 X121.093 Y93.726 E.02465
G1 X114.303 Y91.907 E.37046
G1 X112.557 Y91.907 E.09198
G1 X121.093 Y94.194 E.46568
G1 X121.093 Y94.662 E.02465
G1 X110.812 Y91.907 E.5609
G1 X109.067 Y91.907 E.09198
G1 X121.093 Y95.129 E.65612
G1 X121.093 Y95.597 E.02465
G1 X107.321 Y91.907 E.75134
G1 X105.576 Y91.907 E.09198
G1 X121.093 Y96.065 E.84656
G1 X121.093 Y96.532 E.02465
M73 P15 R26
G1 X103.831 Y91.907 E.94178
G1 X102.085 Y91.907 E.09198
G1 X121.093 Y97 E1.037
G1 X121.093 Y97.468 E.02464
G1 X100.34 Y91.907 E1.13222
G1 X98.595 Y91.907 E.09198
G1 X121.093 Y97.935 E1.22744
G1 X121.093 Y98.403 E.02464
G1 X96.849 Y91.907 E1.32266
G1 X95.104 Y91.907 E.09198
G1 X121.093 Y98.871 E1.41788
G1 X121.093 Y99.338 E.02464
M73 P16 R26
G1 X93.358 Y91.907 E1.5131
G1 X91.613 Y91.907 E.09198
G1 X121.093 Y99.806 E1.60833
G1 X121.093 Y100.274 E.02464
G1 X89.868 Y91.907 E1.70355
G1 X88.122 Y91.907 E.09198
G1 X121.093 Y100.741 E1.79877
G1 X121.093 Y101.209 E.02464
G1 X86.377 Y91.907 E1.89399
G1 X84.632 Y91.907 E.09198
G1 X121.093 Y101.677 E1.98921
G1 X121.093 Y102.144 E.02464
G1 X82.886 Y91.907 E2.08443
G1 X81.141 Y91.907 E.09198
G1 X121.093 Y102.612 E2.17965
G1 X121.093 Y103.08 E.02464
M73 P17 R26
G1 X79.396 Y91.907 E2.27487
G1 X78.907 Y91.907 E.02575
G1 X78.907 Y92.02 E.00597
G1 X79.128 Y92.256 E.01701
G1 X79.116 Y92.3 E.0024
G1 X121.093 Y103.547 E2.29014
G1 X121.093 Y104.015 E.02464
G1 X78.999 Y92.736 E2.29652
G1 X78.979 Y92.811 E.0041
G1 X81.417 Y93.465 E.13302
G1 X81.417 Y93.852 E.0204
G1 X121.093 Y104.483 E2.1646
G1 X121.093 Y104.95 E.02465
G1 X81.417 Y94.319 E2.1646
G1 X81.417 Y94.5 E.00955
G1 X80.882 Y94.644 E.02916
G1 X121.093 Y105.418 E2.19376
G1 X121.093 Y105.886 E.02465
G1 X80.766 Y95.08 E2.20012
G1 X81.405 Y95.719 E.04761
M73 P18 R26
G1 X121.093 Y106.353 E2.16527
G1 X121.093 Y106.821 E.02465
G1 X81.979 Y96.341 E2.13393
G1 X81.745 Y96.746 E.02465
G1 X121.093 Y107.289 E2.14668
G1 X121.093 Y107.756 E.02465
G1 X81.511 Y97.151 E2.15944
G1 X81.478 Y97.208 E.00348
G1 X78.907 Y96.519 E.14028
G1 X78.907 Y96.92 E.02116
G1 X120.604 Y108.093 E2.27483
G1 X118.858 Y108.093 E.09198
M73 P18 R25
G1 X78.907 Y97.388 E2.17961
G1 X78.907 Y97.856 E.02464
G1 X117.113 Y108.093 E2.08439
G1 X115.368 Y108.093 E.09198
G1 X78.907 Y98.323 E1.98917
M73 P19 R25
G1 X78.907 Y98.383 E.00312
G1 X81.935 Y99.194 E.16519
G1 X82.236 Y99.683 E.03026
G1 X113.622 Y108.093 E1.71235
G1 X111.877 Y108.093 E.09198
G1 X82.536 Y100.231 E1.60075
G1 X82.419 Y100.667 E.02381
G1 X110.131 Y108.093 E1.51191
G1 X108.386 Y108.093 E.09198
G1 X82.302 Y101.104 E1.42307
G1 X82.185 Y101.54 E.02381
G1 X106.641 Y108.093 E1.33423
G1 X104.895 Y108.093 E.09198
G1 X82.068 Y101.976 E1.24539
G1 X81.951 Y102.413 E.02381
G1 X103.15 Y108.093 E1.15654
G1 X101.405 Y108.093 E.09198
G1 X81.834 Y102.849 E1.0677
G1 X81.717 Y103.285 E.02381
G1 X99.659 Y108.093 E.97886
G1 X97.914 Y108.093 E.09198
G1 X81.918 Y103.807 E.87272
G1 X82.556 Y104.446 E.04761
G1 X96.169 Y108.093 E.74265
G1 X94.423 Y108.093 E.09198
M73 P20 R25
G1 X81.732 Y104.692 E.69242
G1 X81.631 Y104.711 E.00539
G1 X82.299 Y105.312 E.04737
G1 X92.678 Y108.093 E.56624
G1 X90.933 Y108.093 E.09198
G1 X81.506 Y105.567 E.51431
G1 X81.191 Y105.651 E.01714
G1 X81.117 Y105.93 E.01523
G1 X89.187 Y108.093 E.44032
G1 X87.442 Y108.093 E.09198
G1 X78.907 Y105.806 E.46564
G1 X78.907 Y106.274 E.02465
G1 X85.697 Y108.093 E.37042
G1 X83.951 Y108.093 E.09198
G1 X78.907 Y106.741 E.2752
G1 X78.907 Y107.209 E.02465
G1 X82.206 Y108.093 E.17998
G1 X80.461 Y108.093 E.09198
G1 X78.705 Y107.622 E.0958
M106 S0
M204 S500
G1 X79.959 Y105.235 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
; LAYER_HEIGHT: 0.2
G1 F1680.297
M204 S6000
G1 X80.823 Y105.466 E.02655
G1 X80.862 Y105.322 E.00444
G1 X81.233 Y105.222 E.01142
G1 X81.304 Y104.959 E.00808
G1 X80.75 Y104.461 E.02213
G1 X81.473 Y104.329 E.02181
G1 X81.556 Y104.016 E.00961
G1 X81.368 Y103.828 E.00791
G1 X81.308 Y103.253 E.01717
G1 X81.355 Y103.079 E.00534
G1 X78.861 Y100.585 E.10473
G1 X78.861 Y100.851 E.00791
G1 X81.968 Y100.019 E.09552
G1 X81.675 Y99.542 E.0166
G1 X80.836 Y99.317 E.0258
M204 S500
G1 X79.484 Y96.256 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y96.089 E.01918
G1 X78.861 Y95.306 E.02323
G1 X80.091 Y94.976 E.03783
G1 X79.666 Y94.552 E.01783
G1 X80.247 Y94.396 E.01783
G1 X79.116 Y93.266 E.04745
G1 X78.907 Y93.21 E.00644
G1 X78.861 Y93.383 E.00531
G1 X78.861 Y94.811 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.2
M106 S155.55
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.4 I-.371 J1.159 P1  F42000
G1 X121.443 Y108.443 Z1.4
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.6 I1.217 J0 P1  F42000
G1 X120.576 Y108.3
G1 Z1.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.401
G1 F1675.603
M204 S6000
G1 X121.139 Y107.737 E.02372
G1 X121.139 Y107.23 E.01508
G1 X120.23 Y108.139 E.03828
G1 X119.724 Y108.139 E.01508
G1 X121.139 Y106.724 E.0596
G1 X121.139 Y106.218 E.01508
G1 X119.218 Y108.139 E.08092
G1 X118.711 Y108.139 E.01508
G1 X121.139 Y105.711 E.10225
G1 X121.139 Y105.205 E.01508
G1 X118.205 Y108.139 E.12357
G1 X117.698 Y108.139 E.01508
G1 X121.139 Y104.698 E.14489
G1 X121.139 Y104.192 E.01508
G1 X117.192 Y108.139 E.16622
G1 X116.686 Y108.139 E.01508
G1 X121.139 Y103.686 E.18754
G1 X121.139 Y103.179 E.01508
G1 X116.179 Y108.139 E.20886
G1 X115.673 Y108.139 E.01508
G1 X121.139 Y102.673 E.23019
G1 X121.139 Y102.166 E.01508
G1 X115.166 Y108.139 E.25151
G1 X114.66 Y108.139 E.01508
G1 X121.139 Y101.66 E.27283
G1 X121.139 Y101.154 E.01508
M73 P21 R25
G1 X114.154 Y108.139 E.29416
G1 X113.647 Y108.139 E.01508
G1 X121.139 Y100.647 E.31548
G1 X121.139 Y100.141 E.01508
G1 X113.141 Y108.139 E.3368
G1 X112.634 Y108.139 E.01508
G1 X121.139 Y99.634 E.35813
G1 X121.139 Y99.128 E.01508
G1 X112.128 Y108.139 E.37945
G1 X111.622 Y108.139 E.01508
G1 X121.139 Y98.622 E.40077
G1 X121.139 Y98.115 E.01508
G1 X111.115 Y108.139 E.4221
G1 X110.609 Y108.139 E.01508
G1 X121.139 Y97.609 E.44342
G1 X121.139 Y97.102 E.01508
G1 X110.102 Y108.139 E.46474
G1 X109.596 Y108.139 E.01508
G1 X121.139 Y96.596 E.48607
G1 X121.139 Y96.09 E.01508
G1 X109.09 Y108.139 E.50739
G1 X108.583 Y108.139 E.01508
G1 X121.139 Y95.583 E.52871
G1 X121.139 Y95.077 E.01508
G1 X108.077 Y108.139 E.55004
G1 X107.57 Y108.139 E.01508
G1 X121.139 Y94.57 E.57136
G1 X121.139 Y94.064 E.01508
G1 X107.064 Y108.139 E.59268
G1 X106.558 Y108.139 E.01508
G1 X121.139 Y93.558 E.614
G1 X121.139 Y93.051 E.01508
G1 X106.051 Y108.139 E.63533
G1 X105.545 Y108.139 E.01508
G1 X121.139 Y92.545 E.65665
G1 X121.139 Y92.038 E.01508
G1 X105.038 Y108.139 E.67798
G1 X104.532 Y108.139 E.01508
G1 X120.811 Y91.861 E.68546
G1 X120.304 Y91.861 E.01508
G1 X104.026 Y108.139 E.68546
G1 X103.519 Y108.139 E.01508
G1 X119.798 Y91.861 E.68546
G1 X119.292 Y91.861 E.01508
G1 X103.013 Y108.139 E.68546
G1 X102.506 Y108.139 E.01508
G1 X118.785 Y91.861 E.68546
G1 X118.279 Y91.861 E.01508
M73 P21 R24
G1 X102 Y108.139 E.68546
G1 X101.494 Y108.139 E.01508
G1 X117.772 Y91.861 E.68546
G1 X117.266 Y91.861 E.01508
G1 X100.987 Y108.139 E.68546
G1 X100.481 Y108.139 E.01508
G1 X116.76 Y91.861 E.68546
G1 X116.253 Y91.861 E.01508
M73 P22 R24
G1 X99.974 Y108.139 E.68546
G1 X99.468 Y108.139 E.01508
G1 X115.747 Y91.861 E.68546
G1 X115.24 Y91.861 E.01508
G1 X98.962 Y108.139 E.68546
G1 X98.455 Y108.139 E.01508
G1 X114.734 Y91.861 E.68546
G1 X114.228 Y91.861 E.01508
G1 X97.949 Y108.139 E.68546
G1 X97.442 Y108.139 E.01508
G1 X113.721 Y91.861 E.68546
G1 X113.215 Y91.861 E.01508
G1 X96.936 Y108.139 E.68546
G1 X96.43 Y108.139 E.01508
G1 X112.708 Y91.861 E.68546
G1 X112.202 Y91.861 E.01508
G1 X95.923 Y108.139 E.68546
G1 X95.417 Y108.139 E.01508
G1 X111.696 Y91.861 E.68546
G1 X111.189 Y91.861 E.01508
G1 X94.91 Y108.139 E.68546
G1 X94.404 Y108.139 E.01508
G1 X110.683 Y91.861 E.68546
G1 X110.176 Y91.861 E.01508
G1 X93.898 Y108.139 E.68546
G1 X93.391 Y108.139 E.01508
G1 X109.67 Y91.861 E.68546
G1 X109.164 Y91.861 E.01508
G1 X92.885 Y108.139 E.68546
G1 X92.378 Y108.139 E.01508
G1 X108.657 Y91.861 E.68546
G1 X108.151 Y91.861 E.01508
G1 X91.872 Y108.139 E.68546
G1 X91.366 Y108.139 E.01508
G1 X107.644 Y91.861 E.68546
G1 X107.138 Y91.861 E.01508
G1 X90.859 Y108.139 E.68546
G1 X90.353 Y108.139 E.01508
G1 X106.632 Y91.861 E.68546
G1 X106.125 Y91.861 E.01508
G1 X89.846 Y108.139 E.68546
G1 X89.34 Y108.139 E.01508
G1 X105.619 Y91.861 E.68546
G1 X105.112 Y91.861 E.01508
G1 X88.834 Y108.139 E.68546
G1 X88.327 Y108.139 E.01508
M73 P23 R24
G1 X104.606 Y91.861 E.68546
G1 X104.1 Y91.861 E.01508
G1 X87.821 Y108.139 E.68546
G1 X87.314 Y108.139 E.01508
G1 X103.593 Y91.861 E.68546
G1 X103.087 Y91.861 E.01508
G1 X86.808 Y108.139 E.68546
G1 X86.302 Y108.139 E.01508
G1 X102.58 Y91.861 E.68546
G1 X102.074 Y91.861 E.01508
G1 X85.795 Y108.139 E.68546
G1 X85.289 Y108.139 E.01508
G1 X101.568 Y91.861 E.68546
G1 X101.061 Y91.861 E.01508
G1 X84.782 Y108.139 E.68546
G1 X84.276 Y108.139 E.01508
G1 X100.555 Y91.861 E.68546
G1 X100.048 Y91.861 E.01508
G1 X83.77 Y108.139 E.68546
G1 X83.263 Y108.139 E.01508
G1 X99.542 Y91.861 E.68546
G1 X99.036 Y91.861 E.01508
G1 X82.757 Y108.139 E.68546
G1 X82.25 Y108.139 E.01508
G1 X98.529 Y91.861 E.68546
G1 X98.023 Y91.861 E.01508
G1 X81.744 Y108.139 E.68546
G1 X81.237 Y108.139 E.01508
G1 X82.977 Y106.4 E.07324
G1 X82.47 Y106.4 E.01508
G1 X80.731 Y108.139 E.07324
G1 X80.225 Y108.139 E.01508
G1 X81.964 Y106.4 E.07324
G1 X81.458 Y106.4 E.01508
G1 X79.718 Y108.139 E.07324
G1 X79.212 Y108.139 E.01508
G1 X80.951 Y106.4 E.07324
G1 X80.445 Y106.4 E.01508
G1 X78.861 Y107.984 E.06671
G1 X78.861 Y107.478 E.01508
G1 X79.938 Y106.4 E.04539
G1 X79.432 Y106.4 E.01508
G1 X78.861 Y106.972 E.02407
G1 X78.861 Y106.465 E.01508
G1 X79.086 Y106.239 E.00951
M204 S500
G1 X83.239 Y106.138 F42000
G1 F1675.603
M204 S6000
G1 X97.516 Y91.861 E.60117
G1 X97.01 Y91.861 E.01508
G1 X83.4 Y105.47 E.57308
G1 X83.4 Y104.964 E.01508
G1 X96.504 Y91.861 E.55176
G1 X95.997 Y91.861 E.01508
G1 X83.4 Y104.458 E.53043
G1 X83.4 Y103.951 E.01508
G1 X95.491 Y91.861 E.50911
G1 X94.984 Y91.861 E.01508
G1 X83.4 Y103.445 E.48779
G1 X83.4 Y102.938 E.01508
G1 X94.478 Y91.861 E.46646
G1 X93.972 Y91.861 E.01508
G1 X83.4 Y102.432 E.44514
G1 X83.4 Y101.926 E.01508
G1 X93.465 Y91.861 E.42382
G1 X92.959 Y91.861 E.01508
G1 X83.4 Y101.419 E.40249
G1 X83.4 Y100.913 E.01508
M73 P24 R24
G1 X92.452 Y91.861 E.38117
G1 X91.946 Y91.861 E.01508
G1 X83.4 Y100.406 E.35985
G1 X83.4 Y99.9 E.01508
G1 X91.44 Y91.861 E.33852
G1 X90.933 Y91.861 E.01508
G1 X83.4 Y99.394 E.3172
G1 X83.4 Y98.887 E.01508
G1 X90.427 Y91.861 E.29588
G1 X89.92 Y91.861 E.01508
G1 X83.4 Y98.381 E.27455
G1 X83.4 Y97.874 E.01508
G1 X89.414 Y91.861 E.25323
G1 X88.908 Y91.861 E.01508
G1 X83.4 Y97.368 E.23191
G1 X83.4 Y96.862 E.01508
G1 X88.401 Y91.861 E.21058
G1 X87.895 Y91.861 E.01508
G1 X83.4 Y96.355 E.18926
G1 X83.4 Y95.849 E.01508
G1 X87.388 Y91.861 E.16794
G1 X86.882 Y91.861 E.01508
G1 X83.4 Y95.342 E.14661
G1 X83.4 Y94.836 E.01508
G1 X86.376 Y91.861 E.12529
G1 X85.869 Y91.861 E.01508
G1 X83.4 Y94.33 E.10397
G1 X83.4 Y93.823 E.01508
G1 X85.363 Y91.861 E.08264
G1 X84.856 Y91.861 E.01508
G1 X83.4 Y93.317 E.06132
G1 X83.4 Y92.81 E.01508
G1 X84.35 Y91.861 E.04
G1 X83.844 Y91.861 E.01508
G1 X83.239 Y92.465 E.02544
M204 S500
G1 X78.861 Y96.881 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y95.452 E.04241
G1 X83.043 Y94.332 E.12856
G1 X83.043 Y91.861 E.07337
G1 X79.122 Y91.861 E.11642
G1 X78.861 Y92.836 E.02999
G1 X78.861 Y92.81 E.00077
G1 X83.043 Y96.993 E.17562
G1 X83.043 Y97.922 E.0276
G1 X80.867 Y106.043 E.24962
G1 X80.726 Y106.043 E.00418
G1 X83.043 Y105.422 E.07122
G1 X83.043 Y104.567 E.02538
G1 X78.861 Y100.385 E.17562
G1 X78.861 Y100.998 E.01819
G1 X83.043 Y99.877 E.12856
G1 X83.043 Y101.305 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.6 I-.222 J1.196 P1  F42000
G1 X121.443 Y108.443 Z1.6
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y108.443 E1.2733
G1 X78.557 Y91.557 E.50135
G1 X121.443 Y91.557 E1.2733
G1 X121.443 Y100 E.25068
G1 X121.443 Y108.383 E.24889
M204 S250
G1 X121.8 Y108.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.8 I1.217 J0 P1  F42000
G1 X121.3 Y92.424
G1 Z1.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40113
G1 F1674.995
M204 S6000
G1 X120.737 Y91.861 E.02374
G1 X120.23 Y91.861 E.01509
G1 X121.139 Y92.77 E.03831
G1 X121.139 Y93.277 E.01509
G1 X119.723 Y91.861 E.05965
G1 X119.217 Y91.861 E.01509
G1 X121.139 Y93.783 E.08099
G1 X121.139 Y94.29 E.01509
G1 X118.71 Y91.861 E.10233
G1 X118.204 Y91.861 E.01509
G1 X121.139 Y94.796 E.12366
G1 X121.139 Y95.303 E.01509
G1 X117.697 Y91.861 E.145
G1 X117.19 Y91.861 E.01509
G1 X121.139 Y95.81 E.16634
G1 X121.139 Y96.316 E.01509
G1 X116.684 Y91.861 E.18768
G1 X116.177 Y91.861 E.01509
M73 P24 R23
G1 X121.139 Y96.823 E.20902
G1 X121.139 Y97.329 E.01509
G1 X115.671 Y91.861 E.23036
G1 X115.164 Y91.861 E.01509
G1 X121.139 Y97.836 E.2517
G1 X121.139 Y98.342 E.01509
G1 X114.658 Y91.861 E.27304
G1 X114.151 Y91.861 E.01509
M73 P25 R23
G1 X121.139 Y98.849 E.29437
G1 X121.139 Y99.356 E.01509
G1 X113.644 Y91.861 E.31571
G1 X113.138 Y91.861 E.01509
G1 X121.139 Y99.862 E.33705
G1 X121.139 Y100.369 E.01509
G1 X112.631 Y91.861 E.35839
G1 X112.125 Y91.861 E.01509
G1 X121.139 Y100.875 E.37973
G1 X121.139 Y101.382 E.01509
G1 X111.618 Y91.861 E.40107
G1 X111.111 Y91.861 E.01509
G1 X121.139 Y101.889 E.42241
G1 X121.139 Y102.395 E.01509
G1 X110.605 Y91.861 E.44375
G1 X110.098 Y91.861 E.01509
G1 X121.139 Y102.902 E.46508
G1 X121.139 Y103.408 E.01509
G1 X109.592 Y91.861 E.48642
G1 X109.085 Y91.861 E.01509
G1 X121.139 Y103.915 E.50776
G1 X121.139 Y104.422 E.01509
G1 X108.579 Y91.861 E.5291
G1 X108.072 Y91.861 E.01509
G1 X121.139 Y104.928 E.55044
G1 X121.139 Y105.435 E.01509
G1 X107.565 Y91.861 E.57178
G1 X107.059 Y91.861 E.01509
G1 X121.139 Y105.941 E.59312
G1 X121.139 Y106.448 E.01509
G1 X106.552 Y91.861 E.61446
G1 X106.046 Y91.861 E.01509
G1 X121.139 Y106.954 E.63579
G1 X121.139 Y107.461 E.01509
G1 X105.539 Y91.861 E.65713
G1 X105.032 Y91.861 E.01509
G1 X121.139 Y107.968 E.67847
G1 X121.139 Y108.139 E.00512
G1 X120.805 Y108.139 E.00997
G1 X104.526 Y91.861 E.68571
G1 X104.019 Y91.861 E.01509
G1 X120.298 Y108.139 E.68571
G1 X119.792 Y108.139 E.01509
G1 X103.513 Y91.861 E.68571
G1 X103.006 Y91.861 E.01509
G1 X119.285 Y108.139 E.68571
G1 X118.778 Y108.139 E.01509
G1 X102.499 Y91.861 E.68571
G1 X101.993 Y91.861 E.01509
G1 X118.272 Y108.139 E.68571
G1 X117.765 Y108.139 E.01509
G1 X101.486 Y91.861 E.68571
G1 X100.98 Y91.861 E.01509
G1 X117.259 Y108.139 E.68571
G1 X116.752 Y108.139 E.01509
G1 X100.473 Y91.861 E.68571
G1 X99.967 Y91.861 E.01509
M73 P26 R23
G1 X116.245 Y108.139 E.68571
G1 X115.739 Y108.139 E.01509
G1 X99.46 Y91.861 E.68571
G1 X98.953 Y91.861 E.01509
G1 X115.232 Y108.139 E.68571
G1 X114.726 Y108.139 E.01509
G1 X98.447 Y91.861 E.68571
G1 X97.94 Y91.861 E.01509
G1 X114.219 Y108.139 E.68571
G1 X113.713 Y108.139 E.01509
G1 X97.434 Y91.861 E.68571
G1 X96.927 Y91.861 E.01509
G1 X113.206 Y108.139 E.68571
G1 X112.699 Y108.139 E.01509
G1 X96.42 Y91.861 E.68571
G1 X95.914 Y91.861 E.01509
G1 X112.193 Y108.139 E.68571
G1 X111.686 Y108.139 E.01509
G1 X95.407 Y91.861 E.68571
G1 X94.901 Y91.861 E.01509
G1 X111.18 Y108.139 E.68571
G1 X110.673 Y108.139 E.01509
G1 X94.394 Y91.861 E.68571
G1 X93.888 Y91.861 E.01509
G1 X110.166 Y108.139 E.68571
G1 X109.66 Y108.139 E.01509
G1 X93.381 Y91.861 E.68571
G1 X92.874 Y91.861 E.01509
G1 X109.153 Y108.139 E.68571
G1 X108.647 Y108.139 E.01509
G1 X92.368 Y91.861 E.68571
G1 X91.861 Y91.861 E.01509
G1 X108.14 Y108.139 E.68571
G1 X107.633 Y108.139 E.01509
G1 X91.355 Y91.861 E.68571
G1 X90.848 Y91.861 E.01509
G1 X107.127 Y108.139 E.68571
G1 X106.62 Y108.139 E.01509
G1 X90.341 Y91.861 E.68571
G1 X89.835 Y91.861 E.01509
G1 X106.114 Y108.139 E.68571
G1 X105.607 Y108.139 E.01509
G1 X89.328 Y91.861 E.68571
G1 X88.822 Y91.861 E.01509
G1 X105.101 Y108.139 E.68571
G1 X104.594 Y108.139 E.01509
M73 P27 R23
G1 X88.315 Y91.861 E.68571
G1 X87.809 Y91.861 E.01509
G1 X104.087 Y108.139 E.68571
G1 X103.581 Y108.139 E.01509
G1 X87.302 Y91.861 E.68571
G1 X86.795 Y91.861 E.01509
G1 X103.074 Y108.139 E.68571
G1 X102.568 Y108.139 E.01509
G1 X86.289 Y91.861 E.68571
G1 X85.782 Y91.861 E.01509
G1 X102.061 Y108.139 E.68571
G1 X101.554 Y108.139 E.01509
G1 X85.276 Y91.861 E.68571
G1 X84.769 Y91.861 E.01509
G1 X101.048 Y108.139 E.68571
G1 X100.541 Y108.139 E.01509
G1 X84.262 Y91.861 E.68571
G1 X83.756 Y91.861 E.01509
G1 X100.035 Y108.139 E.68571
G1 X99.528 Y108.139 E.01509
G1 X83.4 Y92.011 E.67936
G1 X83.4 Y92.518 E.01509
G1 X99.022 Y108.139 E.65802
G1 X98.515 Y108.139 E.01509
G1 X83.4 Y93.025 E.63668
G1 X83.4 Y93.531 E.01509
G1 X98.008 Y108.139 E.61534
G1 X97.502 Y108.139 E.01509
G1 X83.4 Y94.038 E.594
G1 X83.4 Y94.544 E.01509
G1 X96.995 Y108.139 E.57266
G1 X96.489 Y108.139 E.01509
G1 X83.4 Y95.051 E.55133
G1 X83.4 Y95.557 E.01509
G1 X95.982 Y108.139 E.52999
G1 X95.475 Y108.139 E.01509
G1 X83.4 Y96.064 E.50865
G1 X83.4 Y96.571 E.01509
G1 X94.969 Y108.139 E.48731
G1 X94.462 Y108.139 E.01509
G1 X83.4 Y97.077 E.46597
G1 X83.4 Y97.584 E.01509
G1 X93.956 Y108.139 E.44463
G1 X93.449 Y108.139 E.01509
G1 X83.4 Y98.09 E.42329
G1 X83.4 Y98.597 E.01509
G1 X92.943 Y108.139 E.40195
G1 X92.436 Y108.139 E.01509
G1 X83.4 Y99.104 E.38062
G1 X83.4 Y99.61 E.01509
G1 X91.929 Y108.139 E.35928
G1 X91.423 Y108.139 E.01509
M73 P28 R23
G1 X83.4 Y100.117 E.33794
G1 X83.4 Y100.623 E.01509
G1 X90.916 Y108.139 E.3166
G1 X90.41 Y108.139 E.01509
G1 X83.4 Y101.13 E.29526
G1 X83.4 Y101.637 E.01509
G1 X89.903 Y108.139 E.27392
G1 X89.396 Y108.139 E.01509
M73 P28 R22
G1 X83.4 Y102.143 E.25258
G1 X83.4 Y102.65 E.01509
G1 X88.89 Y108.139 E.23124
G1 X88.383 Y108.139 E.01509
G1 X83.4 Y103.156 E.20991
G1 X83.4 Y103.663 E.01509
G1 X87.877 Y108.139 E.18857
G1 X87.37 Y108.139 E.01509
G1 X83.4 Y104.169 E.16723
G1 X83.4 Y104.676 E.01509
G1 X86.863 Y108.139 E.14589
G1 X86.357 Y108.139 E.01509
G1 X83.4 Y105.183 E.12455
G1 X83.4 Y105.689 E.01509
G1 X85.85 Y108.139 E.10321
G1 X85.344 Y108.139 E.01509
G1 X83.4 Y106.196 E.08187
G1 X83.208 Y106.4 E.00836
G1 X83.098 Y106.4 E.00327
G1 X84.837 Y108.139 E.07327
G1 X84.331 Y108.139 E.01509
G1 X82.591 Y106.4 E.07327
G1 X82.085 Y106.4 E.01509
G1 X83.824 Y108.139 E.07327
G1 X83.317 Y108.139 E.01509
G1 X81.578 Y106.4 E.07327
G1 X81.071 Y106.4 E.01509
G1 X82.811 Y108.139 E.07327
G1 X82.304 Y108.139 E.01509
G1 X80.565 Y106.4 E.07327
G1 X80.058 Y106.4 E.01509
G1 X81.798 Y108.139 E.07327
G1 X81.291 Y108.139 E.01509
G1 X79.552 Y106.4 E.07327
G1 X79.045 Y106.4 E.01509
G1 X80.784 Y108.139 E.07327
G1 X80.278 Y108.139 E.01509
G1 X78.861 Y106.722 E.0597
G1 X78.861 Y107.229 E.01509
G1 X79.771 Y108.139 E.03836
G1 X79.265 Y108.139 E.01509
G1 X78.7 Y107.575 E.02379
M204 S500
G1 X83.043 Y101.452 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.043 Y100.023 E.04241
G1 X78.861 Y101.144 E.12856
G1 X78.861 Y100.185 E.02848
G1 X83.043 Y104.367 E.17562
G1 X83.043 Y105.569 E.03567
G1 X81.272 Y106.043 E.05442
G1 X80.721 Y106.043 E.01639
G1 X83.043 Y97.376 E.26642
G1 X83.043 Y96.793 E.01732
G1 X78.861 Y92.61 E.17562
G1 X78.861 Y95.599 E.08874
G1 X83.043 Y94.478 E.12856
G1 X83.043 Y93.05 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
M106 S153
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.8 I-.363 J1.161 P1  F42000
G1 X121.443 Y105.067 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X119.579 Y105.067 E.05536
G1 X119.579 Y104.224 E.02503
G1 X121.443 Y104.224 E.05536
G1 X121.443 Y104.646 E.01251
G1 X121.443 Y105.007 E.01073
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I.274 J-1.186 P1  F42000
G1 X116.421 Y103.848 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X114.579 Y103.848 E.05472
G1 X114.579 Y102.005 E.05472
G1 X116.421 Y102.005 E.05472
G1 X116.421 Y103.788 E.05294
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I.956 J.754 P1  F42000
G1 X121.443 Y97.421 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X118.579 Y97.421 E.08505
G1 X118.579 Y95.989 E.04252
G1 X118.579 Y91.557 E.13159
G1 X121.443 Y91.557 E.08505
G1 X121.443 Y97.361 E.17234
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.732 J-.972 P1  F42000
G1 X109.421 Y106.421 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X106.579 Y106.421 E.08441
G1 X106.579 Y100.579 E.17348
G1 X109.421 Y100.579 E.08441
G1 X109.421 Y106.361 E.1717
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.009 J-1.217 P1  F42000
G1 X101.421 Y106.421 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X98.579 Y106.421 E.08441
G1 X98.579 Y100.579 E.17348
G1 X101.421 Y100.579 E.08441
G1 X101.421 Y106.361 E.1717
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I1.217 J0 P1  F42000
G1 X101.421 Y97.421 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X98.579 Y97.421 E.08441
G1 X98.579 Y91.557 E.17412
G1 X101.421 Y91.557 E.08441
G1 X101.421 Y97.361 E.17234
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.547 J-1.087 P1  F42000
G1 X83.421 Y106.421 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1680.343
M204 S6000
G1 X78.557 Y106.421 E.14443
G1 X78.557 Y91.557 E.44133
G1 X83.421 Y91.557 E.14443
G1 X83.421 Y106.361 E.43955
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.077 J1.215 P1  F42000
G1 X121.8 Y108.8 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Outer wall
G1 F1680.343
G1 X78.2 Y108.8 E1.29451
G1 X78.2 Y91.2 E.52255
G1 X121.8 Y91.2 E1.29451
G1 X121.8 Y100 E.26128
M73 P29 R22
G1 X121.8 Y108.74 E.2595
G1 E-.8 F1800
G17
G3 Z2 I1.217 J0 P1  F42000
G1 X120.929 Y108.657
G1 Z1.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40282
G1 F1667.13
G1 X121.497 Y108.09 E.024
G1 X121.497 Y107.581 E.01523
G1 X120.581 Y108.497 E.03874
G1 X120.072 Y108.497 E.01523
G1 X121.497 Y107.072 E.06028
G1 X121.497 Y106.563 E.01523
G1 X119.563 Y108.497 E.08182
G1 X119.054 Y108.497 E.01523
G1 X121.497 Y106.054 E.10337
G1 X121.497 Y105.545 E.01523
G1 X118.545 Y108.497 E.12491
G1 X118.036 Y108.497 E.01523
G1 X121.162 Y105.371 E.1323
G1 X120.653 Y105.371 E.01523
G1 X117.527 Y108.497 E.1323
G1 X117.018 Y108.497 E.01523
G1 X120.144 Y105.371 E.1323
G1 X119.635 Y105.371 E.01523
G1 X116.509 Y108.497 E.1323
G1 X116 Y108.497 E.01523
G1 X119.275 Y105.222 E.13859
G1 X119.275 Y104.713 E.01523
G1 X115.491 Y108.497 E.16013
G1 X114.982 Y108.497 E.01523
G1 X121.497 Y101.982 E.27569
G1 X121.497 Y102.491 E.01523
G1 X120.067 Y103.921 E.06049
G1 X120.576 Y103.921 E.01523
G1 X121.497 Y103 E.03895
G1 X121.497 Y103.509 E.01523
G1 X120.924 Y104.081 E.02421
G1 X120 Y104.646 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.5288
G1 F1234.873
M204 S6000
G1 X120.961 Y104.646 E.03884
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I.431 J-1.138 P1  F42000
G1 X114.936 Y102.362 Z2
G1 Z1.6
G1 E.8 F1800
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.936 Y103.491 E.03352
G1 X116.064 Y103.491 E.03352
G1 X116.064 Y102.362 E.03352
G1 X114.996 Y102.362 E.03173
M204 S500
G1 X115.307 Y102.734 F42000
; LINE_WIDTH: 0.42879
G1 F1554.928
M204 S6000
G1 X115.307 Y103.119 E.01238
G1 X115.693 Y103.119 E.01238
G1 X115.693 Y102.734 E.01238
G1 X115.367 Y102.734 E.01046
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-1.198 J-.213 P1  F42000
G1 X114.313 Y108.657 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40282
G1 F1667.13
G1 X121.497 Y101.473 E.30403
G1 X121.497 Y100.964 E.01523
G1 X113.964 Y108.497 E.31877
G1 X113.455 Y108.497 E.01523
G1 X121.497 Y100.456 E.34031
G1 X121.497 Y99.947 E.01523
G1 X112.947 Y108.497 E.36185
G1 X112.438 Y108.497 E.01523
G1 X121.497 Y99.438 E.38339
G1 X121.497 Y98.929 E.01523
G1 X116.725 Y103.7 E.20195
G1 X116.725 Y103.191 E.01523
G1 X121.497 Y98.42 E.20195
G1 X121.497 Y97.911 E.01523
G1 X116.725 Y102.682 E.20195
G1 X116.725 Y102.173 E.01523
G1 X121.173 Y97.725 E.18827
G1 X120.664 Y97.725 E.01523
G1 X116.688 Y101.702 E.1683
G1 X116.179 Y101.702 E.01523
G1 X120.155 Y97.725 E.1683
G1 X119.646 Y97.725 E.01523
G1 X115.67 Y101.702 E.1683
G1 X115.161 Y101.702 E.01523
G1 X119.137 Y97.725 E.1683
G1 X118.629 Y97.725 E.01523
G1 X114.652 Y101.702 E.1683
G1 X114.275 Y101.702 E.01127
G1 X114.275 Y102.078 E.01127
G1 X107.857 Y108.497 E.27163
G1 X108.366 Y108.497 E.01523
G1 X114.275 Y102.587 E.25009
G1 X114.275 Y103.096 E.01523
G1 X108.875 Y108.497 E.22855
G1 X109.384 Y108.497 E.01523
G1 X114.275 Y103.605 E.20701
G1 X114.275 Y104.114 E.01523
G1 X109.893 Y108.497 E.18547
G1 X110.402 Y108.497 E.01523
G1 X114.747 Y104.151 E.1839
G1 X115.256 Y104.151 E.01523
G1 X110.911 Y108.497 E.1839
G1 X111.42 Y108.497 E.01523
G1 X115.765 Y104.151 E.1839
G1 X116.274 Y104.151 E.01523
G1 X111.768 Y108.657 E.1907
G1 E-.8 F1800
G17
G3 Z2 I0 J-1.217 P1  F42000
G1 X107.187 Y108.657 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1667.13
G1 X109.12 Y106.725 E.08178
G1 X108.611 Y106.725 E.01523
G1 X106.839 Y108.497 E.07498
G1 X106.33 Y108.497 E.01523
G1 X108.102 Y106.725 E.07498
G1 X107.593 Y106.725 E.01523
G1 X105.821 Y108.497 E.07498
G1 X105.312 Y108.497 E.01523
G1 X107.084 Y106.725 E.07498
G1 X106.575 Y106.725 E.01523
G1 X104.803 Y108.497 E.07498
G1 X104.294 Y108.497 E.01523
G1 X106.275 Y106.515 E.08385
G1 X106.275 Y106.006 E.01523
G1 X103.785 Y108.497 E.10539
G1 X103.276 Y108.497 E.01523
G1 X106.275 Y105.497 E.12693
G1 X106.275 Y104.989 E.01523
G1 X102.767 Y108.497 E.14847
G1 X102.258 Y108.497 E.01523
G1 X106.275 Y104.48 E.17001
G1 X106.275 Y103.971 E.01523
G1 X101.749 Y108.497 E.19155
G1 X101.24 Y108.497 E.01523
G1 X106.275 Y103.462 E.21309
G1 X106.275 Y102.953 E.01523
G1 X100.731 Y108.497 E.23463
G1 X100.222 Y108.497 E.01523
G1 X106.275 Y102.444 E.25617
G1 X106.275 Y101.935 E.01523
G1 X99.713 Y108.497 E.27771
G1 X99.204 Y108.497 E.01523
G1 X100.976 Y106.725 E.07498
G1 X100.467 Y106.725 E.01523
G1 X98.695 Y108.497 E.07498
G1 X98.186 Y108.497 E.01523
G1 X99.958 Y106.725 E.07498
G1 X99.449 Y106.725 E.01523
G1 X97.677 Y108.497 E.07498
G1 X97.168 Y108.497 E.01523
G1 X98.94 Y106.725 E.07498
G1 X98.431 Y106.725 E.01523
G1 X96.659 Y108.497 E.07498
G1 X96.15 Y108.497 E.01523
G1 X98.275 Y106.372 E.08992
G1 X98.275 Y105.863 E.01523
G1 X95.641 Y108.497 E.11147
M73 P30 R22
G1 X95.132 Y108.497 E.01523
G1 X98.275 Y105.354 E.13301
G1 X98.275 Y104.845 E.01523
G1 X94.623 Y108.497 E.15455
G1 X94.114 Y108.497 E.01523
G1 X98.275 Y104.336 E.17609
G1 X98.275 Y103.827 E.01523
G1 X93.605 Y108.497 E.19763
G1 X93.096 Y108.497 E.01523
G1 X98.275 Y103.318 E.21917
G1 X98.275 Y102.809 E.01523
G1 X92.587 Y108.497 E.24071
G1 X92.079 Y108.497 E.01523
G1 X98.275 Y102.3 E.26225
G1 X98.275 Y101.791 E.01523
G1 X91.57 Y108.497 E.28379
G1 X91.061 Y108.497 E.01523
G1 X98.275 Y101.282 E.30533
G1 X98.275 Y100.773 E.01523
G1 X90.552 Y108.497 E.32687
G1 X90.043 Y108.497 E.01523
G1 X100.814 Y97.725 E.45588
G1 X101.323 Y97.725 E.01523
G1 X98.773 Y100.275 E.10793
G1 X99.282 Y100.275 E.01523
G1 X108.054 Y91.503 E.37123
G1 X108.563 Y91.503 E.01523
G1 X99.791 Y100.275 E.37123
G1 X100.3 Y100.275 E.01523
G1 X109.072 Y91.503 E.37123
G1 X109.581 Y91.503 E.01523
G1 X100.809 Y100.275 E.37123
G1 X101.318 Y100.275 E.01523
G1 X110.09 Y91.503 E.37123
G1 X110.599 Y91.503 E.01523
G1 X101.725 Y100.377 E.37555
G1 X101.725 Y100.886 E.01523
G1 X111.108 Y91.503 E.39709
G1 X111.617 Y91.503 E.01523
G1 X101.725 Y101.395 E.41863
G1 X101.725 Y101.904 E.01523
G1 X112.126 Y91.503 E.44017
G1 X112.635 Y91.503 E.01523
G1 X101.725 Y102.413 E.46172
G1 X101.725 Y102.922 E.01523
G1 X113.144 Y91.503 E.48326
G1 X113.653 Y91.503 E.01523
G1 X101.725 Y103.431 E.5048
G1 X101.725 Y103.94 E.01523
G1 X114.161 Y91.503 E.52634
G1 X114.67 Y91.503 E.01523
G1 X101.725 Y104.449 E.54788
G1 X101.725 Y104.958 E.01523
G1 X115.179 Y91.503 E.56942
G1 X115.688 Y91.503 E.01523
G1 X106.917 Y100.275 E.37123
G1 X107.426 Y100.275 E.01523
G1 X116.197 Y91.503 E.37123
G1 X116.706 Y91.503 E.01523
G1 X107.935 Y100.275 E.37123
G1 X108.444 Y100.275 E.01523
G1 X117.215 Y91.503 E.37123
G1 X117.724 Y91.503 E.01523
G1 X108.953 Y100.275 E.37123
G1 X109.462 Y100.275 E.01523
G1 X118.233 Y91.503 E.37123
G1 X118.275 Y91.503 E.00125
G1 X118.275 Y91.971 E.01398
G1 X109.725 Y100.521 E.36186
G1 X109.725 Y101.03 E.01523
G1 X118.275 Y92.48 E.36186
G1 X118.275 Y92.989 E.01523
G1 X109.725 Y101.539 E.36186
G1 X109.725 Y102.048 E.01523
G1 X118.275 Y93.497 E.36186
G1 X118.275 Y94.006 E.01523
G1 X109.725 Y102.557 E.36186
G1 X109.725 Y103.066 E.01523
G1 X118.275 Y94.515 E.36186
G1 X118.275 Y95.024 E.01523
G1 X109.725 Y103.575 E.36186
G1 X109.725 Y104.084 E.01523
M73 P31 R22
G1 X118.275 Y95.533 E.36186
G1 X118.275 Y96.042 E.01523
G1 X109.725 Y104.593 E.36186
G1 X109.725 Y105.102 E.01523
G1 X118.275 Y96.551 E.36186
G1 X118.275 Y97.06 E.01523
G1 X109.725 Y105.611 E.36186
G1 X109.725 Y106.12 E.01523
G1 X118.436 Y97.409 E.36866
G1 E-.8 F1800
G17
G3 Z2 I.815 J.904 P1  F42000
G1 X120.011 Y95.989 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40786
G1 F1644.106
M204 S6000
G1 X120.011 Y93.049 E.08921
M204 S500
G1 X119.65 Y96.35 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.35 E.02144
G1 X120.372 Y92.628 E.11051
G1 X119.65 Y92.628 E.02144
G1 X119.65 Y96.29 E.10873
M204 S500
G1 X119.293 Y96.707 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.707 E.04264
G1 X120.729 Y92.271 E.13171
G1 X119.293 Y92.271 E.04264
G1 X119.293 Y96.647 E.12993
M204 S500
G1 X118.936 Y97.064 F42000
M73 P31 R21
G1 F1680.343
M204 S6000
G1 X121.086 Y97.064 E.06384
G1 X121.086 Y91.914 E.15291
G1 X118.936 Y91.914 E.06384
G1 X118.936 Y97.004 E.15113
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.718 J-.982 P1  F42000
G1 X108 Y105 Z2
G1 Z1.6
G1 E.8 F1800
; LINE_WIDTH: 0.38638
G1 F1746.928
M204 S6000
G1 X108 Y102.06 E.08396
M204 S500
G1 X107.65 Y101.65 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.65 Y105.35 E.10987
G1 X108.35 Y105.35 E.0208
G1 X108.35 Y101.65 E.10987
G1 X107.71 Y101.65 E.01902
M204 S500
G1 X107.293 Y101.293 F42000
G1 F1680.343
M204 S6000
G1 X107.293 Y105.707 E.13107
G1 X108.707 Y105.707 E.042
G1 X108.707 Y101.293 E.13107
G1 X107.353 Y101.293 E.04022
M204 S500
G1 X106.936 Y100.936 F42000
G1 F1680.343
M204 S6000
G1 X106.936 Y106.064 E.15228
G1 X109.064 Y106.064 E.06321
G1 X109.064 Y100.936 E.15228
G1 X106.996 Y100.936 E.06142
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I.653 J-1.027 P1  F42000
G1 X101.564 Y97.484 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40282
G1 F1667.13
G1 X107.545 Y91.503 E.25311
G1 X107.036 Y91.503 E.01523
G1 X101.725 Y96.814 E.22477
G1 X101.725 Y96.305 E.01523
G1 X106.527 Y91.503 E.20323
G1 X106.018 Y91.503 E.01523
G1 X101.725 Y95.796 E.18169
G1 X101.725 Y95.287 E.01523
G1 X105.509 Y91.503 E.16015
G1 X105 Y91.503 E.01523
G1 X101.725 Y94.778 E.13861
G1 X101.725 Y94.27 E.01523
G1 X104.491 Y91.503 E.11707
G1 X103.982 Y91.503 E.01523
G1 X101.725 Y93.761 E.09553
G1 X101.725 Y93.252 E.01523
G1 X103.473 Y91.503 E.07398
G1 X102.964 Y91.503 E.01523
G1 X101.725 Y92.743 E.05244
G1 X101.725 Y92.234 E.01523
G1 X102.455 Y91.503 E.0309
G1 X101.946 Y91.503 E.01523
G1 X101.564 Y91.885 E.01616
G1 E-.8 F1800
G17
G3 Z2 I-1.138 J-.432 P1  F42000
G1 X100 Y96 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.38638
G1 F1746.928
M204 S6000
G1 X100 Y93.039 E.08458
M204 S500
G1 X100.35 Y96.35 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.35 Y92.628 E.11051
G1 X99.65 Y92.628 E.0208
G1 X99.65 Y96.35 E.11051
G1 X100.29 Y96.35 E.01902
M204 S500
G1 X100.707 Y96.707 F42000
G1 F1680.343
M204 S6000
G1 X100.707 Y92.271 E.13171
G1 X99.293 Y92.271 E.042
G1 X99.293 Y96.707 E.13171
G1 X100.647 Y96.707 E.04022
M204 S500
G1 X101.064 Y97.064 F42000
G1 F1680.343
M204 S6000
G1 X101.064 Y91.914 E.15291
G1 X98.936 Y91.914 E.06321
G1 X98.936 Y97.064 E.15291
G1 X101.004 Y97.064 E.06142
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-1.207 J-.153 P1  F42000
G1 X100 Y105 Z2
G1 Z1.6
G1 E.8 F1800
; LINE_WIDTH: 0.38638
G1 F1746.928
M204 S6000
G1 X100 Y102.06 E.08396
M204 S500
G1 X99.65 Y101.65 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.65 Y105.35 E.10987
G1 X100.35 Y105.35 E.0208
G1 X100.35 Y101.65 E.10987
G1 X99.71 Y101.65 E.01902
M204 S500
G1 X99.293 Y101.293 F42000
G1 F1680.343
M204 S6000
G1 X99.293 Y105.707 E.13107
G1 X100.707 Y105.707 E.042
G1 X100.707 Y101.293 E.13107
G1 X99.353 Y101.293 E.04022
M204 S500
G1 X98.936 Y100.936 F42000
G1 F1680.343
M204 S6000
G1 X98.936 Y106.064 E.15228
G1 X101.064 Y106.064 E.06321
G1 X101.064 Y100.936 E.15228
G1 X98.996 Y100.936 E.06142
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-1.067 J.584 P1  F42000
G1 X101.564 Y105.628 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40282
G1 F1667.13
G1 X106.275 Y100.917 E.19937
G1 X106.275 Y101.426 E.01523
G1 X101.564 Y106.137 E.19937
G1 E-.8 F1800
G17
G3 Z2 I-.246 J-1.192 P1  F42000
G1 X89.373 Y108.657 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1667.13
G1 X100.305 Y97.725 E.46268
G1 X99.796 Y97.725 E.01523
G1 X89.025 Y108.497 E.45588
G1 X88.516 Y108.497 E.01523
G1 X99.287 Y97.725 E.45588
G1 X98.778 Y97.725 E.01523
G1 X88.007 Y108.497 E.45588
G1 X87.498 Y108.497 E.01523
G1 X98.275 Y97.719 E.45611
G1 X98.275 Y97.21 E.01523
G1 X86.989 Y108.497 E.47766
G1 X86.48 Y108.497 E.01523
M73 P32 R21
G1 X98.275 Y96.701 E.4992
G1 X98.275 Y96.192 E.01523
G1 X85.971 Y108.497 E.52074
G1 X85.462 Y108.497 E.01523
G1 X98.275 Y95.683 E.54228
G1 X98.275 Y95.174 E.01523
G1 X84.953 Y108.497 E.56382
G1 X84.444 Y108.497 E.01523
G1 X98.275 Y94.665 E.58536
G1 X98.275 Y94.156 E.01523
G1 X83.935 Y108.497 E.6069
G1 X83.426 Y108.497 E.01523
G1 X98.275 Y93.647 E.62844
G1 X98.275 Y93.138 E.01523
G1 X82.917 Y108.497 E.64998
G1 X82.408 Y108.497 E.01523
G1 X98.275 Y92.629 E.67152
G1 X98.275 Y92.121 E.01523
G1 X81.899 Y108.497 E.69306
G1 X81.39 Y108.497 E.01523
G1 X83.162 Y106.725 E.07498
G1 X82.653 Y106.725 E.01523
G1 X80.881 Y108.497 E.07498
G1 X80.372 Y108.497 E.01523
G1 X82.144 Y106.725 E.07498
G1 X81.635 Y106.725 E.01523
G1 X79.863 Y108.497 E.07498
G1 X79.354 Y108.497 E.01523
G1 X81.126 Y106.725 E.07498
G1 X80.617 Y106.725 E.01523
G1 X78.845 Y108.497 E.07498
G1 X78.503 Y108.497 E.01023
G1 X78.503 Y108.329 E.005
G1 X80.108 Y106.725 E.06791
G1 X79.599 Y106.725 E.01523
G1 X78.503 Y107.82 E.04637
G1 X78.503 Y107.311 E.01523
G1 X79.09 Y106.725 E.02483
G1 X78.581 Y106.725 E.01523
G1 X78.343 Y106.963 E.01008
G1 E-.8 F1800
G17
G3 Z2 I.148 J1.208 P1  F42000
G1 X83.564 Y106.322 Z2
G1 Z1.6
G1 E.8 F1800
G1 F1667.13
G1 X98.275 Y91.612 E.62259
G1 X98.275 Y91.503 E.00324
G1 X97.874 Y91.503 E.012
G1 X83.725 Y105.653 E.59882
G1 X83.725 Y105.144 E.01523
G1 X97.365 Y91.503 E.57728
G1 X96.856 Y91.503 E.01523
G1 X83.725 Y104.635 E.55574
G1 X83.725 Y104.126 E.01523
G1 X96.347 Y91.503 E.5342
G1 X95.838 Y91.503 E.01523
G1 X83.725 Y103.617 E.51266
G1 X83.725 Y103.108 E.01523
G1 X95.329 Y91.503 E.49112
G1 X94.82 Y91.503 E.01523
G1 X83.725 Y102.599 E.46958
G1 X83.725 Y102.09 E.01523
G1 X94.311 Y91.503 E.44804
G1 X93.802 Y91.503 E.01523
G1 X83.725 Y101.581 E.4265
G1 X83.725 Y101.072 E.01523
G1 X93.293 Y91.503 E.40496
G1 X92.785 Y91.503 E.01523
G1 X83.725 Y100.563 E.38342
G1 X83.725 Y100.054 E.01523
G1 X92.276 Y91.503 E.36188
G1 X91.767 Y91.503 E.01523
G1 X83.725 Y99.545 E.34034
G1 X83.725 Y99.036 E.01523
G1 X91.258 Y91.503 E.3188
G1 X90.749 Y91.503 E.01523
G1 X83.725 Y98.527 E.29726
G1 X83.725 Y98.018 E.01523
M73 P33 R21
G1 X90.24 Y91.503 E.27572
G1 X89.731 Y91.503 E.01523
G1 X83.725 Y97.509 E.25417
G1 X83.725 Y97 E.01523
G1 X89.222 Y91.503 E.23263
G1 X88.713 Y91.503 E.01523
G1 X83.725 Y96.491 E.21109
G1 X83.725 Y95.982 E.01523
G1 X88.204 Y91.503 E.18955
G1 X87.695 Y91.503 E.01523
G1 X83.725 Y95.473 E.16801
G1 X83.725 Y94.964 E.01523
G1 X87.186 Y91.503 E.14647
G1 X86.677 Y91.503 E.01523
G1 X83.725 Y94.455 E.12493
G1 X83.725 Y93.946 E.01523
G1 X86.168 Y91.503 E.10339
G1 X85.659 Y91.503 E.01523
G1 X83.725 Y93.437 E.08185
G1 X83.725 Y92.928 E.01523
G1 X85.15 Y91.503 E.06031
G1 X84.641 Y91.503 E.01523
G1 X83.725 Y92.419 E.03877
G1 X83.725 Y91.91 E.01523
G1 X84.293 Y91.343 E.02403
G1 E-.8 F1800
G17
G3 Z2 I-1.025 J-.656 P1  F42000
G1 X83.118 Y93.176 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.118 Y94.605 E.04241
G1 X78.861 Y95.745 E.13087
G1 X78.861 Y92.41 E.09903
G1 X83.118 Y96.668 E.17877
G1 X83.118 Y96.549 E.00352
G1 X80.554 Y106.118 E.29413
G1 X81.539 Y106.118 E.02924
G1 X83.118 Y105.695 E.04855
G1 X83.118 Y104.242 E.04312
G1 X78.861 Y99.985 E.17877
G1 X78.861 Y101.29 E.03876
G1 X83.118 Y100.15 E.13087
G1 X83.118 Y101.578 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.2
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-1.214 J.081 P1  F42000
G1 X83.443 Y106.443 Z2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z2.2 I1.217 J0 P1  F42000
G1 X83.139 Y101.719
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y100.29 E.04241
G1 X78.861 Y101.437 E.13153
G1 X78.861 Y99.785 E.04905
G1 X83.139 Y104.064 E.17967
G1 X83.139 Y105.835 E.0526
G1 X82.005 Y106.139 E.03487
G1 X80.402 Y106.139 E.0476
G1 X83.139 Y95.923 E.31405
G1 X83.139 Y94.745 E.03496
G1 X78.861 Y95.892 E.13153
G1 X78.861 Y92.21 E.10931
G1 X83.139 Y96.489 E.17967
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.063 J1.215 P1  F42000
G1 X101.443 Y97.443 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z2.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z2.2 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
M73 P34 R21
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z2.2 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.442 J1.134 P1  F42000
G1 X114.557 Y103.869 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y101.984 E.05599
G1 X116.443 Y101.984 E.05599
G1 X116.443 Y102.926 E.028
G1 X116.443 Y103.869 E.028
G1 X114.617 Y103.869 E.05421
M204 S250
G1 X114.2 Y104.226 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y101.626 E.0772
G1 X116.8 Y101.626 E.0772
G1 X116.8 Y102.926 E.0386
G1 X116.8 Y104.226 E.0386
G1 X114.26 Y104.226 E.07541
G1 X114.914 Y102.341 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y103.512 E.03479
G1 X116.086 Y103.512 E.03479
G1 X116.086 Y102.341 E.03479
G1 X114.974 Y102.341 E.03301
M204 S500
G1 X115.296 Y102.723 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y103.13 E.0138
G1 X115.704 Y103.13 E.0138
G1 X115.704 Y102.723 E.0138
G1 X115.356 Y102.723 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.597 J1.06 P1  F42000
G1 X119.557 Y105.089 Z2.2
M73 P34 R20
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X119.557 Y104.203 E.0263
G1 X121.443 Y104.203 E.05599
G1 X121.443 Y104.646 E.01315
G1 X121.443 Y105.089 E.01315
G1 X119.617 Y105.089 E.05421
M204 S250
G1 X119.2 Y105.446 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X119.2 Y103.846 E.04751
G1 X121.8 Y103.846 E.0772
G1 X121.8 Y104.646 E.02375
G1 X121.8 Y105.446 E.02375
G1 X119.26 Y105.446 E.07541
G1 X120 Y104.646 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57172
G1 F1134.644
M204 S6000
G1 X120.94 Y104.646 E.04133
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I1.155 J-.382 P1  F42000
G1 X118.557 Y97.443 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z2.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.312 J-1.176 P1  F42000
G1 X83.443 Y106.443 Z2.2
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z2.4 I1.217 J0 P1  F42000
G1 X83.139 Y99.008
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y100.437 E.04241
G1 X78.861 Y101.583 E.13153
G1 X78.861 Y99.585 E.05933
G1 X83.139 Y103.864 E.17967
G1 X83.139 Y105.982 E.06289
G1 X82.551 Y106.139 E.01808
G1 X80.255 Y106.139 E.06817
G1 X83.139 Y95.376 E.33085
G1 X83.139 Y94.892 E.01439
G1 X78.861 Y96.038 E.13153
G1 X78.861 Y92.01 E.1196
G1 X83.139 Y96.289 E.17967
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.077 J1.215 P1  F42000
G1 X101.443 Y97.443 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
M73 P35 R20
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z2.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z2.4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z2.4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.463 J1.125 P1  F42000
G1 X114.557 Y104.037 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.151 E.05599
G1 X116.443 Y102.151 E.05599
G1 X116.443 Y103.094 E.028
G1 X116.443 Y104.037 E.028
G1 X114.617 Y104.037 E.05421
M204 S250
G1 X114.2 Y104.289 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.099 E.00562
G1 X114.2 Y103.91 E.00562
G1 X114.2 Y103.72 E.00562
G1 X114.2 Y103.531 E.00562
G1 X114.2 Y103.341 E.00562
G1 X114.2 Y103.152 E.00562
G1 X114.2 Y102.963 E.00562
G1 X114.2 Y102.773 E.00562
G1 X114.2 Y102.584 E.00562
G1 X114.2 Y101.794 E.02344
G1 X116.8 Y101.794 E.0772
G1 X116.8 Y103.094 E.0386
G1 X116.8 Y103.217 E.00366
G1 X116.8 Y103.341 E.00366
G1 X116.8 Y103.464 E.00366
G1 X116.8 Y103.587 E.00366
G1 X116.8 Y103.71 E.00366
G1 X116.8 Y103.833 E.00366
G1 X116.8 Y103.956 E.00366
G1 X116.8 Y104.079 E.00366
G1 X116.8 Y104.202 E.00366
G1 X116.8 Y104.326 E.00366
G1 X116.8 Y104.394 E.00204
G1 X114.2 Y104.394 E.0772
G1 X114.2 Y104.349 E.00136
G1 X114.914 Y102.508 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y103.68 E.03479
G1 X116.086 Y103.68 E.03479
G1 X116.086 Y102.508 E.03479
G1 X114.974 Y102.508 E.03301
M204 S500
G1 X115.296 Y102.891 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y103.298 E.0138
G1 X115.704 Y103.298 E.0138
G1 X115.704 Y102.891 E.0138
G1 X115.356 Y102.891 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.474 J1.121 P1  F42000
G1 X119.557 Y104.667 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X119.557 Y104.632 E.00106
G1 X121.443 Y104.632 E.05599
G1 X121.443 Y105.075 E.01315
G1 X121.443 Y105.162 E.00258
G1 X121.443 Y105.248 E.00258
G1 X121.443 Y105.335 E.00258
G1 X121.443 Y105.422 E.00258
G1 X121.443 Y105.509 E.00258
G1 X119.557 Y105.518 E.05599
G1 X119.557 Y105.501 E.00049
G1 X119.557 Y105.327 E.00516
G1 X119.557 Y105.153 E.00516
G1 X119.557 Y104.979 E.00516
G1 X119.557 Y104.806 E.00516
G1 X119.557 Y104.727 E.00232
M204 S250
G1 X119.2 Y104.667 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X119.2 Y104.589 E.00233
G1 X119.2 Y104.51 E.00233
G1 X119.2 Y104.432 E.00233
G1 X119.2 Y104.353 E.00233
G1 X119.2 Y104.275 E.00233
G1 X121.8 Y104.275 E.0772
G1 X121.8 Y105.075 E.02375
G1 X121.8 Y105.113 E.00114
G1 X121.8 Y105.152 E.00114
G1 X121.8 Y105.19 E.00114
G1 X121.8 Y105.229 E.00114
G1 X121.8 Y105.267 E.00114
G1 X121.8 Y105.306 E.00114
G1 X121.8 Y105.344 E.00114
G1 X121.8 Y105.383 E.00114
G1 X121.8 Y105.422 E.00114
G1 X121.8 Y105.46 E.00114
G1 X121.8 Y105.499 E.00114
G1 X121.8 Y105.537 E.00114
G1 X121.8 Y105.576 E.00114
G1 X121.8 Y105.614 E.00114
G1 F1642.025
G1 X121.8 Y105.653 E.00114
G1 F1432.705
G1 X121.8 Y105.691 E.00114
G1 F1237.602
G1 X121.8 Y105.73 E.00114
G1 F1056.819
G1 X121.8 Y105.769 E.00114
G1 F890.261
G1 X121.8 Y105.807 E.00114
G1 F738.014
G1 X121.8 Y105.846 E.00114
; FEATURE: Overhang wall
M106 S255
G1 F600
G1 X121.8 Y105.875 E.00086
G1 X119.2 Y105.875 E.0772
G1 X119.2 Y105.846 E.00086
M106 S193.8
; FEATURE: Outer wall
G1 F896.224
G1 X119.2 Y105.767 E.00233
G1 F1251.73
G1 X119.2 Y105.689 E.00233
G1 F1666.428
G1 X119.2 Y105.61 E.00233
G1 F1680.343
G1 X119.2 Y105.531 E.00233
G1 X119.2 Y105.453 E.00233
G1 X119.2 Y105.374 E.00233
G1 X119.2 Y105.296 E.00233
G1 X119.2 Y105.217 E.00233
G1 X119.2 Y105.139 E.00233
G1 X119.2 Y105.06 E.00233
G1 X119.2 Y104.982 E.00233
G1 X119.2 Y104.903 E.00233
G1 X119.2 Y104.824 E.00233
G1 X119.2 Y104.746 E.00233
G1 X119.2 Y104.727 E.00055
G1 X120 Y105.075 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57172
G1 F1134.644
M204 S6000
G1 X120.94 Y105.075 E.04133
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I1.162 J-.363 P1  F42000
G1 X118.557 Y97.443 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z2.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.312 J-1.176 P1  F42000
G1 X83.443 Y106.443 Z2.4
G1 Z2.2
M73 P36 R20
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z2.6 I1.217 J0 P1  F42000
G1 X83.139 Y105.092
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y103.664 E.04241
G1 X78.861 Y99.385 E.17967
G1 X78.861 Y101.73 E.06962
G1 X83.139 Y100.583 E.13153
G1 X83.139 Y96.089 E.13344
G1 X78.911 Y91.861 E.17755
G1 X78.861 Y91.861 E.0015
G1 X78.861 Y96.185 E.12838
G1 X83.139 Y95.038 E.13153
G1 X83.139 Y94.83 E.00618
G1 X80.109 Y106.139 E.34764
G1 X78.861 Y106.139 E.03707
G1 X78.861 Y105.96 E.00534
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I.429 J1.139 P1  F42000
G1 X101.443 Y97.443 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z2.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z2.6 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z2.6 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I-.484 J1.116 P1  F42000
G1 X114.557 Y104.205 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.319 E.05599
G1 X116.443 Y102.319 E.05599
G1 X116.443 Y103.262 E.028
G1 X116.443 Y104.205 E.028
G1 X114.617 Y104.205 E.05421
M204 S250
M73 P37 R20
G1 X114.2 Y104.267 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.078 E.00562
G1 X114.2 Y103.888 E.00562
G1 X114.2 Y103.699 E.00562
G1 X114.2 Y103.509 E.00562
G1 X114.2 Y103.32 E.00562
G1 X114.2 Y103.13 E.00562
G1 X114.2 Y102.941 E.00562
G1 X114.2 Y102.752 E.00562
G1 X114.2 Y101.962 E.02344
G1 X116.8 Y101.962 E.0772
G1 X116.8 Y103.262 E.0386
G1 X116.8 Y103.385 E.00366
G1 X116.8 Y103.508 E.00366
G1 X116.8 Y103.632 E.00366
G1 X116.8 Y103.755 E.00366
G1 X116.8 Y103.878 E.00366
G1 X116.8 Y104.001 E.00366
G1 X116.8 Y104.124 E.00366
G1 X116.8 Y104.247 E.00366
G1 X116.8 Y104.37 E.00366
G1 X116.8 Y104.493 E.00366
G1 X116.8 Y104.562 E.00204
G1 X114.2 Y104.562 E.0772
G1 X114.2 Y104.456 E.00314
G1 X114.2 Y104.327 E.00384
G1 X114.914 Y102.676 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y103.848 E.03479
G1 X116.086 Y103.848 E.03479
G1 X116.086 Y102.676 E.03479
G1 X114.974 Y102.676 E.03301
M204 S500
G1 X115.296 Y103.058 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y103.466 E.0138
G1 X115.704 Y103.466 E.0138
G1 X115.704 Y103.058 E.0138
G1 X115.356 Y103.058 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I-.531 J1.095 P1  F42000
G1 X119.557 Y105.096 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X119.557 Y105.061 E.00106
G1 X121.443 Y105.061 E.05599
G1 X121.443 Y105.503 E.01315
G1 X121.443 Y105.59 E.00258
G1 X121.443 Y105.677 E.00258
G1 X121.443 Y105.764 E.00258
G1 X121.443 Y105.851 E.00258
G1 X121.443 Y105.938 E.00258
G1 X119.557 Y105.946 E.05599
G1 X119.557 Y105.93 E.00049
G1 X119.557 Y105.756 E.00516
G1 X119.557 Y105.582 E.00516
G1 X119.557 Y105.408 E.00516
G1 X119.557 Y105.234 E.00516
G1 X119.557 Y105.156 E.00232
M204 S250
G1 X119.2 Y105.096 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X119.2 Y105.018 E.00233
G1 X119.2 Y104.939 E.00233
G1 X119.2 Y104.861 E.00233
G1 X119.2 Y104.782 E.00233
G1 X119.2 Y104.703 E.00233
G1 X121.8 Y104.703 E.0772
G1 X121.8 Y105.503 E.02375
G1 X121.8 Y105.542 E.00114
G1 X121.8 Y105.581 E.00114
G1 X121.8 Y105.619 E.00114
G1 X121.8 Y105.658 E.00114
G1 X121.8 Y105.696 E.00114
G1 X121.8 Y105.735 E.00114
G1 X121.8 Y105.773 E.00114
G1 X121.8 Y105.812 E.00114
G1 X121.8 Y105.85 E.00114
G1 X121.8 Y105.889 E.00114
G1 X121.8 Y105.928 E.00114
G1 X121.8 Y105.966 E.00114
G1 X121.8 Y106.005 E.00114
G1 X121.8 Y106.043 E.00114
G1 F1642.025
G1 X121.8 Y106.082 E.00114
G1 F1432.705
G1 X121.8 Y106.12 E.00114
G1 F1237.602
G1 X121.8 Y106.159 E.00114
G1 F1056.819
G1 X121.8 Y106.197 E.00114
G1 F890.261
G1 X121.8 Y106.236 E.00114
G1 F738.014
G1 X121.8 Y106.275 E.00114
; FEATURE: Overhang wall
M106 S255
G1 F600
G1 X121.8 Y106.303 E.00086
G1 X119.2 Y106.303 E.0772
G1 X119.2 Y106.275 E.00086
M106 S193.8
; FEATURE: Outer wall
G1 F896.224
G1 X119.2 Y106.196 E.00233
G1 F1251.681
G1 X119.2 Y106.117 E.00233
G1 F1666.428
G1 X119.2 Y106.039 E.00233
G1 F1680.343
G1 X119.2 Y105.96 E.00233
G1 X119.2 Y105.882 E.00233
G1 X119.2 Y105.803 E.00233
G1 X119.2 Y105.725 E.00233
G1 X119.2 Y105.646 E.00233
G1 X119.2 Y105.568 E.00233
G1 X119.2 Y105.489 E.00233
G1 X119.2 Y105.41 E.00233
G1 X119.2 Y105.332 E.00233
G1 X119.2 Y105.253 E.00233
G1 X119.2 Y105.175 E.00233
G1 X119.2 Y105.156 E.00055
G1 X120 Y105.503 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57172
G1 F1134.644
M204 S6000
G1 X120.94 Y105.503 E.04133
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I1.167 J-.345 P1  F42000
G1 X118.557 Y97.443 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z2.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I-.312 J-1.176 P1  F42000
G1 X83.443 Y106.443 Z2.6
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
M73 P37 R19
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z2.8 I1.217 J0 P1  F42000
G1 X83.139 Y95.184
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y96.331 E.13153
G1 X78.861 Y91.861 E.13273
G1 X79.111 Y91.861 E.00743
G1 X83.139 Y95.889 E.16915
G1 X83.139 Y100.73 E.14372
G1 X78.861 Y101.876 E.13153
G1 X78.861 Y99.185 E.0799
G1 X83.139 Y103.464 E.17967
G1 X83.139 Y106.139 E.07944
G1 X79.963 Y106.139 E.09432
G1 X83.139 Y94.283 E.36444
G1 X83.139 Y92.855 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-.296 J1.18 P1  F42000
G1 X101.443 Y97.443 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z2.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
M73 P38 R19
G1 E-.8 F1800
G17
G3 Z2.8 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z2.8 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-.505 J1.107 P1  F42000
G1 X114.557 Y104.373 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.487 E.05599
G1 X116.443 Y102.487 E.05599
G1 X116.443 Y103.43 E.028
G1 X116.443 Y104.373 E.028
G1 X114.617 Y104.373 E.05421
M204 S250
G1 X114.2 Y104.435 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.245 E.00562
G1 X114.2 Y104.056 E.00562
G1 X114.2 Y103.866 E.00562
G1 X114.2 Y103.677 E.00562
G1 X114.2 Y103.488 E.00562
G1 X114.2 Y103.298 E.00562
G1 X114.2 Y103.109 E.00562
G1 X114.2 Y102.919 E.00562
G1 X114.2 Y102.13 E.02344
G1 X116.8 Y102.13 E.0772
G1 X116.8 Y103.43 E.0386
G1 X116.8 Y103.553 E.00366
G1 X116.8 Y103.676 E.00366
G1 X116.8 Y103.799 E.00366
G1 X116.8 Y103.922 E.00366
G1 X116.8 Y104.046 E.00366
G1 X116.8 Y104.169 E.00366
G1 X116.8 Y104.292 E.00366
G1 X116.8 Y104.415 E.00366
G1 X116.8 Y104.538 E.00366
G1 X116.8 Y104.661 E.00366
G1 X116.8 Y104.73 E.00204
G1 X114.2 Y104.73 E.0772
G1 X114.2 Y104.624 E.00314
G1 X114.2 Y104.495 E.00384
G1 X114.914 Y102.844 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.016 E.03479
G1 X116.086 Y104.016 E.03479
G1 X116.086 Y102.844 E.03479
G1 X114.974 Y102.844 E.03301
M204 S500
G1 X115.296 Y103.226 F42000
; LINE_WIDTH: 0.45026
G1 F1472.971
M204 S6000
G1 X115.296 Y103.634 E.0138
G1 X115.704 Y103.634 E.0138
G1 X115.704 Y103.226 E.0138
G1 X115.356 Y103.226 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-.584 J1.068 P1  F42000
G1 X119.557 Y105.525 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X119.557 Y105.489 E.00106
G1 X121.443 Y105.489 E.05599
G1 X121.443 Y105.932 E.01315
G1 X121.443 Y106.019 E.00258
G1 X121.443 Y106.106 E.00258
G1 X121.443 Y106.193 E.00258
G1 X121.443 Y106.28 E.00258
G1 X121.443 Y106.367 E.00258
G1 X119.557 Y106.375 E.05599
G1 X119.557 Y106.359 E.0005
G1 X119.557 Y106.185 E.00516
G1 X119.557 Y106.011 E.00516
G1 X119.557 Y105.837 E.00516
G1 X119.557 Y105.663 E.00516
G1 X119.557 Y105.585 E.00232
M204 S250
G1 X119.2 Y105.525 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X119.2 Y105.447 E.00233
G1 X119.2 Y105.368 E.00233
G1 X119.2 Y105.289 E.00233
G1 X119.2 Y105.211 E.00233
G1 X119.2 Y105.132 E.00233
G1 X121.8 Y105.132 E.0772
G1 X121.8 Y105.932 E.02375
G1 X121.8 Y105.971 E.00114
G1 X121.8 Y106.009 E.00114
G1 X121.8 Y106.048 E.00114
G1 X121.8 Y106.087 E.00114
G1 X121.8 Y106.125 E.00114
G1 X121.8 Y106.164 E.00114
G1 X121.8 Y106.202 E.00114
G1 X121.8 Y106.241 E.00114
G1 X121.8 Y106.279 E.00114
G1 X121.8 Y106.318 E.00114
G1 X121.8 Y106.356 E.00114
G1 X121.8 Y106.395 E.00114
G1 X121.8 Y106.434 E.00114
G1 X121.8 Y106.472 E.00114
G1 F1642.025
G1 X121.8 Y106.511 E.00114
G1 F1432.705
G1 X121.8 Y106.549 E.00114
G1 F1237.602
G1 X121.8 Y106.588 E.00114
G1 F1056.819
G1 X121.8 Y106.626 E.00114
G1 F890.261
G1 X121.8 Y106.665 E.00114
G1 F738.014
G1 X121.8 Y106.703 E.00114
; FEATURE: Overhang wall
M106 S255
G1 F600
G1 X121.8 Y106.732 E.00086
G1 X119.2 Y106.732 E.0772
G1 X119.2 Y106.703 E.00086
M106 S193.8
; FEATURE: Outer wall
G1 F896.224
G1 X119.2 Y106.625 E.00233
G1 F1251.681
G1 X119.2 Y106.546 E.00233
G1 F1666.428
G1 X119.2 Y106.468 E.00233
G1 F1680.343
G1 X119.2 Y106.389 E.00233
G1 X119.2 Y106.311 E.00233
G1 X119.2 Y106.232 E.00233
G1 X119.2 Y106.154 E.00233
G1 X119.2 Y106.075 E.00233
G1 X119.2 Y105.996 E.00233
G1 X119.2 Y105.918 E.00233
G1 X119.2 Y105.839 E.00233
G1 X119.2 Y105.761 E.00233
G1 X119.2 Y105.682 E.00233
G1 X119.2 Y105.604 E.00233
G1 X119.2 Y105.585 E.00055
G1 X119.916 Y106.233 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.44452
G1 F1494.024
G1 X120.355 Y105.793 E.02076
G1 X120.923 Y105.793 E.01897
G1 X120.484 Y106.233 E.02076
G1 E-.8 F1800
G17
G3 Z2.8 I1.189 J-.261 P1  F42000
G1 X118.557 Y97.443 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z2.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-.312 J-1.176 P1  F42000
G1 X83.443 Y106.443 Z2.8
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z3 I1.217 J0 P1  F42000
G1 X83.139 Y92.309
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.737 E.04241
G1 X79.816 Y106.139 E.38123
G1 X78.861 Y106.139 E.02837
G1 X78.861 Y102.022 E.12224
G1 X83.139 Y100.876 E.13153
M73 P39 R19
G1 X83.139 Y103.264 E.0709
G1 X78.861 Y98.985 E.17967
G1 X78.861 Y96.477 E.07445
G1 X83.139 Y95.331 E.13153
G1 X83.139 Y95.689 E.01064
G1 X79.311 Y91.861 E.16076
G1 X80.739 Y91.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I-.317 J1.175 P1  F42000
G1 X101.443 Y97.443 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z3 I.846 J-.875 P1  F42000
G1 X100 Y96 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z3 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z3 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I-.525 J1.098 P1  F42000
G1 X114.557 Y104.541 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.655 E.05599
G1 X116.443 Y102.655 E.05599
G1 X116.443 Y103.598 E.028
G1 X116.443 Y104.541 E.028
G1 X114.617 Y104.541 E.05421
M204 S250
G1 X114.2 Y104.792 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.603 E.00562
G1 X114.2 Y104.413 E.00562
G1 X114.2 Y104.224 E.00562
G1 X114.2 Y104.034 E.00562
G1 X114.2 Y103.845 E.00562
G1 X114.2 Y103.655 E.00562
G1 X114.2 Y103.466 E.00562
G1 X114.2 Y103.277 E.00562
G1 X114.2 Y103.087 E.00562
G1 X114.2 Y102.298 E.02344
G1 X116.8 Y102.298 E.0772
G1 X116.8 Y103.598 E.0386
G1 X116.8 Y103.721 E.00366
G1 X116.8 Y103.844 E.00366
G1 X116.8 Y103.967 E.00366
G1 X116.8 Y104.09 E.00366
G1 X116.8 Y104.213 E.00366
G1 X116.8 Y104.337 E.00366
G1 X116.8 Y104.46 E.00366
G1 X116.8 Y104.583 E.00366
G1 X116.8 Y104.706 E.00366
G1 X116.8 Y104.829 E.00366
G1 X116.8 Y104.898 E.00204
G1 X114.2 Y104.898 E.0772
G1 X114.2 Y104.852 E.00136
G1 X114.914 Y103.012 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.184 E.03479
G1 X116.086 Y104.184 E.03479
G1 X116.086 Y103.012 E.03479
G1 X114.974 Y103.012 E.03301
M204 S500
G1 X115.296 Y103.394 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y103.801 E.0138
G1 X115.704 Y103.801 E.0138
G1 X115.704 Y103.394 E.0138
G1 X115.356 Y103.394 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I1.072 J.576 P1  F42000
G1 X118.557 Y97.443 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z3 I.875 J.846 P1  F42000
G1 X120 Y96 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
M73 P40 R19
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z3.2 I1.217 J0 P1  F42000
G1 X83.041 Y91.861
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y91.861 E.00292
G1 X83.139 Y93.191 E.03949
G1 X79.67 Y106.139 E.39803
G1 X78.861 Y106.139 E.02403
G1 X78.861 Y102.169 E.11789
G1 X83.139 Y101.022 E.13153
G1 X83.139 Y103.064 E.06061
G1 X78.861 Y98.785 E.17967
G1 X78.861 Y96.624 E.06417
G1 X83.139 Y95.477 E.13153
G1 X83.139 Y95.489 E.00035
G1 X79.511 Y91.861 E.15236
G1 X78.861 Y91.861 E.01931
G1 X78.861 Y92.638 E.0231
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I-.253 J1.19 P1  F42000
G1 X101.443 Y97.443 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z3.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z3.2
G1 Z2.8
M73 P40 R18
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z3.2 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z3.2 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
M73 P41 R18
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I-.545 J1.088 P1  F42000
G1 X114.557 Y104.709 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.823 E.05599
G1 X116.443 Y102.823 E.05599
G1 X116.443 Y103.766 E.028
G1 X116.443 Y104.709 E.028
G1 X114.617 Y104.709 E.05421
M204 S250
G1 X114.2 Y104.77 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.581 E.00562
G1 X114.2 Y104.392 E.00562
G1 X114.2 Y104.202 E.00562
G1 X114.2 Y104.013 E.00562
G1 X114.2 Y103.823 E.00562
G1 X114.2 Y103.634 E.00562
G1 X114.2 Y103.444 E.00562
G1 X114.2 Y103.255 E.00562
G1 X114.2 Y102.466 E.02344
G1 X116.8 Y102.466 E.0772
G1 X116.8 Y103.766 E.0386
G1 X116.8 Y103.889 E.00366
G1 X116.8 Y104.012 E.00366
G1 X116.8 Y104.135 E.00366
G1 X116.8 Y104.258 E.00366
G1 X116.8 Y104.381 E.00366
G1 X116.8 Y104.504 E.00366
G1 X116.8 Y104.627 E.00366
G1 X116.8 Y104.751 E.00366
G1 X116.8 Y104.874 E.00366
G1 X116.8 Y104.997 E.00366
G1 X116.8 Y105.066 E.00204
G1 X114.2 Y105.066 E.0772
G1 X114.2 Y104.96 E.00314
G1 X114.2 Y104.83 E.00384
G1 X114.914 Y103.18 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.351 E.03479
G1 X116.086 Y104.351 E.03479
G1 X116.086 Y103.18 E.03479
G1 X114.974 Y103.18 E.03301
M204 S500
G1 X115.296 Y103.562 F42000
; LINE_WIDTH: 0.45026
G1 F1472.971
M204 S6000
G1 X115.296 Y103.969 E.0138
G1 X115.704 Y103.969 E.0138
G1 X115.704 Y103.562 E.0138
G1 X115.356 Y103.562 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I1.078 J.564 P1  F42000
G1 X118.557 Y97.443 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z3.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z3.2
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z3.4 I1.217 J0 P1  F42000
G1 X78.861 Y103.744
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y102.315 E.04241
G1 X83.139 Y101.169 E.13153
G1 X83.139 Y102.864 E.05033
G1 X78.861 Y98.585 E.17967
G1 X78.861 Y96.77 E.05388
G1 X83.139 Y95.624 E.13153
G1 X83.139 Y95.289 E.00994
G1 X79.711 Y91.861 E.14396
G1 X83.139 Y91.861 E.1018
G1 X83.139 Y92.644 E.02327
G1 X79.523 Y106.139 E.41483
G1 X80.952 Y106.139 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I.475 J1.12 P1  F42000
G1 X101.443 Y97.443 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z3.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z3.4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z3.4
G1 Z3
M73 P42 R18
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z3.4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I-.564 J1.079 P1  F42000
G1 X114.557 Y104.876 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y102.99 E.05599
G1 X116.443 Y102.99 E.05599
G1 X116.443 Y103.933 E.028
G1 X116.443 Y104.876 E.028
G1 X114.617 Y104.876 E.05421
M204 S250
G1 X114.2 Y104.938 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.749 E.00562
G1 X114.2 Y104.559 E.00562
G1 X114.2 Y104.37 E.00562
G1 X114.2 Y104.181 E.00562
G1 X114.2 Y103.991 E.00562
G1 X114.2 Y103.802 E.00562
G1 X114.2 Y103.612 E.00562
G1 X114.2 Y103.423 E.00562
G1 X114.2 Y102.633 E.02344
G1 X116.8 Y102.633 E.0772
G1 X116.8 Y103.933 E.0386
G1 X116.8 Y104.057 E.00366
G1 X116.8 Y104.18 E.00366
G1 X116.8 Y104.303 E.00366
G1 X116.8 Y104.426 E.00366
G1 X116.8 Y104.549 E.00366
G1 X116.8 Y104.672 E.00366
G1 X116.8 Y104.795 E.00366
G1 X116.8 Y104.918 E.00366
G1 X116.8 Y105.042 E.00366
G1 X116.8 Y105.165 E.00366
G1 X116.8 Y105.233 E.00204
G1 X114.2 Y105.233 E.0772
G1 X114.2 Y105.128 E.00314
G1 X114.2 Y104.998 E.00384
G1 X114.914 Y103.348 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.519 E.03479
G1 X116.086 Y104.519 E.03479
G1 X116.086 Y103.348 E.03479
G1 X114.974 Y103.348 E.03301
M204 S500
G1 X115.296 Y103.73 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y104.137 E.0138
G1 X115.704 Y104.137 E.0138
G1 X115.704 Y103.73 E.0138
G1 X115.356 Y103.73 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I1.085 J.552 P1  F42000
G1 X118.557 Y97.443 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z3.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z3.4
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z3.6 I1.217 J0 P1  F42000
G1 X78.861 Y101.033
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y102.462 E.04241
G1 X83.139 Y101.315 E.13153
G1 X83.139 Y102.664 E.04004
G1 X78.861 Y98.385 E.17967
G1 X78.861 Y96.917 E.0436
G1 X83.139 Y95.77 E.13153
G1 X83.139 Y95.089 E.02022
G1 X79.911 Y91.861 E.13556
G1 X83.139 Y91.861 E.09586
G1 X83.139 Y92.098 E.00704
G1 X79.377 Y106.139 E.43162
G1 X79.04 Y106.139 E.01
G1 X78.861 Y105.96 E.00755
G1 X78.861 Y104.531 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I.364 J1.161 P1  F42000
G1 X101.443 Y97.443 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
M73 P43 R18
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z3.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z3.6 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z3.6 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I-.582 J1.069 P1  F42000
G1 X114.557 Y105.044 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.158 E.05599
G1 X116.443 Y103.158 E.05599
G1 X116.443 Y104.101 E.028
G1 X116.443 Y105.044 E.028
G1 X114.617 Y105.044 E.05421
M204 S250
G1 X114.2 Y105.106 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y104.917 E.00562
G1 X114.2 Y104.727 E.00562
G1 X114.2 Y104.538 E.00562
G1 X114.2 Y104.348 E.00562
G1 X114.2 Y104.159 E.00562
G1 X114.2 Y103.97 E.00562
G1 X114.2 Y103.78 E.00562
G1 X114.2 Y103.591 E.00562
G1 X114.2 Y102.801 E.02344
G1 X116.8 Y102.801 E.0772
G1 X116.8 Y104.101 E.0386
G1 X116.8 Y104.224 E.00366
G1 X116.8 Y104.347 E.00366
G1 X116.8 Y104.471 E.00366
G1 X116.8 Y104.594 E.00366
G1 X116.8 Y104.717 E.00366
G1 X116.8 Y104.84 E.00366
G1 X116.8 Y104.963 E.00366
G1 X116.8 Y105.086 E.00366
G1 X116.8 Y105.209 E.00366
G1 X116.8 Y105.332 E.00366
G1 X116.8 Y105.401 E.00204
G1 X114.2 Y105.401 E.0772
G1 X114.2 Y105.295 E.00314
G1 X114.2 Y105.166 E.00384
G1 X114.914 Y103.515 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.687 E.03479
G1 X116.086 Y104.687 E.03479
G1 X116.086 Y103.515 E.03479
G1 X114.974 Y103.515 E.03301
M204 S500
G1 X115.296 Y103.898 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y104.305 E.0138
G1 X115.704 Y104.305 E.0138
G1 X115.704 Y103.898 E.0138
G1 X115.356 Y103.898 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I1.09 J.541 P1  F42000
G1 X118.557 Y97.443 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
M73 P43 R17
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z3.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
M73 P44 R17
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z3.8 I1.217 J0 P1  F42000
G1 X78.861 Y101.18
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y102.608 E.04241
G1 X83.139 Y101.462 E.13153
G1 X83.139 Y102.464 E.02976
G1 X78.861 Y98.185 E.17967
G1 X78.861 Y97.063 E.03331
G1 X83.139 Y95.916 E.13153
G1 X83.139 Y94.889 E.03051
G1 X80.111 Y91.861 E.12716
G1 X83.057 Y91.861 E.08746
G1 X79.24 Y106.139 E.43884
G1 X78.861 Y105.76 E.01594
G1 X78.861 Y104.331 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I.355 J1.164 P1  F42000
G1 X101.443 Y97.443 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z3.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z3.8 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z3.8 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I-.6 J1.059 P1  F42000
G1 X114.557 Y105.212 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.326 E.05599
G1 X116.443 Y103.326 E.05599
G1 X116.443 Y104.269 E.028
G1 X116.443 Y105.212 E.028
G1 X114.617 Y105.212 E.05421
M204 S250
G1 X114.2 Y105.274 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.084 E.00562
G1 X114.2 Y104.895 E.00562
G1 X114.2 Y104.706 E.00562
G1 X114.2 Y104.516 E.00562
G1 X114.2 Y104.327 E.00562
G1 X114.2 Y104.137 E.00562
G1 X114.2 Y103.948 E.00562
G1 X114.2 Y103.758 E.00562
G1 X114.2 Y102.969 E.02344
G1 X116.8 Y102.969 E.0772
G1 X116.8 Y104.269 E.0386
G1 X116.8 Y104.392 E.00366
G1 X116.8 Y104.515 E.00366
G1 X116.8 Y104.638 E.00366
G1 X116.8 Y104.762 E.00366
G1 X116.8 Y104.885 E.00366
G1 X116.8 Y105.008 E.00366
G1 X116.8 Y105.131 E.00366
G1 X116.8 Y105.254 E.00366
G1 X116.8 Y105.377 E.00366
G1 X116.8 Y105.5 E.00366
G1 X116.8 Y105.569 E.00204
G1 X114.2 Y105.569 E.0772
G1 X114.2 Y105.463 E.00314
G1 X114.2 Y105.334 E.00384
G1 X114.914 Y103.683 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y104.855 E.03479
G1 X116.086 Y104.855 E.03479
G1 X116.086 Y103.683 E.03479
G1 X114.974 Y103.683 E.03301
M204 S500
G1 X115.296 Y104.065 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y104.473 E.0138
G1 X115.704 Y104.473 E.0138
G1 X115.704 Y104.065 E.0138
G1 X115.356 Y104.065 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I1.096 J.53 P1  F42000
G1 X118.557 Y97.443 Z3.8
M73 P45 R17
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z3.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z3.8
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z4 I1.217 J0 P1  F42000
G1 X78.861 Y101.326
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y102.755 E.04241
G1 X83.139 Y101.608 E.13153
G1 X83.139 Y102.264 E.01947
G1 X78.861 Y97.985 E.17967
G1 X78.861 Y97.209 E.02303
G1 X83.139 Y96.063 E.13153
G1 X83.139 Y94.689 E.04079
G1 X80.311 Y91.861 E.11877
G1 X82.91 Y91.861 E.07717
G1 X79.084 Y106.139 E.43891
G1 X79.44 Y106.139 E.01057
G1 X78.861 Y105.56 E.02434
G1 X78.861 Y104.131 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I.346 J1.167 P1  F42000
G1 X101.443 Y97.443 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z4
G1 Z3.6
M73 P46 R17
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I-.618 J1.049 P1  F42000
G1 X114.557 Y105.38 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.494 E.05599
G1 X116.443 Y103.494 E.05599
G1 X116.443 Y104.437 E.028
G1 X116.443 Y105.38 E.028
G1 X114.617 Y105.38 E.05421
M204 S250
G1 X114.2 Y105.442 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.252 E.00562
G1 X114.2 Y105.063 E.00562
G1 X114.2 Y104.873 E.00562
G1 X114.2 Y104.684 E.00562
G1 X114.2 Y104.495 E.00562
G1 X114.2 Y104.305 E.00562
G1 X114.2 Y104.116 E.00562
G1 X114.2 Y103.926 E.00562
G1 X114.2 Y103.137 E.02344
G1 X116.8 Y103.137 E.0772
G1 X116.8 Y104.437 E.0386
G1 X116.8 Y104.56 E.00366
G1 X116.8 Y104.683 E.00366
G1 X116.8 Y104.806 E.00366
G1 X116.8 Y104.929 E.00366
G1 X116.8 Y105.052 E.00366
G1 X116.8 Y105.176 E.00366
G1 X116.8 Y105.299 E.00366
G1 X116.8 Y105.422 E.00366
G1 X116.8 Y105.545 E.00366
G1 X116.8 Y105.668 E.00366
G1 X116.8 Y105.737 E.00204
G1 X114.2 Y105.737 E.0772
G1 X114.2 Y105.631 E.00314
G1 X114.2 Y105.502 E.00384
G1 X114.914 Y103.851 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.023 E.03479
G1 X116.086 Y105.023 E.03479
G1 X116.086 Y103.851 E.03479
G1 X114.974 Y103.851 E.03301
M204 S500
G1 X115.296 Y104.233 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y104.641 E.0138
G1 X115.704 Y104.641 E.0138
G1 X115.704 Y104.233 E.0138
G1 X115.356 Y104.233 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I1.101 J.519 P1  F42000
G1 X118.557 Y97.443 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z4 I.875 J.846 P1  F42000
G1 X120 Y96 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z4
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z4.2 I1.217 J0 P1  F42000
G1 X78.861 Y101.473
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y102.901 E.04241
G1 X83.139 Y101.754 E.13153
G1 X83.139 Y102.064 E.00919
G1 X78.861 Y97.785 E.17967
G1 X78.861 Y97.356 E.01274
G1 X83.139 Y96.209 E.13153
G1 X83.139 Y94.489 E.05108
G1 X80.511 Y91.861 E.11037
G1 X82.764 Y91.861 E.06689
G1 X78.938 Y106.139 E.43891
G1 X79.64 Y106.139 E.02086
G1 X78.861 Y105.36 E.03274
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I.403 J1.148 P1  F42000
G1 X101.443 Y97.443 Z4.2
G1 Z3.8
M73 P46 R16
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z4.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
M73 P47 R16
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z4.2 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z4.2 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I-.635 J1.038 P1  F42000
G1 X114.557 Y105.548 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.662 E.05599
G1 X116.443 Y103.662 E.05599
G1 X116.443 Y104.605 E.028
G1 X116.443 Y105.548 E.028
G1 X114.617 Y105.548 E.05421
M204 S250
G1 X114.2 Y105.609 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.42 E.00562
G1 X114.2 Y105.231 E.00562
G1 X114.2 Y105.041 E.00562
G1 X114.2 Y104.852 E.00562
G1 X114.2 Y104.662 E.00562
G1 X114.2 Y104.473 E.00562
G1 X114.2 Y104.284 E.00562
G1 X114.2 Y104.094 E.00562
G1 X114.2 Y103.305 E.02344
G1 X116.8 Y103.305 E.0772
G1 X116.8 Y104.605 E.0386
G1 X116.8 Y104.728 E.00366
G1 X116.8 Y104.851 E.00366
G1 X116.8 Y104.974 E.00366
G1 X116.8 Y105.097 E.00366
G1 X116.8 Y105.22 E.00366
G1 X116.8 Y105.343 E.00366
G1 X116.8 Y105.467 E.00366
G1 X116.8 Y105.59 E.00366
G1 X116.8 Y105.713 E.00366
G1 X116.8 Y105.836 E.00366
G1 X116.8 Y105.905 E.00204
G1 X114.2 Y105.905 E.0772
G1 X114.2 Y105.799 E.00314
G1 X114.2 Y105.669 E.00384
G1 X114.914 Y104.019 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.191 E.03479
G1 X116.086 Y105.191 E.03479
G1 X116.086 Y104.019 E.03479
G1 X114.974 Y104.019 E.03301
M204 S500
G1 X115.296 Y104.401 F42000
; LINE_WIDTH: 0.45026
G1 F1472.971
M204 S6000
G1 X115.296 Y104.808 E.0138
G1 X115.704 Y104.808 E.0138
G1 X115.704 Y104.401 E.0138
G1 X115.356 Y104.401 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I1.106 J.509 P1  F42000
G1 X118.557 Y97.443 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z4.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z4.4 I1.217 J0 P1  F42000
M73 P48 R16
G1 X78.861 Y101.619
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y103.047 E.04241
G1 X83.139 Y101.901 E.13153
G1 X83.139 Y101.864 E.0011
G1 X78.861 Y97.585 E.17967
G1 X78.861 Y97.502 E.00246
G1 X83.139 Y96.356 E.13153
G1 X83.139 Y94.289 E.06136
G1 X80.711 Y91.861 E.10197
G1 X82.617 Y91.861 E.0566
G1 X78.861 Y105.881 E.43097
G1 X78.861 Y106.139 E.00767
G1 X79.84 Y106.139 E.02909
G1 X78.861 Y105.16 E.04114
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I.394 J1.152 P1  F42000
G1 X101.443 Y97.443 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z4.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z4.4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z4.4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I-.651 J1.028 P1  F42000
G1 X114.557 Y105.715 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.83 E.05599
G1 X116.443 Y103.83 E.05599
G1 X116.443 Y104.773 E.028
G1 X116.443 Y105.715 E.028
G1 X114.617 Y105.715 E.05421
M204 S250
G1 X114.2 Y105.967 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.777 E.00562
G1 X114.2 Y105.588 E.00562
G1 X114.2 Y105.398 E.00562
G1 X114.2 Y105.209 E.00562
G1 X114.2 Y105.02 E.00562
G1 X114.2 Y104.83 E.00562
G1 X114.2 Y104.641 E.00562
G1 X114.2 Y104.451 E.00562
G1 X114.2 Y104.262 E.00562
G1 X114.2 Y103.473 E.02344
G1 X116.8 Y103.473 E.0772
G1 X116.8 Y104.773 E.0386
G1 X116.8 Y104.896 E.00366
G1 X116.8 Y105.019 E.00366
G1 X116.8 Y105.142 E.00366
G1 X116.8 Y105.265 E.00366
G1 X116.8 Y105.388 E.00366
G1 X116.8 Y105.511 E.00366
G1 X116.8 Y105.634 E.00366
G1 X116.8 Y105.757 E.00366
G1 X116.8 Y105.881 E.00366
G1 X116.8 Y106.004 E.00366
G1 X116.8 Y106.073 E.00204
G1 X114.2 Y106.073 E.0772
G1 X114.2 Y106.027 E.00136
G1 X114.914 Y104.187 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.358 E.03479
G1 X116.086 Y105.358 E.03479
G1 X116.086 Y104.187 E.03479
G1 X114.974 Y104.187 E.03301
M204 S500
G1 X115.296 Y104.569 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y104.976 E.0138
G1 X115.704 Y104.976 E.0138
G1 X115.704 Y104.569 E.0138
G1 X115.356 Y104.569 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I1.11 J.499 P1  F42000
G1 X118.557 Y97.443 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z4.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z4.4
G1 Z4
M73 P49 R16
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z4.4
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z4.6 I1.217 J0 P1  F42000
G1 X83.139 Y92.62
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y91.861 E.02256
G1 X82.471 Y91.861 E.01985
G1 X78.861 Y105.335 E.41418
G1 X78.861 Y106.139 E.02389
G1 X80.04 Y106.139 E.03503
G1 X78.861 Y104.96 E.04954
M204 S500
G1 X78.861 Y101.765 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y103.194 E.04241
G1 X83.139 Y102.047 E.13153
G1 X83.139 Y101.664 E.01138
G1 X78.861 Y97.385 E.17967
G1 X78.861 Y97.649 E.00783
G1 X83.139 Y96.502 E.13153
G1 X83.139 Y94.089 E.07165
G1 X80.911 Y91.861 E.09357
G1 X79.767 Y91.861 E.03396
G1 X78.861 Y92.103 E.02787
G1 X78.861 Y93.532 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I-.208 J1.199 P1  F42000
G1 X101.443 Y97.443 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z4.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z4.6 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z4.6 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z4.6
M73 P49 R15
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
M73 P50 R15
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I-.667 J1.018 P1  F42000
G1 X114.557 Y105.883 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y103.997 E.05599
G1 X116.443 Y103.997 E.05599
G1 X116.443 Y104.94 E.028
G1 X116.443 Y105.883 E.028
G1 X114.617 Y105.883 E.05421
M204 S250
G1 X114.2 Y105.945 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.756 E.00562
G1 X114.2 Y105.566 E.00562
G1 X114.2 Y105.377 E.00562
G1 X114.2 Y105.187 E.00562
G1 X114.2 Y104.998 E.00562
G1 X114.2 Y104.809 E.00562
G1 X114.2 Y104.619 E.00562
G1 X114.2 Y104.43 E.00562
G1 X114.2 Y103.64 E.02344
G1 X116.8 Y103.64 E.0772
G1 X116.8 Y104.94 E.0386
G1 X116.8 Y105.063 E.00366
G1 X116.8 Y105.187 E.00366
G1 X116.8 Y105.31 E.00366
G1 X116.8 Y105.433 E.00366
G1 X116.8 Y105.556 E.00366
G1 X116.8 Y105.679 E.00366
G1 X116.8 Y105.802 E.00366
G1 X116.8 Y105.925 E.00366
G1 X116.8 Y106.048 E.00366
G1 X116.8 Y106.172 E.00366
G1 X116.8 Y106.24 E.00204
G1 X114.2 Y106.24 E.0772
G1 X114.2 Y106.135 E.00314
G1 X114.2 Y106.005 E.00384
G1 X114.914 Y104.354 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.526 E.03479
G1 X116.086 Y105.526 E.03479
G1 X116.086 Y104.354 E.03479
G1 X114.974 Y104.354 E.03301
M204 S500
G1 X115.296 Y104.737 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y105.144 E.0138
G1 X115.704 Y105.144 E.0138
G1 X115.704 Y104.737 E.0138
G1 X115.356 Y104.737 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I1.114 J.489 P1  F42000
G1 X118.557 Y97.443 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z4.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z4.6
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z4.8 I1.217 J0 P1  F42000
G1 X83.139 Y92.474
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y91.861 E.01821
G1 X82.325 Y91.861 E.0242
G1 X78.861 Y104.788 E.39738
G1 X78.861 Y104.76 E.00085
G1 X80.24 Y106.139 E.05793
G1 X81.669 Y106.139 E.04241
M204 S500
G1 X78.861 Y101.912 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y103.34 E.04241
G1 X83.139 Y102.194 E.13153
G1 X83.139 Y101.464 E.02167
G1 X78.861 Y97.185 E.17967
G1 X78.861 Y97.795 E.01811
G1 X83.139 Y96.649 E.13153
G1 X83.139 Y93.889 E.08193
G1 X81.111 Y91.861 E.08517
G1 X80.314 Y91.861 E.02368
G1 X78.861 Y92.25 E.04466
G1 X78.861 Y93.678 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I-.2 J1.2 P1  F42000
G1 X101.443 Y97.443 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z4.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
M73 P51 R15
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z4.8 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z4.8 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I-.683 J1.008 P1  F42000
G1 X114.557 Y106.051 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y104.165 E.05599
G1 X116.443 Y104.165 E.05599
G1 X116.443 Y105.108 E.028
G1 X116.443 Y106.051 E.028
G1 X114.617 Y106.051 E.05421
M204 S250
G1 X114.2 Y106.113 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y105.924 E.00562
G1 X114.2 Y105.734 E.00562
G1 X114.2 Y105.545 E.00562
G1 X114.2 Y105.355 E.00562
G1 X114.2 Y105.166 E.00562
G1 X114.2 Y104.976 E.00562
G1 X114.2 Y104.787 E.00562
G1 X114.2 Y104.598 E.00562
G1 X114.2 Y103.808 E.02344
G1 X116.8 Y103.808 E.0772
G1 X116.8 Y105.108 E.0386
G1 X116.8 Y105.231 E.00366
G1 X116.8 Y105.354 E.00366
G1 X116.8 Y105.478 E.00366
G1 X116.8 Y105.601 E.00366
G1 X116.8 Y105.724 E.00366
G1 X116.8 Y105.847 E.00366
G1 X116.8 Y105.97 E.00366
G1 X116.8 Y106.093 E.00366
G1 X116.8 Y106.216 E.00366
G1 X116.8 Y106.339 E.00366
G1 X116.8 Y106.408 E.00204
G1 X114.2 Y106.408 E.0772
G1 X114.2 Y106.302 E.00314
G1 X114.2 Y106.173 E.00384
G1 X114.914 Y104.522 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.694 E.03479
G1 X116.086 Y105.694 E.03479
G1 X116.086 Y104.522 E.03479
G1 X114.974 Y104.522 E.03301
M204 S500
G1 X115.296 Y104.904 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y105.312 E.0138
G1 X115.704 Y105.312 E.0138
G1 X115.704 Y104.904 E.0138
G1 X115.356 Y104.904 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I1.118 J.48 P1  F42000
G1 X118.557 Y97.443 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z4.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z5 I1.217 J0 P1  F42000
G1 X78.861 Y93.825
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y92.396 E.04241
G1 X80.86 Y91.861 E.06146
G1 X81.311 Y91.861 E.01339
G1 X83.139 Y93.689 E.07678
G1 X83.139 Y91.861 E.05429
G1 X82.178 Y91.861 E.02854
G1 X78.861 Y104.242 E.38058
G1 X78.861 Y104.56 E.00944
G1 X80.44 Y106.139 E.06633
G1 X81.869 Y106.139 E.04241
M204 S500
G1 X78.861 Y103.487 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y102.34 E.13153
G1 X83.139 Y101.264 E.03196
G1 X78.861 Y96.985 E.17967
G1 X78.861 Y97.941 E.0284
G1 X83.139 Y96.795 E.13153
M73 P52 R15
G1 X83.139 Y98.223 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I.052 J1.216 P1  F42000
G1 X101.443 Y97.443 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z5 I.846 J-.875 P1  F42000
G1 X100 Y96 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z5 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z5 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I-.698 J.997 P1  F42000
G1 X114.557 Y106.219 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y104.333 E.05599
G1 X116.443 Y104.333 E.05599
G1 X116.443 Y105.276 E.028
G1 X116.443 Y106.219 E.028
G1 X114.617 Y106.219 E.05421
M204 S250
G1 X114.2 Y106.281 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y106.091 E.00562
G1 X114.2 Y105.902 E.00562
G1 X114.2 Y105.713 E.00562
G1 X114.2 Y105.523 E.00562
G1 X114.2 Y105.334 E.00562
G1 X114.2 Y105.144 E.00562
G1 X114.2 Y104.955 E.00562
G1 X114.2 Y104.765 E.00562
G1 X114.2 Y103.976 E.02344
G1 X116.8 Y103.976 E.0772
G1 X116.8 Y105.276 E.0386
G1 X116.8 Y105.399 E.00366
G1 X116.8 Y105.522 E.00366
G1 X116.8 Y105.645 E.00366
G1 X116.8 Y105.768 E.00366
G1 X116.8 Y105.892 E.00366
G1 X116.8 Y106.015 E.00366
G1 X116.8 Y106.138 E.00366
G1 X116.8 Y106.261 E.00366
G1 X116.8 Y106.384 E.00366
G1 X116.8 Y106.507 E.00366
G1 X116.8 Y106.576 E.00204
G1 X114.2 Y106.576 E.0772
G1 X114.2 Y106.47 E.00314
G1 X114.2 Y106.341 E.00384
G1 X114.914 Y104.69 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y105.862 E.03479
G1 X116.086 Y105.862 E.03479
G1 X116.086 Y104.69 E.03479
G1 X114.974 Y104.69 E.03301
M204 S500
G1 X115.296 Y105.072 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y105.48 E.0138
G1 X115.704 Y105.48 E.0138
G1 X115.704 Y105.072 E.0138
G1 X115.356 Y105.072 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I1.122 J.471 P1  F42000
G1 X118.557 Y97.443 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z5 I.875 J.846 P1  F42000
G1 X120 Y96 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z5
M73 P53 R15
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
M73 P53 R14
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z5.2 I1.217 J0 P1  F42000
G1 X78.861 Y93.971
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y92.543 E.04241
G1 X81.406 Y91.861 E.07826
G1 X81.511 Y91.861 E.0031
G1 X83.139 Y93.489 E.06838
G1 X83.139 Y91.861 E.04835
G1 X82.032 Y91.861 E.03289
G1 X78.861 Y103.695 E.36379
G1 X78.861 Y103.633 E.00185
G1 X83.139 Y102.486 E.13153
G1 X83.139 Y101.064 E.04224
G1 X78.861 Y96.785 E.17967
G1 X78.861 Y98.088 E.03869
G1 X83.139 Y96.941 E.13153
G1 X83.139 Y98.37 E.04241
M204 S500
G1 X82.069 Y106.139 F42000
G1 F1680.297
M204 S6000
G1 X80.64 Y106.139 E.04241
G1 X78.861 Y104.36 E.07473
G1 X78.861 Y105.788 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I.422 J1.142 P1  F42000
G1 X101.443 Y97.443 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z5.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z5.2 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z5.2 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I-.712 J.987 P1  F42000
G1 X114.557 Y106.387 Z5.2
G1 Z4.8
M73 P54 R14
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y104.501 E.05599
G1 X116.443 Y104.501 E.05599
G1 X116.443 Y105.444 E.028
G1 X116.443 Y106.387 E.028
G1 X114.617 Y106.387 E.05421
M204 S250
G1 X114.2 Y106.638 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y106.449 E.00562
G1 X114.2 Y106.259 E.00562
G1 X114.2 Y106.07 E.00562
G1 X114.2 Y105.88 E.00562
G1 X114.2 Y105.691 E.00562
G1 X114.2 Y105.501 E.00562
G1 X114.2 Y105.312 E.00562
G1 X114.2 Y105.123 E.00562
G1 X114.2 Y104.933 E.00562
G1 X114.2 Y104.144 E.02344
G1 X116.8 Y104.144 E.0772
G1 X116.8 Y105.444 E.0386
G1 X116.8 Y105.567 E.00366
G1 X116.8 Y105.69 E.00366
G1 X116.8 Y105.813 E.00366
G1 X116.8 Y105.936 E.00366
G1 X116.8 Y106.059 E.00366
G1 X116.8 Y106.183 E.00366
G1 X116.8 Y106.306 E.00366
G1 X116.8 Y106.429 E.00366
G1 X116.8 Y106.552 E.00366
G1 X116.8 Y106.675 E.00366
G1 X116.8 Y106.744 E.00204
G1 X114.2 Y106.744 E.0772
G1 X114.2 Y106.698 E.00136
G1 X114.914 Y104.858 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.03 E.03479
G1 X116.086 Y106.03 E.03479
G1 X116.086 Y104.858 E.03479
G1 X114.974 Y104.858 E.03301
M204 S500
G1 X115.296 Y105.24 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y105.647 E.0138
G1 X115.704 Y105.647 E.0138
G1 X115.704 Y105.24 E.0138
G1 X115.356 Y105.24 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I1.126 J.462 P1  F42000
G1 X118.557 Y97.443 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z5.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I.185 J-1.203 P1  F42000
G1 X83.443 Y91.557 Z5.2
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.383 Y91.557 E.14328
M204 S250
G1 X83.8 Y91.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.74 Y91.2 E.16449
G1 E-.8 F1800
G17
G3 Z5.4 I1.217 J0 P1  F42000
G1 X81.711 Y91.861
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.289 E.05998
G1 X83.139 Y97.088 E.11279
G1 X78.861 Y98.234 E.13153
G1 X78.861 Y96.585 E.04897
G1 X83.139 Y100.864 E.17967
G1 X83.139 Y102.633 E.05253
G1 X78.861 Y103.779 E.13153
G1 X78.861 Y104.16 E.01129
G1 X80.84 Y106.139 E.08313
G1 X82.269 Y106.139 E.04241
M204 S500
G1 X78.861 Y103.601 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y103.149 E.01342
G1 X81.885 Y91.861 E.34699
G1 X81.953 Y91.861 E.002
G1 X78.861 Y92.689 E.09505
G1 X78.861 Y94.117 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I-.177 J1.204 P1  F42000
G1 X101.443 Y97.443 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z5.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z5.4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
M73 P55 R14
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z5.4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I-.726 J.976 P1  F42000
G1 X114.557 Y106.555 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y104.669 E.05599
G1 X116.443 Y104.669 E.05599
G1 X116.443 Y105.612 E.028
G1 X116.443 Y106.555 E.028
G1 X114.617 Y106.555 E.05421
M204 S250
G1 X114.2 Y106.616 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y106.427 E.00562
G1 X114.2 Y106.238 E.00562
G1 X114.2 Y106.048 E.00562
G1 X114.2 Y105.859 E.00562
G1 X114.2 Y105.669 E.00562
G1 X114.2 Y105.48 E.00562
G1 X114.2 Y105.29 E.00562
G1 X114.2 Y105.101 E.00562
G1 X114.2 Y104.312 E.02344
G1 X116.8 Y104.312 E.0772
G1 X116.8 Y105.612 E.0386
G1 X116.8 Y105.735 E.00366
G1 X116.8 Y105.858 E.00366
G1 X116.8 Y105.981 E.00366
G1 X116.8 Y106.104 E.00366
G1 X116.8 Y106.227 E.00366
G1 X116.8 Y106.35 E.00366
G1 X116.8 Y106.473 E.00366
G1 X116.8 Y106.597 E.00366
G1 X116.8 Y106.72 E.00366
G1 X116.8 Y106.843 E.00366
G1 X116.8 Y106.912 E.00204
G1 X114.2 Y106.912 E.0772
G1 X114.2 Y106.806 E.00314
G1 X114.2 Y106.676 E.00384
G1 X114.914 Y105.026 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.197 E.03479
G1 X116.086 Y106.197 E.03479
G1 X116.086 Y105.026 E.03479
G1 X114.974 Y105.026 E.03301
M204 S500
G1 X115.296 Y105.408 F42000
; LINE_WIDTH: 0.45026
G1 F1472.971
M204 S6000
G1 X115.296 Y105.815 E.0138
G1 X115.704 Y105.815 E.0138
G1 X115.704 Y105.408 E.0138
G1 X115.356 Y105.408 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I1.129 J.454 P1  F42000
G1 X118.557 Y97.443 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z5.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I.18 J-1.204 P1  F42000
G1 X83.443 Y91.73 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.06741
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y91.67 E.00334
M204 S250
G1 X83.8 Y91.73 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.06741
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y91.67 E.01394
G1 E-.8 F1800
G17
G3 Z5.6 I1.217 J0 P1  F42000
G1 X81.911 Y91.861
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.089 E.05158
G1 X83.139 Y91.861 E.03647
G1 X82.499 Y91.861 E.01901
G1 X78.861 Y92.836 E.11185
G1 X78.861 Y94.264 E.04241
M204 S500
G1 X81.739 Y91.861 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y102.603 E.3302
G1 X78.861 Y103.747 E.03399
M204 S500
G1 X82.469 Y106.139 F42000
G1 F1680.297
M204 S6000
G1 X81.04 Y106.139 E.04241
G1 X78.861 Y103.96 E.09152
G1 X78.861 Y103.926 E.00101
G1 X83.139 Y102.779 E.13153
G1 X83.139 Y100.664 E.06281
G1 X78.861 Y96.385 E.17967
G1 X78.861 Y98.381 E.05926
G1 X83.139 Y97.234 E.13153
G1 X83.139 Y95.806 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I-.108 J1.212 P1  F42000
G1 X101.443 Y97.443 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
M73 P56 R14
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z5.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
M73 P56 R13
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z5.6 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z5.6 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I-.74 J.966 P1  F42000
G1 X114.557 Y106.722 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y104.836 E.05599
G1 X116.443 Y104.836 E.05599
G1 X116.443 Y105.779 E.028
G1 X116.443 Y106.722 E.028
G1 X114.617 Y106.722 E.05421
M204 S250
G1 X114.2 Y106.974 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y106.784 E.00562
G1 X114.2 Y106.595 E.00562
G1 X114.2 Y106.405 E.00562
G1 X114.2 Y106.216 E.00562
G1 X114.2 Y106.027 E.00562
G1 X114.2 Y105.837 E.00562
G1 X114.2 Y105.648 E.00562
G1 X114.2 Y105.458 E.00562
G1 X114.2 Y105.269 E.00562
G1 X114.2 Y104.479 E.02344
G1 X116.8 Y104.479 E.0772
G1 X116.8 Y105.779 E.0386
G1 X116.8 Y105.903 E.00366
G1 X116.8 Y106.026 E.00366
G1 X116.8 Y106.149 E.00366
G1 X116.8 Y106.272 E.00366
G1 X116.8 Y106.395 E.00366
G1 X116.8 Y106.518 E.00366
G1 X116.8 Y106.641 E.00366
G1 X116.8 Y106.764 E.00366
G1 X116.8 Y106.888 E.00366
G1 X116.8 Y107.011 E.00366
G1 X116.8 Y107.079 E.00204
G1 X114.2 Y107.079 E.0772
G1 X114.2 Y107.034 E.00136
G1 X114.914 Y105.194 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.365 E.03479
G1 X116.086 Y106.365 E.03479
G1 X116.086 Y105.194 E.03479
G1 X114.974 Y105.194 E.03301
M204 S500
G1 X115.296 Y105.576 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y105.983 E.0138
G1 X115.704 Y105.983 E.0138
G1 X115.704 Y105.576 E.0138
G1 X115.356 Y105.576 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I1.132 J.446 P1  F42000
G1 X118.557 Y97.443 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z5.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I.178 J-1.204 P1  F42000
G1 X83.443 Y91.796 Z5.6
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.06544
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
M73 P57 R13
G1 X83.443 Y91.736 E.00531
M204 S250
G1 X83.8 Y91.796 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.06544
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y91.736 E.01591
G1 E-.8 F1800
G17
G3 Z5.8 I1.217 J0 P1  F42000
G1 X82.111 Y91.861
G1 Z5.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y92.889 E.04318
G1 X83.139 Y91.861 E.03054
G1 X83.046 Y91.861 E.00279
G1 X78.861 Y92.982 E.12864
G1 X78.861 Y91.861 E.0333
G1 X81.592 Y91.861 E.08111
G1 X78.861 Y102.056 E.3134
G1 X78.861 Y103.485 E.04241
M204 S500
G1 X82.669 Y106.139 F42000
G1 F1680.297
M204 S6000
G1 X81.24 Y106.139 E.04241
G1 X78.861 Y103.76 E.09992
G1 X78.861 Y104.072 E.00928
G1 X83.139 Y102.926 E.13153
G1 X83.139 Y100.464 E.0731
G1 X78.861 Y96.185 E.17967
G1 X78.861 Y98.527 E.06954
G1 X83.139 Y97.381 E.13153
G1 X83.139 Y95.952 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I-.099 J1.213 P1  F42000
G1 X101.443 Y97.443 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z5.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z5.8 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z5.8 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I-.753 J.956 P1  F42000
G1 X114.557 Y106.89 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y105.004 E.05599
G1 X116.443 Y105.004 E.05599
G1 X116.443 Y105.947 E.028
G1 X116.443 Y106.89 E.028
G1 X114.617 Y106.89 E.05421
M204 S250
G1 X114.2 Y106.952 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y106.763 E.00562
G1 X114.2 Y106.573 E.00562
G1 X114.2 Y106.384 E.00562
G1 X114.2 Y106.194 E.00562
G1 X114.2 Y106.005 E.00562
G1 X114.2 Y105.816 E.00562
G1 X114.2 Y105.626 E.00562
G1 X114.2 Y105.437 E.00562
G1 X114.2 Y104.647 E.02344
G1 X116.8 Y104.647 E.0772
G1 X116.8 Y105.947 E.0386
G1 X116.8 Y106.07 E.00366
G1 X116.8 Y106.193 E.00366
G1 X116.8 Y106.317 E.00366
G1 X116.8 Y106.44 E.00366
G1 X116.8 Y106.563 E.00366
G1 X116.8 Y106.686 E.00366
G1 X116.8 Y106.809 E.00366
G1 X116.8 Y106.932 E.00366
G1 X116.8 Y107.055 E.00366
G1 X116.8 Y107.178 E.00366
G1 X116.8 Y107.247 E.00204
G1 X114.2 Y107.247 E.0772
G1 X114.2 Y107.141 E.00314
G1 X114.2 Y107.012 E.00384
G1 X114.914 Y105.361 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.533 E.03479
G1 X116.086 Y106.533 E.03479
G1 X116.086 Y105.361 E.03479
G1 X114.974 Y105.361 E.03301
M204 S500
G1 X115.296 Y105.744 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y106.151 E.0138
G1 X115.704 Y106.151 E.0138
G1 X115.704 Y105.744 E.0138
G1 X115.356 Y105.744 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I1.135 J.438 P1  F42000
G1 X118.557 Y97.443 Z5.8
G1 Z5.4
M73 P58 R13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z5.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I.175 J-1.204 P1  F42000
G1 X83.443 Y91.863 Z5.8
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.06344
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y91.803 E.00731
M204 S250
G1 X83.8 Y91.863 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.06344
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y91.803 E.01791
G1 E-.8 F1800
G17
G3 Z6 I1.217 J0 P1  F42000
G1 X83.139 Y96.099
G1 Z5.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y97.527 E.04241
G1 X78.861 Y98.674 E.13153
G1 X78.861 Y95.985 E.07983
G1 X83.139 Y100.264 E.17967
G1 X83.139 Y103.072 E.08338
G1 X78.861 Y104.219 E.13153
G1 X78.861 Y103.56 E.01956
G1 X81.44 Y106.139 E.10832
G1 X82.869 Y106.139 E.04241
M204 S500
G1 X78.861 Y102.938 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y101.51 E.04241
G1 X81.446 Y91.861 E.29661
G1 X82.311 Y91.861 E.02568
G1 X83.139 Y92.689 E.03479
G1 X83.139 Y91.982 E.021
G1 X78.861 Y93.128 E.13153
G1 X78.861 Y91.861 E.03764
G1 X79.021 Y91.861 E.00477
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I-.294 J1.181 P1  F42000
G1 X101.443 Y97.443 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z6 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z6
G1 Z5.6
M73 P59 R13
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z6 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I-.766 J.946 P1  F42000
G1 X114.557 Y107.058 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y105.172 E.05599
G1 X116.443 Y105.172 E.05599
G1 X116.443 Y106.115 E.028
G1 X116.443 Y107.058 E.028
G1 X114.617 Y107.058 E.05421
M204 S250
G1 X114.2 Y107.309 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y107.12 E.00562
G1 X114.2 Y106.931 E.00562
G1 X114.2 Y106.741 E.00562
G1 X114.2 Y106.552 E.00562
G1 X114.2 Y106.362 E.00562
G1 X114.2 Y106.173 E.00562
G1 X114.2 Y105.983 E.00562
G1 X114.2 Y105.794 E.00562
G1 X114.2 Y105.604 E.00562
G1 X114.2 Y104.815 E.02344
G1 X116.8 Y104.815 E.0772
G1 X116.8 Y106.115 E.0386
G1 X116.8 Y106.238 E.00366
G1 X116.8 Y106.361 E.00366
G1 X116.8 Y106.484 E.00366
G1 X116.8 Y106.608 E.00366
G1 X116.8 Y106.731 E.00366
G1 X116.8 Y106.854 E.00366
G1 X116.8 Y106.977 E.00366
G1 X116.8 Y107.1 E.00366
G1 X116.8 Y107.223 E.00366
G1 X116.8 Y107.346 E.00366
G1 X116.8 Y107.415 E.00204
G1 X114.2 Y107.415 E.0772
G1 X114.2 Y107.369 E.00136
G1 X114.914 Y105.529 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.701 E.03479
G1 X116.086 Y106.701 E.03479
G1 X116.086 Y105.529 E.03479
G1 X114.974 Y105.529 E.03301
M204 S500
G1 X115.296 Y105.911 F42000
; LINE_WIDTH: 0.45025
G1 F1473.007
M204 S6000
G1 X115.296 Y106.319 E.0138
G1 X115.704 Y106.319 E.0138
G1 X115.704 Y105.911 E.0138
G1 X115.356 Y105.911 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I1.138 J.43 P1  F42000
G1 X118.557 Y97.443 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
M73 P59 R12
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z6 I.875 J.846 P1  F42000
G1 X120 Y96 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I.173 J-1.205 P1  F42000
G1 X83.443 Y91.931 Z6
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.06143
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y91.871 E.00932
M204 S250
G1 X83.8 Y91.931 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.06143
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y91.871 E.01992
G1 E-.8 F1800
G17
G3 Z6.2 I1.217 J0 P1  F42000
G1 X78.861 Y97.392
G1 Z5.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y98.82 E.04241
G1 X83.139 Y97.673 E.13153
G1 X83.139 Y100.064 E.07098
G1 X78.861 Y95.785 E.17967
G1 X78.861 Y93.275 E.07453
G1 X83.139 Y92.128 E.13153
G1 X83.139 Y92.489 E.01071
G1 X82.511 Y91.861 E.02639
G1 X81.3 Y91.861 E.03597
G1 X78.861 Y100.963 E.27981
G1 X78.861 Y102.392 E.04241
M204 S500
G1 X80.212 Y106.139 F42000
G1 F1680.297
M204 S6000
G1 X81.64 Y106.139 E.04241
G1 X78.861 Y103.36 E.11672
G1 X78.861 Y104.365 E.02985
G1 X83.139 Y103.219 E.13153
G1 X83.139 Y104.647 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I.446 J1.132 P1  F42000
G1 X101.443 Y97.443 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z6.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
M73 P60 R12
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z6.2 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z6.2 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I-.779 J.935 P1  F42000
G1 X114.557 Y107.226 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X114.557 Y105.34 E.05599
G1 X116.443 Y105.34 E.05599
G1 X116.443 Y106.283 E.028
G1 X116.443 Y107.226 E.028
G1 X114.617 Y107.226 E.05421
M204 S250
G1 X114.2 Y107.288 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y107.098 E.00562
G1 X114.2 Y106.909 E.00562
G1 X114.2 Y106.719 E.00562
G1 X114.2 Y106.53 E.00562
G1 X114.2 Y106.341 E.00562
G1 X114.2 Y106.151 E.00562
G1 X114.2 Y105.962 E.00562
G1 X114.2 Y105.772 E.00562
G1 X114.2 Y104.983 E.02344
G1 X116.8 Y104.983 E.0772
G1 X116.8 Y106.283 E.0386
G1 X116.8 Y106.406 E.00366
G1 X116.8 Y106.529 E.00366
G1 X116.8 Y106.652 E.00366
G1 X116.8 Y106.775 E.00366
G1 X116.8 Y106.899 E.00366
G1 X116.8 Y107.022 E.00366
G1 X116.8 Y107.145 E.00366
G1 X116.8 Y107.268 E.00366
G1 X116.8 Y107.391 E.00366
G1 X116.8 Y107.514 E.00366
G1 X116.8 Y107.583 E.00204
G1 X114.2 Y107.583 E.0772
G1 X114.2 Y107.477 E.00314
G1 X114.2 Y107.348 E.00384
G1 X114.914 Y105.697 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X114.914 Y106.869 E.03479
G1 X116.086 Y106.869 E.03479
G1 X116.086 Y105.697 E.03479
G1 X114.974 Y105.697 E.03301
M204 S500
G1 X115.296 Y106.079 F42000
; LINE_WIDTH: 0.45026
G1 F1472.971
M204 S6000
G1 X115.296 Y106.487 E.0138
G1 X115.704 Y106.487 E.0138
G1 X115.704 Y106.079 E.0138
G1 X115.356 Y106.079 E.01176
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I1.141 J.423 P1  F42000
G1 X118.557 Y97.443 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z6.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I.171 J-1.205 P1  F42000
G1 X83.443 Y92 Z6.2
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.0594
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y91.94 E.01136
M204 S250
G1 X83.8 Y92 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.0594
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
M73 P61 R12
G1 X83.8 Y91.94 E.02196
G1 E-.8 F1800
G17
G3 Z6.4 I1.217 J0 P1  F42000
G1 X78.861 Y97.538
G1 Z6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y98.966 E.04241
G1 X83.139 Y97.82 E.13153
G1 X83.139 Y99.864 E.06069
G1 X78.861 Y95.585 E.17967
G1 X78.861 Y93.421 E.06424
G1 X83.139 Y92.275 E.13153
G1 X83.139 Y92.289 E.00043
G1 X82.711 Y91.861 E.01799
G1 X81.153 Y91.861 E.04625
G1 X78.861 Y100.417 E.26301
G1 X78.861 Y101.845 E.04241
M204 S500
G1 X83.139 Y101.937 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y103.365 E.04241
G1 X78.861 Y104.511 E.13153
G1 X78.861 Y103.16 E.04013
G1 X81.84 Y106.139 E.12512
G1 X82.872 Y106.139 E.03064
G1 X83.139 Y105.143 E.03064
G1 X83.139 Y103.714 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I.394 J1.151 P1  F42000
G1 X101.443 Y97.443 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z6.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I-1.208 J.145 P1  F42000
G1 X101.443 Y100.557 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X101.443 Y102 E.04284
G1 X101.443 Y106.443 E.13191
G1 X98.557 Y106.443 E.08568
G1 X98.557 Y100.557 E.17475
G1 X101.383 Y100.557 E.0839
M204 S250
G1 X101.8 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X101.8 Y102 E.05344
G1 X101.8 Y106.8 E.14251
G1 X98.2 Y106.8 E.10689
G1 X98.2 Y100.2 E.19596
G1 X101.74 Y100.2 E.1051
G1 E-.8 F1800
G17
G3 Z6.4 I-1.144 J-.415 P1  F42000
G1 X100 Y105 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y102.06 E.09446
M204 S500
G1 X99.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X100.372 Y105.372 E.02207
G1 X100.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.02029
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X100.729 Y105.729 E.04328
G1 X100.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.0415
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X101.086 Y106.086 E.06448
G1 X101.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I.057 J1.216 P1  F42000
G1 X106.557 Y100.557 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.08568
G1 X109.443 Y102 E.04284
G1 X109.443 Y106.443 E.13191
G1 X106.557 Y106.443 E.08568
G1 X106.557 Y100.617 E.17297
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.10689
G1 X109.8 Y102 E.05344
G1 X109.8 Y106.8 E.14251
G1 X106.2 Y106.8 E.10689
G1 X106.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z6.4 I-1.138 J.432 P1  F42000
G1 X108 Y105 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X108 Y102.06 E.09446
M204 S500
G1 X107.628 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.02207
G1 X108.372 Y101.628 E.11115
G1 X107.688 Y101.628 E.02029
M204 S500
G1 X107.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.04328
G1 X108.729 Y101.271 E.13235
G1 X107.331 Y101.271 E.0415
M204 S500
G1 X106.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.06448
G1 X109.086 Y100.914 E.15355
G1 X106.974 Y100.914 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I-.829 J.89 P1  F42000
G1 X114.2 Y107.645 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Outer wall
G1 F1680.343
G1 X114.2 Y107.456 E.00562
G1 X114.2 Y107.266 E.00562
G1 X114.2 Y107.077 E.00562
G1 X114.2 Y106.887 E.00562
G1 X114.2 Y106.698 E.00562
G1 X114.2 Y106.508 E.00562
G1 X114.2 Y106.319 E.00562
G1 X114.2 Y106.13 E.00562
G1 X114.2 Y105.94 E.00562
G1 X114.2 Y105.151 E.02344
G1 X116.8 Y105.151 E.0772
G1 X116.8 Y106.451 E.0386
G1 X116.8 Y106.574 E.00366
G1 X116.8 Y106.697 E.00366
G1 X116.8 Y106.82 E.00366
G1 X116.8 Y106.943 E.00366
G1 X116.8 Y107.066 E.00366
G1 X116.8 Y107.189 E.00366
G1 X116.8 Y107.313 E.00366
G1 X116.8 Y107.436 E.00366
G1 X116.8 Y107.559 E.00366
G1 X116.8 Y107.682 E.00366
G1 X116.8 Y107.751 E.00204
G1 X114.2 Y107.751 E.0772
G1 X114.2 Y107.705 E.00136
G1 X115.909 Y107.608 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.41219
G1 F1624.827
G1 X116.497 Y107.021 E.02549
G1 X116.497 Y106.499 E.01603
G1 X115.548 Y107.447 E.04119
G1 X115.026 Y107.447 E.01604
G1 X116.496 Y105.976 E.06387
G1 X116.496 Y105.454 E.01604
G1 X114.503 Y107.447 E.08654
G1 X114.503 Y106.925 E.01604
G1 X115.974 Y105.454 E.06387
G1 X115.452 Y105.454 E.01604
G1 X114.503 Y106.403 E.04119
G1 X114.503 Y105.881 E.01604
G1 X115.091 Y105.294 E.02549
G1 E-.8 F1800
G17
G3 Z6.4 I1.113 J.492 P1  F42000
G1 X118.557 Y97.443 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
M73 P62 R12
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z6.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I.168 J-1.205 P1  F42000
G1 X83.443 Y92.068 Z6.4
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.05735
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.008 E.0134
M204 S250
G1 X83.8 Y92.068 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.05735
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.008 E.024
G1 E-.8 F1800
G17
G3 Z6.6 I1.217 J0 P1  F42000
G1 X78.861 Y99.113
G1 Z6.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y97.966 E.13153
G1 X83.139 Y99.664 E.0504
G1 X78.861 Y95.385 E.17967
G1 X78.861 Y93.568 E.05396
G1 X83.139 Y92.421 E.13153
G1 X83.139 Y92.089 E.00986
G1 X82.911 Y91.861 E.00959
G1 X81.007 Y91.861 E.05654
G1 X78.861 Y99.871 E.24622
G1 X78.861 Y102.96 E.09172
G1 X82.04 Y106.139 E.13352
G1 X82.726 Y106.139 E.02036
G1 X83.139 Y104.596 E.04743
G1 X83.139 Y103.511 E.03221
G1 X78.861 Y104.658 E.13153
G1 X78.861 Y106.086 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I.435 J1.137 P1  F42000
G1 X101.443 Y97.443 Z6.6
G1 Z6.2
M73 P62 R11
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z6.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I-.678 J1.011 P1  F42000
G1 X106.2 Y100.557 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X106.3 Y100.557 E.00297
G1 X106.4 Y100.557 E.00297
G1 X106.5 Y100.557 E.00297
G1 X106.6 Y100.557 E.00297
G1 X106.7 Y100.557 E.00297
G1 X106.8 Y100.557 E.00297
G1 X106.9 Y100.557 E.00297
G1 X107 Y100.557 E.00297
G1 X107.1 Y100.557 E.00297
G1 X107.2 Y100.557 E.00297
G1 X107.3 Y100.557 E.00297
G1 X107.4 Y100.557 E.00297
G1 X107.5 Y100.557 E.00297
G1 X107.6 Y100.557 E.00297
G1 X107.7 Y100.557 E.00297
G1 X109.443 Y100.557 E.05175
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X107.361 Y106.443 E.06182
G1 X107.279 Y106.443 E.00244
G1 X107.196 Y106.443 E.00244
G1 X107.114 Y106.443 E.00244
G1 X107.032 Y106.443 E.00244
G1 X106.95 Y106.443 E.00244
G1 X106.868 Y106.443 E.00244
G1 X106.786 Y106.443 E.00244
G1 X106.704 Y106.443 E.00244
G1 X106.621 Y106.443 E.00244
G1 X106.539 Y106.443 E.00244
G1 X106.457 Y106.443 E.00244
G1 X106.375 Y106.443 E.00244
G1 X106.293 Y106.443 E.00244
G1 X106.211 Y106.443 E.00244
G1 X106.129 Y106.443 E.00244
G1 X106.046 Y106.443 E.00244
G1 X105.964 Y106.443 E.00244
G1 X105.882 Y106.443 E.00244
G1 X105.8 Y106.443 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X102.2 Y106.443 E.10689
M106 S193.8
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X102.1 Y106.443 E.00297
G1 X102 Y106.443 E.00297
G1 X101.9 Y106.443 E.00297
G1 X101.8 Y106.443 E.00297
G1 X101.7 Y106.443 E.00297
G1 X101.6 Y106.443 E.00297
G1 X101.5 Y106.443 E.00297
G1 X101.4 Y106.443 E.00297
G1 X101.3 Y106.443 E.00297
G1 X101.2 Y106.443 E.00297
G1 X101.1 Y106.443 E.00297
G1 X101 Y106.443 E.00297
G1 X100.9 Y106.443 E.00297
G1 X100.8 Y106.443 E.00297
G1 X100.7 Y106.443 E.00297
G1 X100.6 Y106.443 E.00297
G1 X100.5 Y106.443 E.00297
G1 X100.4 Y106.443 E.00297
G1 X100.3 Y106.443 E.00297
G1 X98.557 Y106.443 E.05175
G1 X98.557 Y100.557 E.17475
G1 X100.639 Y100.557 E.06182
G1 X100.721 Y100.557 E.00244
G1 X100.803 Y100.557 E.00244
G1 X100.886 Y100.557 E.00244
G1 X100.968 Y100.557 E.00244
G1 X101.05 Y100.557 E.00244
G1 X101.132 Y100.557 E.00244
G1 X101.214 Y100.557 E.00244
G1 X101.296 Y100.557 E.00244
G1 X101.379 Y100.557 E.00244
G1 X101.461 Y100.557 E.00244
G1 X101.543 Y100.557 E.00244
G1 X101.625 Y100.557 E.00244
G1 X101.707 Y100.557 E.00244
G1 X101.789 Y100.557 E.00244
G1 X101.871 Y100.557 E.00244
G1 X101.954 Y100.557 E.00244
G1 X102.036 Y100.557 E.00244
G1 X102.118 Y100.557 E.00244
G1 X102.2 Y100.557 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X105.8 Y100.557 E.10689
M106 S193.8
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X105.9 Y100.557 E.00297
G1 X106 Y100.557 E.00297
G1 X106.1 Y100.557 E.00297
G1 X106.14 Y100.557 E.00119
M204 S250
G1 X106.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X106.3 Y100.2 E.00297
G1 X106.4 Y100.2 E.00297
G1 X106.5 Y100.2 E.00297
G1 X106.6 Y100.2 E.00297
G1 X106.7 Y100.2 E.00297
G1 X106.8 Y100.2 E.00297
G1 X106.9 Y100.2 E.00297
G1 X107 Y100.2 E.00297
G1 X107.1 Y100.2 E.00297
G1 X107.2 Y100.2 E.00297
G1 X107.3 Y100.2 E.00297
G1 X107.4 Y100.2 E.00297
G1 X107.5 Y100.2 E.00297
G1 X107.6 Y100.2 E.00297
G1 X107.7 Y100.2 E.00297
G1 X109.8 Y100.2 E.06235
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X107.7 Y106.8 E.06235
G1 X107.6 Y106.8 E.00297
G1 X107.5 Y106.8 E.00297
G1 X107.4 Y106.8 E.00297
G1 X107.3 Y106.8 E.00297
G1 X107.2 Y106.8 E.00297
G1 X107.1 Y106.8 E.00297
G1 X107 Y106.8 E.00297
G1 X106.9 Y106.8 E.00297
G1 X106.8 Y106.8 E.00297
G1 X106.7 Y106.8 E.00297
G1 X106.6 Y106.8 E.00297
G1 X106.5 Y106.8 E.00297
G1 X106.4 Y106.8 E.00297
G1 X106.3 Y106.8 E.00297
G1 X106.2 Y106.8 E.00297
G1 X106.1 Y106.8 E.00297
G1 X106 Y106.8 E.00297
G1 X105.9 Y106.8 E.00297
G1 X105.8 Y106.8 E.00297
M204 S250
G1 X105.8 Y106.8 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X102.2 Y106.8 E.10689
M106 S193.8
; FEATURE: Outer wall
G1 F1680.343
G1 X102.1 Y106.8 E.00297
G1 X102 Y106.8 E.00297
G1 X101.9 Y106.8 E.00297
G1 X101.8 Y106.8 E.00297
G1 X101.7 Y106.8 E.00297
G1 X101.6 Y106.8 E.00297
G1 X101.5 Y106.8 E.00297
G1 X101.4 Y106.8 E.00297
G1 X101.3 Y106.8 E.00297
G1 X101.2 Y106.8 E.00297
G1 X101.1 Y106.8 E.00297
G1 X101 Y106.8 E.00297
G1 X100.9 Y106.8 E.00297
G1 X100.8 Y106.8 E.00297
G1 X100.7 Y106.8 E.00297
G1 X100.6 Y106.8 E.00297
G1 X100.5 Y106.8 E.00297
G1 X100.4 Y106.8 E.00297
G1 X100.3 Y106.8 E.00297
G1 X98.2 Y106.8 E.06235
G1 X98.2 Y100.2 E.19596
G1 X100.3 Y100.2 E.06235
G1 X100.4 Y100.2 E.00297
G1 X100.5 Y100.2 E.00297
G1 X100.6 Y100.2 E.00297
G1 X100.7 Y100.2 E.00297
G1 X100.8 Y100.2 E.00297
G1 X100.9 Y100.2 E.00297
G1 X101 Y100.2 E.00297
G1 X101.1 Y100.2 E.00297
G1 X101.2 Y100.2 E.00297
G1 X101.3 Y100.2 E.00297
G1 X101.4 Y100.2 E.00297
G1 X101.5 Y100.2 E.00297
G1 X101.6 Y100.2 E.00297
G1 X101.7 Y100.2 E.00297
G1 X101.8 Y100.2 E.00297
G1 X101.9 Y100.2 E.00297
G1 X102 Y100.2 E.00297
G1 X102.1 Y100.2 E.00297
G1 X102.2 Y100.2 E.00297
M204 S250
G1 X102.2 Y100.2 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X105.8 Y100.2 E.10689
M106 S193.8
; FEATURE: Outer wall
G1 F1680.343
G1 X105.9 Y100.2 E.00297
G1 X106 Y100.2 E.00297
G1 X106.1 Y100.2 E.00297
G1 X106.14 Y100.2 E.00119
G1 X106.739 Y100.87 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.41864
M106 S255
G1 F1500
M204 S6000
G1 X101.422 Y100.87 E.16613
G1 X101.422 Y101.246 E.01174
G1 X106.578 Y101.246 E.16111
G1 X106.578 Y101.621 E.01174
G1 X101.422 Y101.621 E.16111
G1 X101.422 Y101.997 E.01174
G1 X106.578 Y101.997 E.16111
G1 X106.578 Y102.373 E.01174
G1 X101.422 Y102.373 E.16111
G1 X101.422 Y102.749 E.01174
G1 X106.578 Y102.749 E.16111
G1 X106.578 Y103.124 E.01174
G1 X101.422 Y103.124 E.16111
G1 X101.422 Y103.5 E.01174
G1 X106.578 Y103.5 E.16111
G1 X106.578 Y103.876 E.01174
G1 X101.422 Y103.876 E.16111
G1 X101.422 Y104.251 E.01174
G1 X106.578 Y104.251 E.16111
G1 X106.578 Y104.627 E.01174
G1 X101.422 Y104.627 E.16111
G1 X101.422 Y105.003 E.01174
G1 X106.578 Y105.003 E.16111
G1 X106.578 Y105.379 E.01174
M73 P63 R11
G1 X101.422 Y105.379 E.16111
G1 X101.422 Y105.754 E.01174
G1 X106.578 Y105.754 E.16111
G1 X106.578 Y106.13 E.01174
G1 X101.261 Y106.13 E.16613
M106 S193.8
M204 S500
G1 X99.989 Y105.011 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4079
G1 F1643.926
M204 S6000
G1 X99.989 Y102.049 E.08987
M204 S500
G1 X100.35 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.628 Y101.628 E.02144
G1 X99.628 Y105.372 E.11115
G1 X100.35 Y105.372 E.02144
G1 X100.35 Y101.688 E.10936
M204 S500
G1 X100.707 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y101.271 E.04264
G1 X99.271 Y105.729 E.13235
G1 X100.707 Y105.729 E.04264
G1 X100.707 Y101.331 E.13057
M204 S500
G1 X101.064 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y100.914 E.06384
G1 X98.914 Y106.086 E.15355
G1 X101.064 Y106.086 E.06384
G1 X101.064 Y100.974 E.15177
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I-.611 J1.052 P1  F42000
G1 X108.011 Y105.011 Z6.6
G1 Z6.2
G1 E.8 F1800
; LINE_WIDTH: 0.40788
G1 F1644.016
M204 S6000
G1 X108.011 Y102.049 E.08987
M204 S500
G1 X107.65 Y101.628 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X107.65 Y105.372 E.11114
G1 X108.372 Y105.372 E.02144
G1 X108.372 Y101.628 E.11114
G1 X107.71 Y101.628 E.01966
M204 S500
G1 X107.293 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X107.293 Y105.729 E.13235
G1 X108.729 Y105.729 E.04264
G1 X108.729 Y101.271 E.13235
G1 X107.353 Y101.271 E.04086
M204 S500
G1 X106.936 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X106.936 Y106.086 E.15355
G1 X109.086 Y106.086 E.06384
G1 X109.086 Y100.914 E.15355
G1 X106.996 Y100.914 E.06206
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I.35 J1.166 P1  F42000
G1 X118.557 Y97.443 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z6.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I.166 J-1.206 P1  F42000
G1 X83.443 Y92.137 Z6.6
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.0553
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.077 E.01545
M204 S250
G1 X83.8 Y92.137 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.0553
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.077 E.02605
G1 E-.8 F1800
G17
G3 Z6.8 I1.217 J0 P1  F42000
G1 X83.139 Y93.996
G1 Z6.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y92.567 E.04241
G1 X78.861 Y93.714 E.13153
G1 X78.861 Y95.185 E.04367
G1 X83.139 Y99.464 E.17967
G1 X83.139 Y98.113 E.04012
G1 X78.861 Y99.259 E.13153
G1 X78.861 Y99.324 E.00193
G1 X80.86 Y91.861 E.22942
G1 X79.432 Y91.861 E.04241
M204 S500
G1 X78.861 Y101.331 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y102.76 E.04241
G1 X82.24 Y106.139 E.14191
G1 X82.58 Y106.139 E.01007
G1 X83.139 Y104.05 E.06423
G1 X83.139 Y103.658 E.01164
G1 X78.861 Y104.804 E.13153
G1 X78.861 Y106.139 E.03964
G1 X78.954 Y106.139 E.00277
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I.439 J1.135 P1  F42000
G1 X101.443 Y97.443 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z6.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
M73 P64 R11
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z6.8 I-.853 J.868 P1  F42000
G1 X101.5 Y103.5 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X106.44 Y103.5 E.21763
M204 S500
G1 X101.057 Y103.057 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X101.057 Y103.943 E.02633
G1 X106.943 Y103.943 E.17479
G1 X106.943 Y103.057 E.02633
G1 X101.117 Y103.057 E.173
M204 S500
G1 X100.699 Y102.7 F42000
G1 F1680.343
M204 S6000
G1 X100.699 Y104.301 E.04754
G1 X107.301 Y104.301 E.19599
G1 X107.301 Y102.7 E.04754
G1 X100.759 Y102.7 E.19421
M204 S500
G1 X100.342 Y102.342 F42000
G1 F1680.343
M204 S6000
G1 X100.342 Y104.658 E.06874
G1 X107.658 Y104.658 E.21719
G1 X107.658 Y102.342 E.06874
G1 X100.402 Y102.342 E.21541
M204 S500
G1 X99.985 Y101.985 F42000
G1 F1680.343
M204 S6000
G1 X99.985 Y105.015 E.08994
G1 X108.015 Y105.015 E.23839
G1 X108.015 Y101.985 E.08994
G1 X100.045 Y101.985 E.23661
M204 S500
G1 X99.628 Y101.628 F42000
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.2596
G1 X108.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.25782
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.2808
G1 X108.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.27902
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.302
G1 X109.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.30022
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I.212 J1.198 P1  F42000
G1 X118.557 Y97.443 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z6.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 6.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I.164 J-1.206 P1  F42000
G1 X83.443 Y92.206 Z6.8
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.05325
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.146 E.0175
M204 S250
G1 X83.8 Y92.206 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.05325
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.146 E.0281
G1 E-.8 F1800
G17
G3 Z7 I1.217 J0 P1  F42000
G1 X83.139 Y94.142
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y92.714 E.04241
G1 X78.861 Y93.86 E.13153
G1 X78.861 Y94.985 E.03339
G1 X83.139 Y99.264 E.17967
G1 X83.139 Y98.259 E.02983
M73 P65 R11
G1 X78.861 Y99.406 E.13153
G1 X78.861 Y98.778 E.01864
G1 X80.714 Y91.861 E.21262
G1 X79.286 Y91.861 E.04241
M204 S500
G1 X78.861 Y101.131 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y102.56 E.04241
G1 X82.433 Y106.139 E.15016
G1 X83.139 Y103.504 E.08102
G1 X83.139 Y103.804 E.00893
G1 X78.861 Y104.951 E.13153
G1 X78.861 Y106.139 E.0353
G1 X79.1 Y106.139 E.00711
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I.441 J1.134 P1  F42000
G1 X101.443 Y97.443 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z7 I.846 J-.875 P1  F42000
G1 X100 Y96 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z7 I-.336 J1.17 P1  F42000
G1 X101.729 Y101.275 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X101.729 Y102.703 E.04241
G1 X99.886 Y100.861 E.07738
G1 X100.483 Y100.861 E.01773
G1 X99.069 Y106.139 E.16227
G1 X98.861 Y106.139 E.00618
G1 X98.861 Y105.137 E.02977
G1 X101.729 Y104.368 E.08816
G1 X101.729 Y105.797 E.04241
M204 S500
G1 X106.271 Y104.579 F42000
G1 F1680.297
M204 S6000
G1 X106.271 Y103.151 E.04241
G1 X109.139 Y102.383 E.08816
G1 X109.139 Y102.539 E.00466
G1 X107.461 Y100.861 E.0705
G1 X106.271 Y100.861 E.03531
G1 X106.271 Y101.1 E.0071
M204 S500
G1 X102.086 Y100.914 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X102.086 Y106.086 E.15355
G1 X105.914 Y106.086 E.11368
G1 X105.914 Y100.914 E.15355
G1 X102.146 Y100.914 E.1119
M204 S500
G1 X102.443 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X102.443 Y105.729 E.13235
G1 X105.557 Y105.729 E.09248
G1 X105.557 Y101.271 E.13235
G1 X102.503 Y101.271 E.09069
M204 S500
M73 P65 R10
G1 X102.8 Y101.628 F42000
G1 F1680.343
M204 S6000
G1 X102.8 Y105.372 E.11115
G1 X105.2 Y105.372 E.07127
G1 X105.2 Y101.628 E.11115
G1 X102.86 Y101.628 E.06949
M204 S500
G1 X103.157 Y101.985 F42000
G1 F1680.343
M204 S6000
G1 X103.157 Y105.015 E.08994
G1 X104.843 Y105.015 E.05007
G1 X104.843 Y101.985 E.08994
G1 X103.217 Y101.985 E.04829
M204 S500
G1 X103.514 Y102.342 F42000
G1 F1680.343
M204 S6000
G1 X103.514 Y104.658 E.06874
G1 X104.486 Y104.658 E.02887
G1 X104.486 Y102.342 E.06874
G1 X103.574 Y102.342 E.02708
M204 S500
G1 X103.846 Y102.675 F42000
; LINE_WIDTH: 0.3505
G1 F1950.712
M204 S6000
G1 X103.846 Y104.325 E.04221
G1 X104.154 Y104.325 E.00787
G1 X104.154 Y102.675 E.04221
G1 X103.906 Y102.675 E.00633
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I.409 J1.146 P1  F42000
G1 X118.557 Y97.443 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z7 I.875 J.846 P1  F42000
G1 X120 Y96 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 6.8
; LAYER_HEIGHT: 0.2
M106 S196.35
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I.162 J-1.206 P1  F42000
G1 X83.443 Y92.275 Z7
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.05121
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
M73 P66 R10
G1 X83.443 Y92.215 E.01954
M204 S250
G1 X83.8 Y92.275 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.05121
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.215 E.03014
G1 E-.8 F1800
G17
G3 Z7.2 I1.217 J0 P1  F42000
G1 X83.139 Y94.289
G1 Z6.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y92.86 E.04241
G1 X78.861 Y94.007 E.13153
G1 X78.861 Y94.785 E.0231
G1 X83.139 Y99.064 E.17967
G1 X83.139 Y98.405 E.01955
G1 X78.861 Y99.552 E.13153
G1 X78.861 Y98.231 E.03921
G1 X80.568 Y91.861 E.19583
G1 X79.139 Y91.861 E.04241
M204 S500
G1 X83.139 Y101.529 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y102.957 E.04241
G1 X82.287 Y106.139 E.09782
G1 X82.64 Y106.139 E.0105
G1 X78.861 Y102.36 E.15871
G1 X78.861 Y105.097 E.08128
G1 X83.139 Y103.951 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I.408 J1.147 P1  F42000
G1 X101.443 Y97.443 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z7.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z7.2 I-1.208 J.146 P1  F42000
G1 X98.887 Y105.961 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383185
G1 F1763.331
M204 S6000
G1 X98.914 Y106.087 E.00363
G1 X99.039 Y106.113 E.00363
G1 X108.961 Y106.113 E.28071
G1 X109.086 Y106.087 E.00363
G1 X109.113 Y105.961 E.00363
G1 X109.113 Y101.039 E.13924
G1 X109.086 Y100.914 E.00363
G1 X108.961 Y100.887 E.00363
G1 X99.039 Y100.887 E.28071
G1 X98.914 Y100.914 E.00363
G1 X98.887 Y101.039 E.00363
G1 X98.887 Y105.901 E.13754
M204 S500
G1 X104.358 Y101.218 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X105.786 Y101.218 E.04241
G1 X104.563 Y105.782 E.14031
G1 X105.007 Y105.782 E.0132
G1 X100.443 Y101.218 E.19166
G1 X100.241 Y101.218 E.006
G1 X99.218 Y105.036 E.11738
G1 X99.218 Y105.188 E.00449
G1 X108.782 Y102.625 E.294
G1 X108.782 Y101.982 E.01908
G1 X108.018 Y101.218 E.0321
G1 X106.589 Y101.218 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I.366 J1.161 P1  F42000
G1 X118.557 Y97.443 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z7.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
M73 P67 R10
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 7
; LAYER_HEIGHT: 0.2
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I.159 J-1.206 P1  F42000
G1 X83.443 Y92.344 Z7.2
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.04917
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.284 E.02158
M204 S250
G1 X83.8 Y92.344 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.04917
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.284 E.03218
G1 E-.8 F1800
G17
G3 Z7.4 I1.217 J0 P1  F42000
G1 X81.85 Y91.861
G1 Z7
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.421 Y91.861 E.04241
G1 X78.861 Y97.685 E.17903
G1 X78.861 Y99.698 E.05978
G1 X83.139 Y98.552 E.13153
G1 X83.139 Y98.864 E.00926
G1 X78.861 Y94.585 E.17967
G1 X78.861 Y94.153 E.01282
G1 X83.139 Y93.007 E.13153
G1 X83.139 Y94.435 E.04241
M204 S500
G1 X83.139 Y100.982 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y102.411 E.04241
G1 X82.14 Y106.139 E.11462
G1 X82.84 Y106.139 E.02078
G1 X78.861 Y102.16 E.16711
G1 X78.861 Y105.244 E.09156
G1 X83.139 Y104.097 E.13153
G1 X83.139 Y105.525 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I.492 J1.113 P1  F42000
G1 X101.443 Y97.443 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z7.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z7.4 I-1.212 J.114 P1  F42000
G1 X98.705 Y105.617 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40537
; LAYER_HEIGHT: 0.4
M106 S255
G1 F929.797
M204 S6000
G1 X100.482 Y106.093 E.09872
G1 X102.241 Y106.093 E.0944
G1 X98.907 Y105.2 E.1852
G1 X98.907 Y104.728 E.0253
G1 X104 Y106.093 E.28294
G1 X105.76 Y106.093 E.0944
G1 X98.907 Y104.257 E.38067
G1 X98.907 Y103.785 E.0253
G1 X107.519 Y106.093 E.47841
G1 X109.093 Y106.093 E.08444
G1 X109.093 Y106.043 E.00267
G1 X98.907 Y103.314 E.56583
G1 X98.907 Y102.842 E.0253
G1 X109.093 Y105.572 E.56583
G1 X109.093 Y105.1 E.0253
G1 X98.907 Y102.371 E.56583
G1 X98.907 Y101.9 E.0253
G1 X109.093 Y104.629 E.56583
G1 X109.093 Y104.157 E.0253
M73 P68 R10
G1 X98.907 Y101.428 E.56583
G1 X98.907 Y100.957 E.0253
G1 X109.093 Y103.686 E.56583
G1 X109.093 Y103.215 E.0253
G1 X100.481 Y100.907 E.47839
G1 X102.24 Y100.907 E.0944
G1 X109.093 Y102.743 E.38066
G1 X109.093 Y102.272 E.0253
G1 X104 Y100.907 E.28292
G1 X105.759 Y100.907 E.0944
G1 X109.093 Y101.8 E.18519
G1 X109.093 Y101.329 E.0253
G1 X106.763 Y100.705 E.12943
M106 S191.25
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I.324 J1.173 P1  F42000
G1 X118.557 Y97.443 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z7.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 7.2
; LAYER_HEIGHT: 0.2
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I.157 J-1.207 P1  F42000
G1 X83.443 Y92.412 Z7.4
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.04715
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.352 E.0236
M204 S250
G1 X83.8 Y92.412 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.04715
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.352 E.0342
G1 E-.8 F1800
G17
G3 Z7.6 I1.217 J0 P1  F42000
G1 X78.861 Y98.567
G1 Z7.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y97.139 E.04241
G1 X80.275 Y91.861 E.16224
G1 X83.139 Y91.861 E.08505
G1 X83.139 Y93.153 E.03838
G1 X78.861 Y94.3 E.13153
G1 X78.861 Y94.385 E.00253
G1 X83.139 Y98.664 E.17967
G1 X83.139 Y98.698 E.00102
G1 X78.861 Y99.845 E.13153
G1 X78.861 Y101.96 E.0628
G1 X83.04 Y106.139 E.1755
G1 X81.994 Y106.139 E.03107
G1 X83.139 Y101.864 E.13141
G1 X83.139 Y100.436 E.04241
M204 S500
G1 X83.139 Y105.672 F42000
M73 P68 R9
G1 F1680.297
M204 S6000
G1 X83.139 Y104.243 E.04241
G1 X78.861 Y105.39 E.13153
G1 X78.861 Y106.139 E.02225
G1 X79.539 Y106.139 E.02015
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I.449 J1.131 P1  F42000
G1 X101.443 Y97.443 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z7.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z7.6
M73 P69 R9
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z7.6 I-.853 J.868 P1  F42000
G1 X101.5 Y103.5 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X106.44 Y103.5 E.21763
M204 S500
G1 X101.057 Y103.057 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X101.057 Y103.943 E.02633
G1 X106.943 Y103.943 E.17479
G1 X106.943 Y103.057 E.02633
G1 X101.117 Y103.057 E.173
M204 S500
G1 X100.699 Y102.7 F42000
G1 F1680.343
M204 S6000
G1 X100.699 Y104.301 E.04754
G1 X107.301 Y104.301 E.19599
G1 X107.301 Y102.7 E.04754
G1 X100.759 Y102.7 E.19421
M204 S500
G1 X100.342 Y102.342 F42000
G1 F1680.343
M204 S6000
G1 X100.342 Y104.658 E.06874
G1 X107.658 Y104.658 E.21719
G1 X107.658 Y102.342 E.06874
G1 X100.402 Y102.342 E.21541
M204 S500
G1 X99.985 Y101.985 F42000
G1 F1680.343
M204 S6000
G1 X99.985 Y105.015 E.08994
G1 X108.015 Y105.015 E.23839
G1 X108.015 Y101.985 E.08994
G1 X100.045 Y101.985 E.23661
M204 S500
G1 X99.628 Y101.628 F42000
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.2596
G1 X108.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.25782
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.2808
G1 X108.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.27902
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.302
G1 X109.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.30022
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I.212 J1.198 P1  F42000
G1 X118.557 Y97.443 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z7.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 7.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I.155 J-1.207 P1  F42000
G1 X83.443 Y92.479 Z7.6
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.04515
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.419 E.0256
M204 S250
G1 X83.8 Y92.479 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.04515
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.419 E.0362
G1 E-.8 F1800
G17
G3 Z7.8 I1.217 J0 P1  F42000
G1 X78.861 Y98.02
G1 Z7.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y96.592 E.04241
G1 X80.128 Y91.861 E.14544
G1 X83.139 Y91.861 E.0894
G1 X83.139 Y93.3 E.04272
G1 X78.861 Y94.446 E.13153
M73 P70 R9
G1 X78.861 Y94.185 E.00775
G1 X83.139 Y98.464 E.17967
G1 X83.139 Y98.845 E.01131
G1 X78.861 Y99.991 E.13153
G1 X78.861 Y101.76 E.05251
G1 X83.139 Y106.039 E.17967
G1 X83.139 Y106.139 E.00299
G1 X81.847 Y106.139 E.03836
G1 X83.139 Y101.318 E.14821
G1 X83.139 Y99.89 E.04241
M204 S500
G1 X83.139 Y102.962 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y104.39 E.04241
G1 X78.861 Y105.536 E.13153
G1 X78.861 Y104.108 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I.344 J1.167 P1  F42000
G1 X101.443 Y97.443 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z7.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I-.992 J-.705 P1  F42000
G1 X98.557 Y100.557 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X109.443 Y100.557 E.32321
G1 X109.443 Y103.5 E.08738
G1 X109.443 Y106.443 E.08738
G1 X98.557 Y106.443 E.32321
G1 X98.557 Y100.617 E.17297
M204 S250
G1 X98.2 Y100.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 E-.8 F1800
G17
G3 Z7.8 I-.853 J.868 P1  F42000
G1 X101.5 Y103.5 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X106.44 Y103.5 E.21763
M204 S500
G1 X101.057 Y103.057 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X101.057 Y103.943 E.02633
G1 X106.943 Y103.943 E.17479
G1 X106.943 Y103.057 E.02633
G1 X101.117 Y103.057 E.173
M204 S500
G1 X100.699 Y102.7 F42000
G1 F1680.343
M204 S6000
G1 X100.699 Y104.301 E.04754
G1 X107.301 Y104.301 E.19599
G1 X107.301 Y102.7 E.04754
G1 X100.759 Y102.7 E.19421
M204 S500
G1 X100.342 Y102.342 F42000
G1 F1680.343
M204 S6000
G1 X100.342 Y104.658 E.06874
G1 X107.658 Y104.658 E.21719
G1 X107.658 Y102.342 E.06874
G1 X100.402 Y102.342 E.21541
M204 S500
G1 X99.985 Y101.985 F42000
G1 F1680.343
M204 S6000
G1 X99.985 Y105.015 E.08994
G1 X108.015 Y105.015 E.23839
G1 X108.015 Y101.985 E.08994
G1 X100.045 Y101.985 E.23661
M204 S500
G1 X99.628 Y101.628 F42000
G1 F1680.343
M204 S6000
G1 X99.628 Y105.372 E.11115
G1 X108.372 Y105.372 E.2596
G1 X108.372 Y101.628 E.11115
G1 X99.688 Y101.628 E.25782
M204 S500
G1 X99.271 Y101.271 F42000
G1 F1680.343
M204 S6000
G1 X99.271 Y105.729 E.13235
G1 X108.729 Y105.729 E.2808
G1 X108.729 Y101.271 E.13235
G1 X99.331 Y101.271 E.27902
M204 S500
G1 X98.914 Y100.914 F42000
G1 F1680.343
M204 S6000
G1 X98.914 Y106.086 E.15355
G1 X109.086 Y106.086 E.302
G1 X109.086 Y100.914 E.15355
G1 X98.974 Y100.914 E.30022
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I.212 J1.198 P1  F42000
G1 X118.557 Y97.443 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z7.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
M73 P71 R9
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 7.6
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I.152 J-1.207 P1  F42000
G1 X83.443 Y92.546 Z7.8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.04318
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.486 E.02757
M204 S250
G1 X83.8 Y92.546 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.04318
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.486 E.03817
G1 E-.8 F1800
G17
G3 Z8 I1.217 J0 P1  F42000
G1 X83.139 Y99.343
G1 Z7.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y100.771 E.04241
G1 X81.701 Y106.139 E.165
G1 X78.861 Y106.139 E.08434
G1 X78.861 Y105.683 E.01356
G1 X83.139 Y104.536 E.13153
G1 X83.139 Y105.839 E.03867
G1 X78.861 Y101.56 E.17967
G1 X78.861 Y100.138 E.04223
G1 X83.139 Y98.991 E.13153
G1 X83.139 Y98.264 E.02159
G1 X78.861 Y93.985 E.17967
G1 X78.861 Y94.592 E.01804
G1 X83.139 Y93.446 E.13153
G1 X83.139 Y91.861 E.04707
G1 X79.982 Y91.861 E.09375
G1 X78.861 Y96.046 E.12865
G1 X78.861 Y97.474 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8 I.002 J1.217 P1  F42000
G1 X101.443 Y97.443 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z8 I-.901 J-.818 P1  F42000
G1 X98.2 Y100.2 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Outer wall
G1 F1680.343
G1 X109.8 Y100.2 E.34441
G1 X109.8 Y103.5 E.09798
G1 X109.8 Y106.8 E.09798
G1 X98.2 Y106.8 E.34441
G1 X98.2 Y100.26 E.19418
G1 X99.066 Y100.343 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.40051
G1 F1677.899
G1 X98.503 Y100.905 E.02365
G1 X98.503 Y101.411 E.01504
G1 X99.411 Y100.504 E.03816
G1 X99.917 Y100.504 E.01504
G1 X98.503 Y101.917 E.05942
G1 X98.503 Y102.422 E.01504
G1 X100.422 Y100.504 E.08069
G1 X100.928 Y100.504 E.01504
G1 X98.503 Y102.928 E.10195
G1 X98.503 Y103.434 E.01504
G1 X101.434 Y100.504 E.12322
G1 X101.94 Y100.504 E.01504
G1 X98.503 Y103.94 E.14448
G1 X98.503 Y104.445 E.01504
G1 X102.445 Y100.504 E.16575
G1 X102.951 Y100.504 E.01504
G1 X98.503 Y104.951 E.18701
G1 X98.503 Y105.457 E.01504
G1 X103.457 Y100.504 E.20828
G1 X103.962 Y100.504 E.01504
G1 X98.503 Y105.962 E.22954
G1 X98.503 Y106.468 E.01504
G1 X104.468 Y100.504 E.25081
G1 X104.974 Y100.504 E.01504
G1 X98.981 Y106.497 E.252
G1 X99.486 Y106.497 E.01504
G1 X105.479 Y100.504 E.252
G1 X105.985 Y100.504 E.01504
M73 P71 R8
G1 X99.992 Y106.497 E.252
G1 X100.498 Y106.497 E.01504
G1 X106.491 Y100.504 E.252
G1 X106.997 Y100.504 E.01504
G1 X101.004 Y106.497 E.252
G1 X101.509 Y106.497 E.01504
G1 X107.502 Y100.504 E.252
G1 X108.008 Y100.504 E.01504
G1 X102.015 Y106.497 E.252
G1 X102.521 Y106.497 E.01504
G1 X108.514 Y100.504 E.252
G1 X109.019 Y100.504 E.01504
G1 X103.026 Y106.497 E.252
M73 P72 R8
G1 X103.532 Y106.497 E.01504
G1 X109.497 Y100.532 E.2508
G1 X109.497 Y101.038 E.01504
G1 X104.038 Y106.497 E.22954
G1 X104.544 Y106.497 E.01504
G1 X109.497 Y101.544 E.20827
G1 X109.497 Y102.049 E.01504
G1 X105.049 Y106.497 E.18701
G1 X105.555 Y106.497 E.01504
G1 X109.497 Y102.555 E.16574
G1 X109.497 Y103.061 E.01504
G1 X106.061 Y106.497 E.14448
G1 X106.566 Y106.497 E.01504
G1 X109.497 Y103.566 E.12321
G1 X109.497 Y104.072 E.01504
G1 X107.072 Y106.497 E.10195
G1 X107.578 Y106.497 E.01504
G1 X109.497 Y104.578 E.08068
G1 X109.497 Y105.084 E.01504
G1 X108.084 Y106.497 E.05942
G1 X108.589 Y106.497 E.01504
G1 X109.497 Y105.589 E.03815
G1 X109.497 Y106.095 E.01504
G1 X108.934 Y106.657 E.02364
G1 E-.8 F1800
G17
G3 Z8 I.842 J.879 P1  F42000
G1 X118.557 Y97.443 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z8 I.875 J.846 P1  F42000
G1 X120 Y96 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 7.8
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8 I.15 J-1.208 P1  F42000
G1 X83.443 Y92.611 Z8
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.04123
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.551 E.02952
M204 S250
G1 X83.8 Y92.611 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.04123
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.551 E.04012
G1 E-.8 F1800
G17
G3 Z8.2 I1.217 J0 P1  F42000
G1 X83.139 Y92.164
G1 Z7.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.592 E.04241
G1 X78.861 Y94.739 E.13153
M204 S500
G1 X78.861 Y96.928 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y95.499 E.04241
G1 X79.836 Y91.861 E.11185
G1 X78.861 Y91.861 E.02895
G1 X78.861 Y93.785 E.05714
G1 X83.139 Y98.064 E.17967
G1 X83.139 Y99.138 E.03188
G1 X78.861 Y100.284 E.13153
G1 X78.861 Y101.36 E.03194
G1 X83.139 Y105.639 E.17967
G1 X83.139 Y104.683 E.02838
G1 X78.861 Y105.829 E.13153
G1 X78.861 Y106.139 E.00921
G1 X81.555 Y106.139 E.07999
G1 X83.139 Y100.225 E.1818
G1 X83.139 Y99.316 E.02699
G1 E-.8 F1800
M204 S500
G17
G3 Z8.2 I.124 J1.211 P1  F42000
G1 X101.443 Y97.443 Z8.2
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z8.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z8.2
G1 Z7.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z8.2 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z8.2
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
M73 P73 R8
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z8.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z8.2
G1 Z7.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.2 I.148 J-1.208 P1  F42000
G1 X83.443 Y92.676 Z8.2
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.03933
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.616 E.03143
M204 S250
G1 X83.8 Y92.676 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.03933
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.616 E.04203
G1 E-.8 F1800
G17
G3 Z8.4 I1.217 J0 P1  F42000
G1 X83.139 Y92.31
G1 Z8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.739 E.04241
G1 X78.861 Y94.885 E.13153
G1 X78.861 Y94.953 E.00201
G1 X79.689 Y91.861 E.09505
G1 X78.861 Y91.861 E.0246
G1 X78.861 Y93.585 E.0512
G1 X83.139 Y97.864 E.17967
G1 X83.139 Y96.436 E.04241
M204 S500
G1 X78.861 Y104.547 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y105.976 E.04241
G1 X83.139 Y104.829 E.13153
G1 X83.139 Y105.439 E.0181
G1 X78.861 Y101.16 E.17967
G1 X78.861 Y100.43 E.02165
G1 X83.139 Y99.284 E.13153
G1 X83.139 Y99.679 E.01172
G1 X81.408 Y106.139 E.1986
G1 X79.98 Y106.139 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8.4 I.457 J1.128 P1  F42000
G1 X101.443 Y97.443 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z8.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z8.4 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z8.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 8.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.4 I.146 J-1.208 P1  F42000
G1 X83.443 Y92.738 Z8.4
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.03746
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
M73 P74 R8
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.678 E.03329
M204 S250
G1 X83.8 Y92.738 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.03746
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.678 E.0439
G1 E-.8 F1800
G17
G3 Z8.6 I1.217 J0 P1  F42000
G1 X80.971 Y91.861
G1 Z8.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X79.543 Y91.861 E.04241
G1 X78.861 Y94.406 E.07826
G1 X78.861 Y95.032 E.01856
G1 X83.139 Y93.885 E.13153
G1 X83.139 Y97.664 E.11219
G1 X78.861 Y93.385 E.17967
M204 S500
G1 X78.861 Y104.694 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y106.122 E.04241
G1 X83.139 Y104.975 E.13153
G1 X83.139 Y105.239 E.00781
G1 X78.861 Y100.96 E.17967
G1 X78.861 Y100.577 E.01137
G1 X83.139 Y99.43 E.13153
G1 X83.139 Y99.132 E.00885
G1 X81.262 Y106.139 E.21539
G1 X82.69 Y106.139 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8.6 I.512 J1.104 P1  F42000
G1 X101.443 Y97.443 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z8.6 I.846 J-.875 P1  F42000
G1 X100 Y96 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z8.6 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z8.6 I.875 J.846 P1  F42000
G1 X120 Y96 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 8.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.6 I.144 J-1.208 P1  F42000
G1 X83.443 Y92.8 Z8.6
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.03563
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.74 E.03512
M204 S250
G1 X83.8 Y92.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.03563
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.74 E.04572
G1 E-.8 F1800
G17
G3 Z8.8 I1.217 J0 P1  F42000
G1 X83.139 Y92.603
G1 Z8.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y94.032 E.04241
G1 X78.861 Y95.178 E.13153
G1 X78.861 Y93.86 E.03913
G1 X79.396 Y91.861 E.06146
G1 X80.825 Y91.861 E.04241
M204 S500
G1 X78.861 Y93.185 F42000
G1 F1680.297
M204 S6000
G1 X83.139 Y97.464 E.17967
G1 X83.139 Y98.586 E.03331
G1 X81.115 Y106.139 E.23219
G1 X82.544 Y106.139 E.04241
M204 S500
G1 X78.861 Y105.192 F42000
G1 F1680.297
M204 S6000
M73 P75 R7
G1 X78.861 Y106.139 E.02812
G1 X79.342 Y106.139 E.01429
G1 X83.139 Y105.122 E.11674
G1 X83.139 Y105.039 E.00247
G1 X78.861 Y100.76 E.17967
G1 X78.861 Y100.723 E.00108
G1 X83.139 Y99.577 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z8.8 I.141 J1.209 P1  F42000
G1 X101.443 Y97.443 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z8.8 I.846 J-.875 P1  F42000
G1 X100 Y96 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z8.8 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z8.8 I.875 J.846 P1  F42000
G1 X120 Y96 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 8.6
; LAYER_HEIGHT: 0.200001
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.8 I.142 J-1.209 P1  F42000
G1 X83.443 Y92.86 Z8.8
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.03384
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.8 E.03691
M204 S250
G1 X83.8 Y92.86 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.03384
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.8 E.04751
G1 E-.8 F1800
G17
G3 Z9 I1.217 J0 P1  F42000
G1 X78.861 Y96.753
G1 Z8.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y95.325 E.04241
G1 X83.139 Y94.178 E.13153
G1 X83.139 Y91.861 E.06881
G1 X79.25 Y91.861 E.11548
G1 X78.861 Y93.314 E.04467
G1 X78.861 Y92.985 E.00976
G1 X83.139 Y97.264 E.17967
G1 X83.139 Y98.039 E.02303
G1 X80.969 Y106.139 E.24898
M204 S500
G1 X78.861 Y105.739 F42000
G1 F1680.297
M204 S6000
G1 X78.861 Y106.139 E.0119
G1 X79.888 Y106.139 E.03051
G1 X83.139 Y105.268 E.09994
G1 X83.139 Y104.839 E.01276
G1 X78.861 Y100.56 E.17967
G1 X78.861 Y100.87 E.0092
G1 X83.139 Y99.723 E.13153
G1 X83.139 Y101.151 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9 I.242 J1.193 P1  F42000
G1 X101.443 Y97.443 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z9 I.846 J-.875 P1  F42000
G1 X100 Y96 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
M73 P76 R7
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z9 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z9 I.875 J.846 P1  F42000
G1 X120 Y96 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 8.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9 I.14 J-1.209 P1  F42000
G1 X83.443 Y92.919 Z9
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.0321
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.859 E.03865
M204 S250
G1 X83.8 Y92.919 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.0321
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y92.859 E.04926
G1 E-.8 F1800
G17
G3 Z9.2 I1.217 J0 P1  F42000
G1 X78.861 Y96.899
G1 Z8.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y95.471 E.04241
G1 X83.139 Y94.324 E.13153
G1 X83.139 Y91.861 E.07315
G1 X79.104 Y91.861 E.11983
G1 X78.861 Y92.767 E.02787
G1 X78.861 Y92.785 E.00053
G1 X83.139 Y97.064 E.17967
G1 X83.139 Y97.493 E.01274
G1 X80.823 Y106.139 E.26578
M204 S500
G1 X79.006 Y106.139 F42000
G1 F1680.297
M204 S6000
G1 X80.435 Y106.139 E.04241
G1 X83.139 Y105.415 E.08315
G1 X83.139 Y104.639 E.02304
G1 X78.861 Y100.36 E.17967
G1 X78.861 Y101.016 E.01949
G1 X83.139 Y99.87 E.13153
G1 X83.139 Y101.298 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9.2 I.251 J1.191 P1  F42000
G1 X101.443 Y97.443 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z9.2 I.846 J-.875 P1  F42000
G1 X100 Y96 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z9.2 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z9.2 I.875 J.846 P1  F42000
G1 X120 Y96 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
M73 P77 R7
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 9
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.2 I.103 J-1.213 P1  F42000
G1 X83.443 Y94 Z9.2
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.94 E.07075
M204 S250
G1 X83.8 Y94 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.94 E.08135
G1 E-.8 F1800
G17
G3 Z9.4 I1.217 J0 P1  F42000
G1 X83.139 Y93.043
G1 Z9
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y94.471 E.04241
G1 X78.861 Y95.617 E.13153
G1 X78.861 Y92.585 E.09004
G1 X83.139 Y96.864 E.17967
G1 X83.139 Y96.947 E.00246
G1 X80.676 Y106.139 E.28258
G1 X80.981 Y106.139 E.00905
G1 X83.139 Y105.561 E.06635
G1 X83.139 Y104.439 E.03333
G1 X78.861 Y100.16 E.17967
G1 X78.861 Y101.162 E.02977
G1 X83.139 Y100.016 E.13153
G1 X83.139 Y101.444 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9.4 I.26 J1.189 P1  F42000
G1 X101.443 Y97.443 Z9.4
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y97.443 E.08568
G1 X98.557 Y91.557 E.17475
G1 X101.443 Y91.557 E.08568
G1 X101.443 Y93 E.04284
G1 X101.443 Y97.383 E.13013
M204 S250
G1 X101.8 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y97.8 E.10689
G1 X98.2 Y91.2 E.19596
G1 X101.8 Y91.2 E.10689
G1 X101.8 Y93 E.05344
G1 X101.8 Y97.74 E.14073
G1 E-.8 F1800
G17
G3 Z9.4 I.846 J-.875 P1  F42000
G1 X100 Y96 Z9.4
G1 Z9
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.42932
G1 F1552.795
M204 S6000
G1 X100 Y93.06 E.09446
M204 S500
G1 X100.372 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.02207
G1 X99.628 Y96.372 E.11115
G1 X100.312 Y96.372 E.02029
M204 S500
G1 X100.729 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.04328
G1 X99.271 Y96.729 E.13235
G1 X100.669 Y96.729 E.0415
M204 S500
G1 X101.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.06448
G1 X98.914 Y97.086 E.15355
G1 X101.026 Y97.086 E.0627
G1 E-.8 F1800
M204 S500
G17
G3 Z9.4 I-.025 J1.217 P1  F42000
G1 X118.557 Y97.443 Z9.4
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X118.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.08568
G1 X121.443 Y93 E.04284
G1 X121.443 Y97.443 E.13191
G1 X118.617 Y97.443 E.0839
M204 S250
G1 X118.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X118.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.10689
G1 X121.8 Y93 E.05344
G1 X121.8 Y97.8 E.14251
G1 X118.26 Y97.8 E.1051
G1 E-.8 F1800
G17
G3 Z9.4 I.875 J.846 P1  F42000
G1 X120 Y96 Z9.4
G1 Z9
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4293
G1 F1552.875
M204 S6000
G1 X120 Y93.06 E.09446
M204 S500
G1 X119.628 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02207
G1 X120.372 Y92.628 E.11115
G1 X119.628 Y92.628 E.02207
G1 X119.628 Y96.312 E.10936
M204 S500
G1 X119.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04328
G1 X120.729 Y92.271 E.13235
G1 X119.271 Y92.271 E.04328
G1 X119.271 Y96.669 E.13057
M204 S500
G1 X118.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06448
G1 X121.086 Y91.914 E.15355
G1 X118.914 Y91.914 E.06448
G1 X118.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 9.2
; LAYER_HEIGHT: 0.2
M106 S181.05
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.4 I.12 J-1.211 P1  F42000
G1 X83.997 Y93.557 Z9.4
G1 Z9.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1486.488
M204 S6000
G1 X84.002 Y93.557 E.00016
G1 F1458.625
G1 X84.027 Y93.557 E.00073
G1 F1330.79
G1 X84.052 Y93.557 E.00073
G1 F1208.816
G1 X84.076 Y93.557 E.00073
G1 F1092.658
G1 X84.101 Y93.557 E.00073
G1 F982.41
G1 X84.126 Y93.557 E.00073
G1 F878.024
G1 X84.151 Y93.557 E.00073
G1 F779.499
G1 X84.175 Y93.557 E.00073
G1 F686.836
G1 X84.2 Y93.557 E.00073
; FEATURE: Overhang wall
M106 S255
G1 F600
M204 S500
G1 X92.443 Y93.557 E.24474
G1 X92.443 Y99 E.1616
M106 S181.05
M106 S255

G1 X92.443 Y104.443 E.1616
G1 X84.2 Y104.443 E.24474
M106 S181.05
; FEATURE: Inner wall
G1 F687.853
M204 S6000
G1 X84.175 Y104.443 E.00074
G1 F781.706
G1 X84.15 Y104.443 E.00074
G1 F881.558
G1 X84.125 Y104.443 E.00074
G1 F987.411
G1 X84.1 Y104.443 E.00074
G1 F1099.264
G1 X84.075 Y104.443 E.00074
G1 F1217.117
G1 X84.05 Y104.443 E.00074
G1 F1340.97
G1 X84.025 Y104.443 E.00074
G1 F1470.823
G1 X84 Y104.443 E.00074
G1 F1601.129
G1 X83.977 Y104.449 E.00071
G1 F1680.343
G1 X83.953 Y104.454 E.00071
G1 X83.93 Y104.46 E.00071
G1 X83.907 Y104.465 E.00071
G1 X83.883 Y104.471 E.00071
G1 X83.86 Y104.476 E.00071
G1 X83.837 Y104.482 E.00071
G1 X83.813 Y104.487 E.00071
G1 X83.79 Y104.493 E.00071
G1 X83.766 Y104.499 E.00071
G1 X83.743 Y104.504 E.00071
G1 X83.72 Y104.51 E.00071
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
M73 P78 R7
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.72 Y93.49 E.00713
G1 X83.743 Y93.496 E.00072
G1 X83.767 Y93.502 E.00072
G1 X83.79 Y93.509 E.00072
G1 X83.813 Y93.515 E.00072
G1 X83.837 Y93.521 E.00072
G1 X83.86 Y93.527 E.00072
G1 X83.884 Y93.533 E.00072
G1 X83.907 Y93.539 E.00072
G1 X83.931 Y93.545 E.00072
G1 X83.938 Y93.547 E.00023
M204 S250
G1 X83.857 Y93.147 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.873 Y93.161 E.00063
G1 X83.891 Y93.167 E.00055
G1 X83.908 Y93.174 E.00055
G1 X83.926 Y93.18 E.00055
G1 X83.943 Y93.187 E.00055
G1 X83.96 Y93.193 E.00055
G1 X83.978 Y93.2 E.00055
G1 F1590.837
G1 X84.002 Y93.2 E.00073
G1 F1458.625
G1 X84.027 Y93.2 E.00073
G1 F1330.79
G1 X84.052 Y93.2 E.00073
G1 F1208.816
G1 X84.076 Y93.2 E.00073
G1 F1092.658
G1 X84.101 Y93.2 E.00073
G1 F982.41
G1 X84.126 Y93.2 E.00073
G1 F878.024
G1 X84.151 Y93.2 E.00073
G1 F779.499
G1 X84.175 Y93.2 E.00073
G1 F686.836
G1 X84.2 Y93.2 E.00073
; FEATURE: Overhang wall
M106 S255
G1 F600
G1 X92.8 Y93.2 E.25534
G1 X92.8 Y99 E.17221
M106 S181.05
M106 S255

G1 X92.8 Y104.8 E.17221
G1 X84.2 Y104.8 E.25534
M106 S181.05
; FEATURE: Outer wall
M73 P78 R6
G1 F687.853
G1 X84.175 Y104.8 E.00074
G1 F781.706
G1 X84.15 Y104.8 E.00074
G1 F881.558
G1 X84.125 Y104.8 E.00074
G1 F987.411
G1 X84.1 Y104.8 E.00074
G1 F1099.264
G1 X84.075 Y104.8 E.00074
G1 F1217.117
G1 X84.05 Y104.8 E.00074
G1 F1340.97
G1 X84.025 Y104.8 E.00074
G1 F1470.823
G1 X84 Y104.8 E.00074
G1 F1572.955
G1 X83.982 Y104.806 E.00056
G1 F1678.569
G1 X83.964 Y104.811 E.00056
G1 F1680.343
G1 X83.946 Y104.817 E.00056
G1 X83.928 Y104.823 E.00056
G1 X83.91 Y104.829 E.00056
G1 X83.892 Y104.834 E.00056
G1 X83.874 Y104.84 E.00056
G1 X83.857 Y104.853 E.00063
G1 X83.843 Y104.884 E.00102
G1 X83.828 Y104.916 E.00102
G1 X83.814 Y104.947 E.00102
G1 X83.8 Y104.979 E.00102
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.814 Y93.053 E.00102
G1 X83.828 Y93.084 E.00102
G1 X83.832 Y93.092 E.00026
G1 E-.8 F1800
G17
G3 Z9.6 I1.217 J0 P1  F42000
G1 X83.174 Y93.285
G1 Z9.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.064 Y93.327 E.0035
G1 X83.064 Y94.637 E.03891
G1 X78.861 Y95.764 E.12922
G1 X78.861 Y92.385 E.10032
G1 X83.064 Y96.589 E.17652
G1 X83.064 Y96.68 E.00272
G1 X80.53 Y106.139 E.29076
G1 X81.527 Y106.139 E.02962
G1 X83.139 Y105.708 E.04955
G1 X83.139 Y104.967 E.02198
G1 X83.184 Y104.719 E.00749
G1 X83.064 Y104.673 E.00381
G1 X83.064 Y104.164 E.01513
G1 X78.861 Y99.96 E.17652
G1 X78.861 Y101.309 E.04006
G1 X83.064 Y100.182 E.12922
G1 X83.064 Y101.611 E.04241
M204 S500
G1 X83.261 Y104.077 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.40556
M106 S255
G1 F1500
M204 S6000
G1 X92.139 Y104.085 E.26772
G1 X92.139 Y103.722 E.01093
G1 X83.422 Y103.714 E.26288
G1 X83.422 Y103.352 E.01093
G1 X92.139 Y103.36 E.26288
G1 X92.139 Y102.997 E.01093
G1 X83.422 Y102.989 E.26288
G1 X83.422 Y102.626 E.01093
G1 X92.139 Y102.634 E.26288
G1 X92.139 Y102.272 E.01093
G1 X83.422 Y102.264 E.26288
G1 X83.422 Y101.901 E.01093
G1 X92.139 Y101.909 E.26288
G1 X92.139 Y101.546 E.01093
G1 X83.421 Y101.539 E.26288
G1 X83.421 Y101.176 E.01093
G1 X92.139 Y101.184 E.26288
G1 X92.139 Y100.821 E.01093
G1 X83.421 Y100.813 E.26288
G1 X83.421 Y100.451 E.01093
G1 X92.139 Y100.459 E.26288
G1 X92.139 Y100.096 E.01093
G1 X83.421 Y100.088 E.26288
G1 X83.421 Y99.725 E.01093
G1 X92.139 Y99.733 E.26288
G1 X92.139 Y99.371 E.01093
G1 X83.421 Y99.363 E.26288
G1 X83.422 Y99 E.01093
G1 X92.139 Y99.008 E.26288
G1 X92.139 Y98.645 E.01093
G1 X83.422 Y98.637 E.26288
G1 X83.422 Y98.275 E.01093
G1 X92.139 Y98.283 E.26288
G1 X92.139 Y97.92 E.01093
G1 X83.422 Y97.912 E.26288
G1 X83.422 Y97.549 E.01093
G1 X92.139 Y97.557 E.26288
G1 X92.139 Y97.195 E.01093
G1 X83.422 Y97.187 E.26288
G1 X83.422 Y96.824 E.01093
G1 X92.139 Y96.832 E.26288
G1 X92.139 Y96.469 E.01093
G1 X83.422 Y96.462 E.26288
G1 X83.422 Y96.099 E.01093
G1 X92.139 Y96.107 E.26288
G1 X92.139 Y95.744 E.01093
G1 X83.422 Y95.736 E.26288
G1 X83.422 Y95.374 E.01093
G1 X92.139 Y95.382 E.26288
G1 X92.139 Y95.019 E.01093
G1 X83.422 Y95.011 E.26288
G1 X83.422 Y94.648 E.01093
G1 X92.139 Y94.656 E.26288
G1 X92.139 Y94.294 E.01093
G1 X83.422 Y94.286 E.26288
G1 X83.422 Y93.923 E.01093
G1 X92.3 Y93.931 E.26772
M106 S181.05
G1 E-.8 F1800
M204 S500
G17
G3 Z9.6 I-.596 J1.061 P1  F42000
G1 X98.557 Y97.443 Z9.6
G1 Z9.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X100.639 Y91.557 E.06182
G1 X100.721 Y91.557 E.00244
G1 X100.803 Y91.557 E.00244
G1 X100.886 Y91.557 E.00244
G1 X100.968 Y91.557 E.00244
G1 X101.05 Y91.557 E.00244
G1 X101.132 Y91.557 E.00244
G1 X101.214 Y91.557 E.00244
G1 X101.296 Y91.557 E.00244
G1 X101.379 Y91.557 E.00244
G1 X101.461 Y91.557 E.00244
G1 X101.543 Y91.557 E.00244
G1 X101.625 Y91.557 E.00244
G1 X101.707 Y91.557 E.00244
G1 X101.789 Y91.557 E.00244
G1 X101.871 Y91.557 E.00244
G1 X101.954 Y91.557 E.00244
G1 X102.036 Y91.557 E.00244
G1 X102.118 Y91.557 E.00244
G1 X102.2 Y91.557 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X117.8 Y91.557 E.46317
M106 S181.05
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
M73 P79 R6
G1 X117.9 Y91.557 E.00297
G1 X118 Y91.557 E.00297
G1 X118.1 Y91.557 E.00297
G1 X118.2 Y91.557 E.00297
G1 X118.3 Y91.557 E.00297
G1 X118.4 Y91.557 E.00297
G1 X118.5 Y91.557 E.00297
G1 X118.6 Y91.557 E.00297
G1 X118.7 Y91.557 E.00297
G1 X118.8 Y91.557 E.00297
G1 X118.9 Y91.557 E.00297
G1 X119 Y91.557 E.00297
G1 X119.1 Y91.557 E.00297
G1 X119.2 Y91.557 E.00297
G1 X119.3 Y91.557 E.00297
G1 X119.4 Y91.557 E.00297
G1 X119.5 Y91.557 E.00297
G1 X119.6 Y91.557 E.00297
G1 X119.7 Y91.557 E.00297
G1 X121.443 Y91.557 E.05175
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X119.361 Y97.443 E.06182
G1 X119.279 Y97.443 E.00244
G1 X119.196 Y97.443 E.00244
G1 X119.114 Y97.443 E.00244
G1 X119.032 Y97.443 E.00244
G1 X118.95 Y97.443 E.00244
G1 X118.868 Y97.443 E.00244
G1 X118.786 Y97.443 E.00244
G1 X118.704 Y97.443 E.00244
G1 X118.621 Y97.443 E.00244
G1 X118.539 Y97.443 E.00244
G1 X118.457 Y97.443 E.00244
G1 X118.375 Y97.443 E.00244
G1 X118.293 Y97.443 E.00244
G1 X118.211 Y97.443 E.00244
G1 X118.129 Y97.443 E.00244
G1 X118.046 Y97.443 E.00244
G1 X117.964 Y97.443 E.00244
G1 X117.882 Y97.443 E.00244
G1 X117.8 Y97.443 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X102.2 Y97.443 E.46317
M106 S181.05
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X102.1 Y97.443 E.00297
G1 X102 Y97.443 E.00297
G1 X101.9 Y97.443 E.00297
G1 X101.8 Y97.443 E.00297
G1 X101.7 Y97.443 E.00297
G1 X101.6 Y97.443 E.00297
G1 X101.5 Y97.443 E.00297
G1 X101.4 Y97.443 E.00297
G1 X101.3 Y97.443 E.00297
G1 X101.2 Y97.443 E.00297
G1 X101.1 Y97.443 E.00297
G1 X101 Y97.443 E.00297
G1 X100.9 Y97.443 E.00297
G1 X100.8 Y97.443 E.00297
G1 X100.7 Y97.443 E.00297
G1 X100.6 Y97.443 E.00297
G1 X100.5 Y97.443 E.00297
G1 X100.4 Y97.443 E.00297
G1 X100.3 Y97.443 E.00297
G1 X98.617 Y97.443 E.04997
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X100.3 Y91.2 E.06235
G1 X100.4 Y91.2 E.00297
G1 X100.5 Y91.2 E.00297
G1 X100.6 Y91.2 E.00297
G1 X100.7 Y91.2 E.00297
G1 X100.8 Y91.2 E.00297
G1 X100.9 Y91.2 E.00297
G1 X101 Y91.2 E.00297
G1 X101.1 Y91.2 E.00297
G1 X101.2 Y91.2 E.00297
G1 X101.3 Y91.2 E.00297
G1 X101.4 Y91.2 E.00297
G1 X101.5 Y91.2 E.00297
G1 X101.6 Y91.2 E.00297
G1 X101.7 Y91.2 E.00297
G1 X101.8 Y91.2 E.00297
G1 X101.9 Y91.2 E.00297
G1 X102 Y91.2 E.00297
G1 X102.1 Y91.2 E.00297
G1 X102.2 Y91.2 E.00297
M204 S250
G1 X102.2 Y91.2 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X117.8 Y91.2 E.46317
M106 S181.05
; FEATURE: Outer wall
G1 F1680.343
G1 X117.9 Y91.2 E.00297
G1 X118 Y91.2 E.00297
G1 X118.1 Y91.2 E.00297
G1 X118.2 Y91.2 E.00297
G1 X118.3 Y91.2 E.00297
G1 X118.4 Y91.2 E.00297
G1 X118.5 Y91.2 E.00297
G1 X118.6 Y91.2 E.00297
G1 X118.7 Y91.2 E.00297
G1 X118.8 Y91.2 E.00297
G1 X118.9 Y91.2 E.00297
G1 X119 Y91.2 E.00297
G1 X119.1 Y91.2 E.00297
G1 X119.2 Y91.2 E.00297
G1 X119.3 Y91.2 E.00297
G1 X119.4 Y91.2 E.00297
G1 X119.5 Y91.2 E.00297
G1 X119.6 Y91.2 E.00297
G1 X119.7 Y91.2 E.00297
G1 X121.8 Y91.2 E.06235
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X119.7 Y97.8 E.06235
G1 X119.6 Y97.8 E.00297
G1 X119.5 Y97.8 E.00297
G1 X119.4 Y97.8 E.00297
G1 X119.3 Y97.8 E.00297
G1 X119.2 Y97.8 E.00297
G1 X119.1 Y97.8 E.00297
G1 X119 Y97.8 E.00297
G1 X118.9 Y97.8 E.00297
G1 X118.8 Y97.8 E.00297
G1 X118.7 Y97.8 E.00297
G1 X118.6 Y97.8 E.00297
G1 X118.5 Y97.8 E.00297
G1 X118.4 Y97.8 E.00297
G1 X118.3 Y97.8 E.00297
G1 X118.2 Y97.8 E.00297
G1 X118.1 Y97.8 E.00297
G1 X118 Y97.8 E.00297
G1 X117.9 Y97.8 E.00297
G1 X117.8 Y97.8 E.00297
M204 S250
G1 X117.8 Y97.8 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X102.2 Y97.8 E.46317
M106 S181.05
; FEATURE: Outer wall
G1 F1680.343
G1 X102.1 Y97.8 E.00297
G1 X102 Y97.8 E.00297
G1 X101.9 Y97.8 E.00297
G1 X101.8 Y97.8 E.00297
G1 X101.7 Y97.8 E.00297
G1 X101.6 Y97.8 E.00297
G1 X101.5 Y97.8 E.00297
G1 X101.4 Y97.8 E.00297
G1 X101.3 Y97.8 E.00297
G1 X101.2 Y97.8 E.00297
G1 X101.1 Y97.8 E.00297
G1 X101 Y97.8 E.00297
G1 X100.9 Y97.8 E.00297
G1 X100.8 Y97.8 E.00297
G1 X100.7 Y97.8 E.00297
G1 X100.6 Y97.8 E.00297
G1 X100.5 Y97.8 E.00297
G1 X100.4 Y97.8 E.00297
G1 X100.3 Y97.8 E.00297
G1 X98.26 Y97.8 E.06057
G1 E-.8 F1800
G17
G3 Z9.6 I.875 J.846 P1  F42000
G1 X99.989 Y96.011 Z9.6
G1 Z9.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4079
G1 F1643.926
M204 S6000
G1 X99.989 Y93.049 E.08987
M204 S500
G1 X100.35 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.35 Y92.628 E.11115
G1 X99.628 Y92.628 E.02144
G1 X99.628 Y96.372 E.11115
G1 X100.29 Y96.372 E.01966
M204 S500
G1 X100.707 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X100.707 Y92.271 E.13235
G1 X99.271 Y92.271 E.04264
G1 X99.271 Y96.729 E.13235
G1 X100.647 Y96.729 E.04086
M204 S500
G1 X101.064 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X101.064 Y91.914 E.15355
G1 X98.914 Y91.914 E.06384
G1 X98.914 Y97.086 E.15355
G1 X101.004 Y97.086 E.06206
M204 S500
G1 X101.261 Y97.13 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.41864
M106 S255
G1 F1500
M204 S6000
G1 X118.578 Y97.13 E.54103
G1 X118.578 Y96.754 E.01174
G1 X101.422 Y96.754 E.53601
G1 X101.422 Y96.379 E.01174
G1 X118.578 Y96.379 E.53601
G1 X118.578 Y96.003 E.01174
G1 X101.422 Y96.003 E.53601
G1 X101.422 Y95.627 E.01174
G1 X118.578 Y95.627 E.53601
G1 X118.578 Y95.251 E.01174
G1 X101.422 Y95.251 E.53601
G1 X101.422 Y94.876 E.01174
G1 X118.578 Y94.876 E.53601
G1 X118.578 Y94.5 E.01174
G1 X101.422 Y94.5 E.53601
G1 X101.422 Y94.124 E.01174
G1 X118.578 Y94.124 E.53601
G1 X118.578 Y93.749 E.01174
G1 X101.422 Y93.749 E.53601
G1 X101.422 Y93.373 E.01174
G1 X118.578 Y93.373 E.53601
G1 X118.578 Y92.997 E.01174
G1 X101.422 Y92.997 E.53601
G1 X101.422 Y92.621 E.01174
G1 X118.578 Y92.621 E.53601
G1 X118.578 Y92.246 E.01174
G1 X101.422 Y92.246 E.53601
G1 X101.422 Y91.87 E.01174
G1 X118.739 Y91.87 E.54103
M106 S181.05
M204 S500
G1 X120.011 Y96.011 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40788
G1 F1644.016
M204 S6000
G1 X120.011 Y93.049 E.08987
M204 S500
G1 X119.65 Y96.372 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.02144
G1 X120.372 Y92.628 E.11115
G1 X119.65 Y92.628 E.02144
G1 X119.65 Y96.312 E.10936
M204 S500
G1 X119.293 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.04264
G1 X120.729 Y92.271 E.13235
G1 X119.293 Y92.271 E.04264
G1 X119.293 Y96.669 E.13057
M204 S500
G1 X118.936 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.06384
G1 X121.086 Y91.914 E.15355
G1 X118.936 Y91.914 E.06384
G1 X118.936 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 9.4
; LAYER_HEIGHT: 0.2
M106 S183.6
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.6 I.124 J-1.211 P1  F42000
G1 X83.628 Y93.408 Z9.6
G1 Z9.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
M73 P80 R6
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z9.8 I1.217 J0 P1  F42000
G1 X83.064 Y93.355
G1 Z9.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.064 Y94.784 E.04241
G1 X78.861 Y95.91 E.12922
G1 X78.861 Y92.185 E.11061
G1 X83.064 Y96.389 E.17652
G1 X83.064 Y96.134 E.00756
G1 X80.383 Y106.139 E.30755
G1 X82.074 Y106.139 E.05019
G1 X83.139 Y105.854 E.03276
G1 X83.139 Y104.967 E.02632
G1 X83.184 Y104.719 E.00749
G1 X83.064 Y104.673 E.00381
G1 X83.064 Y103.964 E.02107
G1 X78.861 Y99.76 E.17652
G1 X78.861 Y101.455 E.05034
G1 X83.064 Y100.329 E.12922
G1 X83.064 Y101.757 E.04241
M204 S500
G1 X83.261 Y103.801 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40451
G1 F1659.338
M204 S6000
G1 X83.664 Y104.204 E.01714
G1 X83.86 Y104.147 E.00614
G1 X84.118 Y104.147 E.00776
G1 X83.421 Y103.45 E.02962
G1 X83.421 Y102.939 E.01538
G1 X84.629 Y104.146 E.05135
G1 X85.14 Y104.146 E.01536
G1 X83.421 Y102.428 E.07307
G1 X83.421 Y101.916 E.01537
G1 X85.651 Y104.146 E.0948
G1 X86.162 Y104.145 E.01536
G1 X83.421 Y101.405 E.11652
G1 X83.421 Y100.893 E.01537
G1 X86.673 Y104.145 E.13824
G1 X87.184 Y104.144 E.01536
G1 X83.421 Y100.382 E.15997
G1 X83.421 Y99.871 E.01537
G1 X87.694 Y104.144 E.18169
G1 X88.205 Y104.143 E.01536
G1 X83.421 Y99.359 E.20341
G1 X83.421 Y98.848 E.01537
G1 X88.716 Y104.143 E.22514
G1 X89.227 Y104.142 E.01536
G1 X83.421 Y98.337 E.24686
G1 X83.421 Y97.825 E.01537
G1 X89.738 Y104.142 E.26858
G1 X90.249 Y104.141 E.01536
G1 X83.421 Y97.314 E.29031
G1 X83.421 Y96.802 E.01538
G1 X90.76 Y104.141 E.31203
G1 X91.271 Y104.14 E.01536
G1 X83.421 Y96.291 E.33376
G1 X83.421 Y95.78 E.01538
G1 X91.782 Y104.14 E.35548
G1 X92.14 Y104.14 E.01076
G1 X92.14 Y103.987 E.0046
G1 X83.421 Y95.268 E.3707
G1 X83.421 Y94.757 E.01538
G1 X92.14 Y103.475 E.3707
G1 X92.14 Y102.964 E.01538
G1 X83.421 Y94.246 E.3707
G1 X83.421 Y93.734 E.01538
G1 X92.14 Y102.452 E.3707
G1 X92.14 Y101.941 E.01538
G1 X84.051 Y93.853 E.34391
G1 X84.563 Y93.853 E.01539
G1 X92.14 Y101.43 E.32214
G1 X92.14 Y100.918 E.01538
G1 X85.075 Y93.854 E.30038
G1 X85.587 Y93.854 E.01539
G1 X92.14 Y100.407 E.27862
G1 X92.14 Y99.896 E.01537
G1 X86.099 Y93.855 E.25685
G1 X86.611 Y93.855 E.01539
G1 X92.14 Y99.384 E.23509
G1 X92.14 Y98.873 E.01537
G1 X87.122 Y93.856 E.21333
G1 X87.634 Y93.856 E.01539
G1 X92.14 Y98.361 E.19156
G1 X92.14 Y97.85 E.01537
G1 X88.146 Y93.857 E.1698
G1 X88.658 Y93.857 E.01539
G1 X92.14 Y97.339 E.14804
G1 X92.14 Y96.827 E.01537
G1 X89.17 Y93.858 E.12627
G1 X89.682 Y93.858 E.01539
G1 X92.14 Y96.316 E.10451
G1 X92.14 Y95.805 E.01538
G1 X90.193 Y93.859 E.08275
G1 X90.705 Y93.859 E.01539
G1 X92.14 Y95.293 E.06098
G1 X92.14 Y94.782 E.01538
G1 X91.217 Y93.86 E.03922
G1 X91.729 Y93.86 E.01539
G1 X92.3 Y94.431 E.02429
G1 E-.8 F1800
M204 S500
G17
G3 Z9.8 I-.528 J1.097 P1  F42000
G1 X98.557 Y97.443 Z9.8
G1 Z9.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
M73 P81 R6
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 E-.8 F1800
G17
G3 Z9.8 I.868 J.853 P1  F42000
G1 X101.5 Y94.5 Z9.8
G1 Z9.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X118.44 Y94.5 E.74629
M204 S500
G1 X101.057 Y94.943 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.943 Y94.943 E.53107
G1 X118.943 Y94.057 E.02633
G1 X101.057 Y94.057 E.53107
G1 X101.057 Y94.883 E.02455
M204 S500
M73 P81 R5
G1 X100.699 Y95.301 F42000
G1 F1680.343
M204 S6000
G1 X119.301 Y95.301 E.55227
G1 X119.301 Y93.699 E.04754
G1 X100.699 Y93.699 E.55227
G1 X100.699 Y95.241 E.04575
M204 S500
G1 X100.342 Y95.658 F42000
G1 F1680.343
M204 S6000
G1 X119.658 Y95.658 E.57348
G1 X119.658 Y93.342 E.06874
G1 X100.342 Y93.342 E.57348
G1 X100.342 Y95.598 E.06696
M204 S500
G1 X99.985 Y96.015 F42000
G1 F1680.343
M204 S6000
G1 X120.015 Y96.015 E.59468
G1 X120.015 Y92.985 E.08994
G1 X99.985 Y92.985 E.59468
G1 X99.985 Y95.955 E.08816
M204 S500
G1 X99.628 Y96.372 F42000
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.61588
G1 X120.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.61588
G1 X99.628 Y96.312 E.10936
M204 S500
G1 X99.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.63709
G1 X120.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.63709
G1 X99.271 Y96.669 E.13057
M204 S500
G1 X98.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.65829
G1 X121.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.65829
G1 X98.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 9.6
; LAYER_HEIGHT: 0.200001
M106 S186.15
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.8 I.28 J-1.184 P1  F42000
G1 X83.628 Y93.408 Z9.8
G1 Z9.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
M73 P82 R5
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z10 I1.217 J0 P1  F42000
G1 X84.7 Y93.693
G1 Z9.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40629
G1 F1651.209
M204 S6000
G1 X84.086 Y94.307 E.02626
G1 X84.086 Y94.821 E.01553
G1 X85.053 Y93.854 E.04134
G1 X85.567 Y93.854 E.01551
G1 X84.086 Y95.335 E.06328
G1 X84.086 Y95.849 E.01553
G1 X86.08 Y93.855 E.08522
G1 X86.593 Y93.855 E.01551
G1 X84.086 Y96.363 E.10715
G1 X84.086 Y96.877 E.01553
G1 X87.107 Y93.856 E.12909
G1 X87.62 Y93.856 E.01551
G1 X84.086 Y97.391 E.15103
G1 X84.086 Y97.905 E.01553
G1 X88.134 Y93.857 E.17297
G1 X88.647 Y93.857 E.01551
G1 X84.086 Y98.419 E.19491
G1 X84.086 Y98.932 E.01553
G1 X89.16 Y93.858 E.21684
G1 X89.674 Y93.858 E.01551
G1 X84.086 Y99.446 E.23878
G1 X84.086 Y99.96 E.01553
G1 X90.187 Y93.859 E.26072
G1 X90.701 Y93.859 E.01551
G1 X84.086 Y100.474 E.28266
G1 X84.086 Y100.988 E.01553
G1 X91.214 Y93.86 E.3046
G1 X91.728 Y93.86 E.01551
G1 X84.086 Y101.502 E.32653
G1 X84.086 Y102.016 E.01553
G1 X92.14 Y93.962 E.34414
G1 X92.14 Y94.476 E.01553
G1 X84.086 Y102.53 E.34414
G1 X84.086 Y103.043 E.01553
G1 X92.14 Y94.99 E.34414
G1 X92.14 Y95.504 E.01553
G1 X84.086 Y103.557 E.34414
G1 X84.086 Y104.071 E.01553
G1 X92.14 Y96.017 E.34414
G1 X92.14 Y96.531 E.01553
G1 X84.524 Y104.147 E.3254
G1 X85.039 Y104.146 E.01554
G1 X92.14 Y97.045 E.30342
G1 X92.14 Y97.559 E.01553
G1 X85.553 Y104.146 E.28144
G1 X86.067 Y104.145 E.01554
G1 X92.14 Y98.073 E.25946
G1 X92.14 Y98.587 E.01553
G1 X86.582 Y104.145 E.23749
G1 X87.096 Y104.144 E.01554
G1 X92.14 Y99.101 E.21551
G1 X92.14 Y99.615 E.01553
G1 X87.61 Y104.144 E.19353
G1 X88.125 Y104.143 E.01554
G1 X92.14 Y100.128 E.17155
G1 X92.14 Y100.642 E.01553
G1 X88.639 Y104.143 E.14957
G1 X89.153 Y104.142 E.01554
G1 X92.14 Y101.156 E.1276
G1 X92.14 Y101.67 E.01553
G1 X89.668 Y104.142 E.10562
G1 X90.182 Y104.141 E.01554
G1 X92.14 Y102.184 E.08364
G1 X92.14 Y102.698 E.01553
G1 X90.696 Y104.141 E.06166
G1 X91.211 Y104.141 E.01554
G1 X92.14 Y103.212 E.03968
G1 X92.14 Y103.726 E.01553
G1 X91.564 Y104.301 E.02458
G1 E-.8 F1800
M204 S500
G17
G3 Z10 I-.176 J-1.204 P1  F42000
G1 X83.139 Y105.534 Z10
G1 Z9.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y104.967 E.01684
G1 X83.19 Y104.688 E.00844
G1 X83.292 Y104.495 E.00647
G1 X83.425 Y104.347 E.00591
G1 X83.556 Y104.255 E.00475
G1 X78.861 Y99.56 E.19716
G1 X78.861 Y101.602 E.06063
G1 X83.729 Y100.297 E.14964
G1 X83.729 Y96.853 E.10226
G1 X78.861 Y91.985 E.20441
G1 X78.861 Y96.057 E.12089
G1 X83.729 Y94.752 E.14964
G1 X83.729 Y93.822 E.02761
G1 X83.558 Y93.746 E.00555
G1 X80.237 Y106.139 E.38095
G1 X78.861 Y106.139 E.04087
G1 X78.861 Y106.088 E.00154
G1 E-.8 F1800
M204 S500
G17
G3 Z10 I.489 J1.114 P1  F42000
G1 X98.557 Y97.443 Z10
G1 Z9.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 E-.8 F1800
G17
G3 Z10 I.305 J1.178 P1  F42000
G1 X101.729 Y96.903 Z10
G1 Z9.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
M73 P83 R5
G1 X101.729 Y95.474 E.04241
G1 X98.861 Y96.243 E.08816
G1 X98.861 Y96.835 E.0176
G1 X99.165 Y97.139 E.01277
G1 X99.284 Y97.139 E.00354
G1 X100.698 Y91.861 E.16227
G1 X101.461 Y91.861 E.02263
G1 X101.729 Y92.129 E.01126
G1 X101.729 Y93.557 E.04241
M204 S500
G1 X104.671 Y94.5 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57275
G1 F1132.439
M204 S6000
G1 X115.269 Y94.5 E.46686
M204 S500
G1 X104.228 Y94.943 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X115.772 Y94.943 E.34275
G1 X115.772 Y94.057 E.02633
G1 X104.228 Y94.057 E.34275
G1 X104.228 Y94.883 E.02455
M204 S500
G1 X103.871 Y95.301 F42000
G1 F1680.343
M204 S6000
G1 X116.129 Y95.301 E.36395
G1 X116.129 Y93.699 E.04754
G1 X103.871 Y93.699 E.36395
G1 X103.871 Y95.241 E.04575
M204 S500
G1 X103.514 Y95.658 F42000
G1 F1680.343
M204 S6000
G1 X116.486 Y95.658 E.38515
G1 X116.486 Y93.342 E.06874
G1 X103.514 Y93.342 E.38515
G1 X103.514 Y95.598 E.06696
M204 S500
G1 X103.157 Y96.015 F42000
G1 F1680.343
M204 S6000
G1 X116.843 Y96.015 E.40636
G1 X116.843 Y92.985 E.08994
G1 X103.157 Y92.985 E.40636
G1 X103.157 Y95.955 E.08816
M204 S500
G1 X102.8 Y96.372 F42000
G1 F1680.343
M204 S6000
G1 X117.2 Y96.372 E.42756
G1 X117.2 Y92.628 E.11115
G1 X102.8 Y92.628 E.42756
G1 X102.8 Y96.312 E.10936
M204 S500
G1 X102.443 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X117.557 Y96.729 E.44876
G1 X117.557 Y92.271 E.13235
G1 X102.443 Y92.271 E.44876
G1 X102.443 Y96.669 E.13057
M204 S500
G1 X102.086 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X117.914 Y97.086 E.46996
G1 X117.914 Y91.914 E.15355
G1 X102.086 Y91.914 E.46996
G1 X102.086 Y97.026 E.15177
M204 S500
G1 X118.271 Y92.093 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X118.271 Y93.522 E.04241
G1 X121.139 Y96.39 E.12043
G1 X121.139 Y95.818 E.01697
G1 X118.271 Y96.587 E.08816
G1 X118.271 Y97.139 E.01641
G1 X119.147 Y97.139 E.026
; CHANGE_LAYER
; Z_HEIGHT: 9.8
; LAYER_HEIGHT: 0.2
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10 I.127 J-1.21 P1  F42000
G1 X83.628 Y93.408 Z10
G1 Z9.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z10.2 I1.217 J0 P1  F42000
G1 X83.139 Y92.317
G1 Z9.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.139 Y93.033 E.02124
G1 X83.19 Y93.312 E.00844
G1 X83.292 Y93.505 E.00647
G1 X83.434 Y93.66 E.00625
G1 X80.091 Y106.139 E.38361
G1 X83.139 Y106.139 E.09052
G1 X83.139 Y104.967 E.0348
G1 X83.19 Y104.688 E.00844
G1 X83.292 Y104.495 E.00647
G1 X83.425 Y104.347 E.00591
G1 X83.572 Y104.244 E.00534
G1 X83.692 Y104.192 E.00389
G1 X78.861 Y99.36 E.20289
G1 X78.861 Y101.748 E.07091
G1 X92.139 Y98.19 E.40817
G1 X92.139 Y97.489 E.02081
G1 X88.508 Y93.857 E.1525
G1 X88.927 Y93.858 E.01244
G1 X86.17 Y104.145 E.31622
G1 X90.625 Y104.141 E.13228
G1 X92.139 Y103.735 E.04655
G1 X92.139 Y104.14 E.01201
G1 X91.717 Y104.14 E.01255
G1 X92.139 Y102.562 E.0485
G1 X92.139 Y101.134 E.04241
M204 S500
G1 X91.216 Y104.14 F42000
G1 F1680.297
M204 S6000
G1 X78.936 Y91.861 E.51563
G1 X78.861 Y91.861 E.00225
M73 P84 R5
G1 X78.861 Y96.203 E.12893
G1 X87.618 Y93.856 E.2692
G1 X88.329 Y93.857 E.0211
G1 E-.8 F1800
M204 S500
G17
G3 Z10.2 I-.403 J1.148 P1  F42000
G1 X98.557 Y97.443 Z10.2
G1 Z9.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 X98.887 Y96.961 F42000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383068
G1 F1763.94
M204 S6000
G1 X98.913 Y97.087 E.00363
G1 X99.039 Y97.113 E.00363
G1 X120.961 Y97.113 E.62002
G1 X121.087 Y97.087 E.00363
G1 X121.113 Y96.961 E.00363
G1 X121.113 Y92.039 E.1392
G1 X121.087 Y91.913 E.00363
G1 X120.961 Y91.887 E.00363
G1 X99.039 Y91.887 E.62002
G1 X98.913 Y91.913 E.00363
M73 P84 R4
G1 X98.887 Y92.039 E.00363
G1 X98.887 Y96.901 E.1375
M204 S500
G1 X99.218 Y96.293 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.428 Y92.218 E.46756
G1 X115.857 Y92.218 E.04241
M204 S500
G1 X116.66 Y96.782 F42000
G1 F1680.297
M204 S6000
G1 X118.088 Y96.782 E.04241
G1 X120.782 Y96.06 E.08282
G1 X120.782 Y95.833 E.00676
G1 X117.167 Y92.218 E.15179
G1 X117.092 Y92.218 E.00225
G1 X115.869 Y96.782 E.14031
G1 X114.157 Y96.782 E.05082
G1 X109.593 Y92.218 E.19166
G1 X111.547 Y92.218 E.05802
G1 X110.324 Y96.782 E.14031
G1 X111.752 Y96.782 E.04241
M204 S500
G1 X104.573 Y92.218 F42000
G1 F1680.297
M204 S6000
G1 X106.001 Y92.218 E.04241
G1 X104.778 Y96.782 E.14031
G1 X106.582 Y96.782 E.05356
G1 X102.018 Y92.218 E.19166
G1 X100.456 Y92.218 E.04636
G1 X99.233 Y96.782 E.14031
G1 X100.662 Y96.782 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 10
; LAYER_HEIGHT: 0.2
M106 S186.15
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.2 I.236 J-1.194 P1  F42000
G1 X83.628 Y93.408 Z10.2
G1 Z10
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z10.4 I1.217 J0 P1  F42000
G1 X88.529 Y93.857
G1 Z10
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X88.163 Y93.857 E.01088
G1 X78.861 Y96.349 E.28594
G1 X78.861 Y99.16 E.08344
G1 X83.85 Y104.149 E.20951
G1 X86.024 Y104.145 E.06453
G1 X88.78 Y93.857 E.31623
G1 X88.708 Y93.857 E.00215
G1 X92.139 Y97.289 E.1441
G1 X92.139 Y98.336 E.0311
G1 X78.861 Y101.895 E.40817
G1 X78.861 Y106.139 E.12604
G1 X79.944 Y106.139 E.03217
G1 X83.321 Y93.538 E.38737
G1 X83.19 Y93.312 E.00773
G1 X83.139 Y93.033 E.00844
G1 X83.139 Y91.861 E.0348
G1 X79.136 Y91.861 E.11886
M73 P85 R4
G1 X91.416 Y104.14 E.51562
G1 X91.57 Y104.14 E.00458
G1 X92.139 Y102.016 E.0653
G1 X92.139 Y100.587 E.04241
M204 S500
G1 X91.749 Y104.14 F42000
G1 F1680.297
M204 S6000
G1 X92.139 Y104.14 E.0116
G1 X92.139 Y103.882 E.00766
G1 X91.173 Y104.14 E.02969
G1 X89.745 Y104.142 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10.4 I.736 J.969 P1  F42000
G1 X98.557 Y97.443 Z10.4
G1 Z10
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 X98.705 Y96.622 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.40209
; LAYER_HEIGHT: 0.4
M106 S255
G1 F945.028
M204 S6000
G1 X100.463 Y97.093 E.09609
G1 X102.209 Y97.093 E.09221
G1 X98.907 Y96.208 E.18049
G1 X98.907 Y95.74 E.02471
G1 X103.956 Y97.093 E.27596
G1 X105.703 Y97.093 E.09221
G1 X98.907 Y95.272 E.37142
G1 X98.907 Y94.804 E.02471
G1 X107.45 Y97.093 E.46689
G1 X109.196 Y97.093 E.09221
G1 X98.907 Y94.336 E.56236
G1 X98.907 Y93.868 E.02471
G1 X110.943 Y97.093 E.65783
G1 X112.69 Y97.093 E.09221
G1 X98.907 Y93.4 E.75329
G1 X98.907 Y92.932 E.02471
G1 X114.437 Y97.093 E.84876
G1 X116.183 Y97.093 E.09221
G1 X98.907 Y92.464 E.94423
G1 X98.907 Y91.996 E.02471
G1 X117.93 Y97.093 E1.0397
G1 X119.677 Y97.093 E.09221
G1 X100.323 Y91.907 E1.0578
G1 X102.069 Y91.907 E.09221
G1 X121.093 Y97.004 E1.03973
G1 X121.093 Y96.536 E.02471
G1 X103.816 Y91.907 E.94426
G1 X105.563 Y91.907 E.09221
G1 X121.093 Y96.068 E.84879
G1 X121.093 Y95.6 E.02471
M73 P86 R4
G1 X107.31 Y91.907 E.75333
G1 X109.056 Y91.907 E.09221
G1 X121.093 Y95.132 E.65786
G1 X121.093 Y94.664 E.02471
G1 X110.803 Y91.907 E.56239
G1 X112.55 Y91.907 E.09221
G1 X121.093 Y94.196 E.46692
G1 X121.093 Y93.728 E.02471
G1 X114.297 Y91.907 E.37145
G1 X116.043 Y91.907 E.09221
G1 X121.093 Y93.26 E.27599
G1 X121.093 Y92.792 E.02471
G1 X117.79 Y91.907 E.18052
G1 X119.537 Y91.907 E.09221
G1 X121.295 Y92.378 E.09612
M106 S186.15
; CHANGE_LAYER
; Z_HEIGHT: 10.2
; LAYER_HEIGHT: 0.2
M106 S188.7
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.4 I-.033 J-1.217 P1  F42000
G1 X83.628 Y93.408 Z10.4
G1 Z10.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z10.6 I1.217 J0 P1  F42000
G1 X83.188 Y93.364
G1 Z10.2
G1 E.8 F1800
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383059
G1 F1763.984
M204 S6000
G1 X83.433 Y93.691 E.01157
G1 X83.725 Y93.841 E.00929
G1 X83.874 Y93.88 E.00435
G1 X91.961 Y93.887 E.22871
G1 X92.087 Y93.913 E.00363
G1 X92.113 Y94.039 E.00363
G1 X92.113 Y103.961 E.28062
G1 X92.087 Y104.087 E.00363
G1 X91.961 Y104.113 E.00363
G1 X83.874 Y104.12 E.22871
G1 X83.537 Y104.246 E.01017
G1 X83.261 Y104.496 E.01055
G1 X83.16 Y104.702 E.00648
G1 X83.113 Y104.979 E.00794
G1 X83.113 Y105.335 E.01009
M204 S500
G1 X81.88 Y106.113 F42000
; Slow Down Start
; LINE_WIDTH: 0.38292
G1 F1500;_EXTRUDE_SET_SPEED
M204 S6000
G1 X79.914 Y106.113 E.05559
; Slow Down End
G1 E-.8 F1800
M204 S500
G17
G3 Z10.6 I.451 J1.13 P1  F42000
G1 X91.782 Y101.374 Z10.6
G1 Z10.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X91.782 Y102.802 E.04241
G1 X91.519 Y103.783 E.03015
G1 X91.259 Y103.783 E.00774
G1 X79.336 Y91.861 E.50063
G1 X83.139 Y91.861 E.11292
G1 X83.139 Y92.814 E.02831
G1 X82.799 Y93.155 E.01431
G1 X82.848 Y93.43 E.00831
G1 X82.997 Y93.711 E.00943
G1 X83.098 Y93.824 E.00449
G1 X79.893 Y105.782 E.36759
G1 X79.717 Y105.782 E.00524
G1 X79.36 Y106.139 E.015
G1 X78.861 Y106.139 E.01483
G1 X78.861 Y102.041 E.12169
G1 X91.782 Y98.579 E.3972
G1 X91.782 Y96.732 E.05483
G1 X89.265 Y94.215 E.10568
G1 X88.538 Y94.214 E.02159
G1 X85.973 Y103.788 E.29428
G1 X83.819 Y103.79 E.06397
G1 X83.715 Y103.814 E.00316
G1 X78.861 Y98.96 E.20384
G1 X78.861 Y96.496 E.07316
G1 X87.379 Y94.213 E.26184
G1 X88.36 Y94.214 E.02912
G1 E-.8 F1800
M204 S500
G17
G3 Z10.6 I-.367 J1.16 P1  F42000
G1 X98.557 Y97.443 Z10.6
G1 Z10.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
M73 P87 R4
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 E-.8 F1800
G17
G3 Z10.6 I.868 J.853 P1  F42000
G1 X101.5 Y94.5 Z10.6
G1 Z10.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X118.44 Y94.5 E.74629
M204 S500
G1 X101.057 Y94.943 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.943 Y94.943 E.53107
G1 X118.943 Y94.057 E.02633
G1 X101.057 Y94.057 E.53107
G1 X101.057 Y94.883 E.02455
M204 S500
G1 X100.699 Y95.301 F42000
G1 F1680.343
M204 S6000
G1 X119.301 Y95.301 E.55227
G1 X119.301 Y93.699 E.04754
G1 X100.699 Y93.699 E.55227
G1 X100.699 Y95.241 E.04575
M204 S500
G1 X100.342 Y95.658 F42000
G1 F1680.343
M204 S6000
G1 X119.658 Y95.658 E.57348
G1 X119.658 Y93.342 E.06874
G1 X100.342 Y93.342 E.57348
G1 X100.342 Y95.598 E.06696
M204 S500
G1 X99.985 Y96.015 F42000
G1 F1680.343
M204 S6000
G1 X120.015 Y96.015 E.59468
G1 X120.015 Y92.985 E.08994
G1 X99.985 Y92.985 E.59468
G1 X99.985 Y95.955 E.08816
M204 S500
G1 X99.628 Y96.372 F42000
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.61588
G1 X120.372 Y92.628 E.11115
M73 P87 R3
G1 X99.628 Y92.628 E.61588
G1 X99.628 Y96.312 E.10936
M204 S500
G1 X99.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.63709
G1 X120.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.63709
G1 X99.271 Y96.669 E.13057
M204 S500
G1 X98.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.65829
G1 X121.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.65829
G1 X98.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 10.4
; LAYER_HEIGHT: 0.2
M106 S178.5
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.6 I.28 J-1.184 P1  F42000
G1 X83.628 Y93.408 Z10.6
G1 Z10.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
M73 P88 R3
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z10.8 I1.217 J0 P1  F42000
G1 X83.274 Y93.252
G1 Z10.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40143
; LAYER_HEIGHT: 0.4
M106 S255
G1 F948.138
M204 S6000
G1 X81.877 Y94.649 E.10395
G1 X82.196 Y94.968 E.02375
G1 X83.442 Y93.722 E.09273
G1 X83.549 Y93.797 E.00689
G1 X83.704 Y93.864 E.00888
G1 X83.903 Y93.899 E.01063
G1 X82.515 Y95.287 E.10327
G1 X82.591 Y95.363 E.00561
G1 X82.52 Y95.921 E.02962
G1 X84.541 Y93.9 E.15039
G1 X85.179 Y93.901 E.03356
G1 X82.343 Y96.736 E.21101
G1 X82.109 Y97.608 E.04751
G1 X85.817 Y93.901 E.27586
G1 X86.454 Y93.902 E.03356
G1 X81.876 Y98.48 E.34071
G1 X81.642 Y99.352 E.04751
G1 X87.092 Y93.902 E.40557
G1 X87.73 Y93.903 E.03356
G1 X81.408 Y100.225 E.47042
G1 X81.175 Y101.097 E.04751
G1 X88.368 Y93.904 E.53528
G1 X89.006 Y93.904 E.03356
G1 X81.639 Y101.271 E.54818
G1 X82.511 Y101.037 E.04751
G1 X89.644 Y93.905 E.53075
G1 X90.281 Y93.905 E.03356
G1 X82.13 Y102.056 E.60657
G1 X82.011 Y102.358 E.01707
G1 X82.239 Y102.586 E.01694
G1 X90.919 Y93.906 E.64593
G1 X91.557 Y93.906 E.03356
G1 X82.558 Y102.905 E.66964
G1 X82.862 Y103.209 E.02258
G1 X79.977 Y106.093 E.21464
G1 X80.009 Y106.093 E.00167
G1 X92.093 Y94.009 E.89923
G1 X92.093 Y94.647 E.03359
G1 X80.647 Y106.093 E.85172
G1 X81.286 Y106.093 E.03359
G1 X92.093 Y95.286 E.80421
G1 X92.093 Y95.924 E.03359
G1 X83.917 Y104.101 E.60844
G1 X84.556 Y104.1 E.03362
G1 X92.093 Y96.563 E.56089
G1 X92.093 Y97.201 E.03359
G1 X85.195 Y104.099 E.51334
G1 X85.834 Y104.099 E.03362
G1 X92.093 Y97.839 E.46579
G1 X92.093 Y98.478 E.03359
G1 X86.473 Y104.098 E.41824
G1 X87.112 Y104.098 E.03362
G1 X92.093 Y99.116 E.37069
G1 X92.093 Y99.755 E.03359
G1 X87.751 Y104.097 E.32313
G1 X88.39 Y104.096 E.03362
G1 X92.093 Y100.393 E.27558
G1 X92.093 Y101.032 E.03359
G1 X89.029 Y104.096 E.22803
G1 X89.668 Y104.095 E.03362
G1 X92.093 Y101.67 E.18048
G1 X92.093 Y102.308 E.03359
G1 X90.307 Y104.095 E.13293
G1 X90.946 Y104.094 E.03362
G1 X92.093 Y102.947 E.08538
G1 X92.093 Y103.585 E.03359
G1 X91.382 Y104.296 E.05291
M106 S178.5
G1 E-.8 F1800
M204 S500
G17
G3 Z10.8 I-.048 J-1.216 P1  F42000
G1 X83.408 Y104.61 Z10.8
G1 Z10.4
G1 E.8 F1800
M106 S255
G1 F948.138
M204 S6000
G1 X81.722 Y106.295 E.12545
M106 S178.5
M204 S500
G1 X78.861 Y103.616 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
; LAYER_HEIGHT: 0.2
G1 F1680.297
M204 S6000
G1 X78.861 Y102.187 E.04241
G1 X80.589 Y101.724 E.05312
G1 X80.518 Y101.989 E.00814
G1 X80.782 Y101.918 E.00814
G1 X79.758 Y105.741 E.11753
G1 X82.291 Y103.209 E.10636
M73 P89 R3
G1 X81.539 Y102.457 E.03157
G1 X81.827 Y101.726 E.02332
G1 X81.758 Y101.657 E.0029
G1 X80.955 Y101.872 E.02467
M204 S500
G1 X81.22 Y99.37 F42000
G1 F1680.297
M204 S6000
G1 X80.85 Y100.749 E.04241
G1 X78.861 Y98.76 E.08354
G1 X78.861 Y96.642 E.06287
G1 X82.133 Y95.765 E.10058
G1 X82.165 Y95.508 E.0077
G1 X81.305 Y94.648 E.03611
G1 X81.815 Y94.139 E.02138
G1 X79.536 Y91.861 E.09567
G1 X80.965 Y91.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10.8 I-.368 J1.16 P1  F42000
G1 X98.557 Y97.443 Z10.8
G1 Z10.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.557 Y91.557 E.17475
G1 X121.443 Y91.557 E.67949
G1 X121.443 Y94.5 E.08738
G1 X121.443 Y97.443 E.08738
G1 X98.617 Y97.443 E.67771
M204 S250
G1 X98.2 Y97.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 E-.8 F1800
G17
G3 Z10.8 I.868 J.853 P1  F42000
G1 X101.5 Y94.5 Z10.8
G1 Z10.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.57274
G1 F1132.46
M204 S6000
G1 X118.44 Y94.5 E.74629
M204 S500
G1 X101.057 Y94.943 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X118.943 Y94.943 E.53107
G1 X118.943 Y94.057 E.02633
G1 X101.057 Y94.057 E.53107
G1 X101.057 Y94.883 E.02455
M204 S500
G1 X100.699 Y95.301 F42000
G1 F1680.343
M204 S6000
G1 X119.301 Y95.301 E.55227
G1 X119.301 Y93.699 E.04754
G1 X100.699 Y93.699 E.55227
G1 X100.699 Y95.241 E.04575
M204 S500
G1 X100.342 Y95.658 F42000
G1 F1680.343
M204 S6000
G1 X119.658 Y95.658 E.57348
G1 X119.658 Y93.342 E.06874
G1 X100.342 Y93.342 E.57348
G1 X100.342 Y95.598 E.06696
M204 S500
G1 X99.985 Y96.015 F42000
G1 F1680.343
M204 S6000
G1 X120.015 Y96.015 E.59468
G1 X120.015 Y92.985 E.08994
G1 X99.985 Y92.985 E.59468
G1 X99.985 Y95.955 E.08816
M204 S500
G1 X99.628 Y96.372 F42000
G1 F1680.343
M204 S6000
G1 X120.372 Y96.372 E.61588
G1 X120.372 Y92.628 E.11115
G1 X99.628 Y92.628 E.61588
G1 X99.628 Y96.312 E.10936
M204 S500
G1 X99.271 Y96.729 F42000
G1 F1680.343
M204 S6000
G1 X120.729 Y96.729 E.63709
G1 X120.729 Y92.271 E.13235
G1 X99.271 Y92.271 E.63709
G1 X99.271 Y96.669 E.13057
M204 S500
G1 X98.914 Y97.086 F42000
G1 F1680.343
M204 S6000
G1 X121.086 Y97.086 E.65829
G1 X121.086 Y91.914 E.15355
G1 X98.914 Y91.914 E.65829
G1 X98.914 Y97.026 E.15177
; CHANGE_LAYER
; Z_HEIGHT: 10.6
; LAYER_HEIGHT: 0.200001
M106 S183.6
; OBJECT_ID: 15
M73 P90 R3
G1 E-.8 F1800
M204 S500
G17
G3 Z10.8 I.28 J-1.184 P1  F42000
G1 X83.628 Y93.408 Z10.8
G1 Z10.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z11 I1.217 J0 P1  F42000
G1 X92.3 Y94.433
G1 Z10.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40533
G1 F1655.583
M204 S6000
G1 X91.727 Y93.86 E.02442
G1 X91.214 Y93.86 E.01546
G1 X92.139 Y94.785 E.03943
G1 X92.139 Y95.297 E.01544
G1 X90.701 Y93.859 E.0613
G1 X90.188 Y93.859 E.01546
G1 X92.139 Y95.81 E.08316
G1 X92.139 Y96.323 E.01544
G1 X89.675 Y93.858 E.10502
G1 X89.162 Y93.858 E.01546
G1 X92.139 Y96.835 E.12688
G1 X92.139 Y97.348 E.01544
G1 X88.649 Y93.857 E.14874
G1 X88.136 Y93.857 E.01546
G1 X92.139 Y97.86 E.17061
G1 X92.139 Y98.373 E.01544
G1 X87.623 Y93.856 E.19247
G1 X87.11 Y93.856 E.01546
G1 X92.139 Y98.885 E.21433
G1 X92.139 Y99.398 E.01544
G1 X86.597 Y93.855 E.23619
G1 X86.084 Y93.855 E.01546
G1 X92.139 Y99.91 E.25805
G1 X92.139 Y100.423 E.01544
G1 X85.571 Y93.854 E.27992
G1 X85.058 Y93.854 E.01546
G1 X92.139 Y100.935 E.30178
G1 X92.139 Y101.448 E.01544
G1 X84.545 Y93.854 E.32364
G1 X84.032 Y93.853 E.01546
G1 X92.139 Y101.96 E.3455
G1 X92.139 Y102.473 E.01544
G1 X83.4 Y93.733 E.37244
G1 X83.4 Y94.246 E.01544
G1 X92.139 Y102.985 E.37244
G1 X92.139 Y103.498 E.01544
G1 X83.4 Y94.758 E.37244
G1 X83.4 Y95.271 E.01544
G1 X92.139 Y104.01 E.37244
G1 X92.139 Y104.14 E.00389
G1 X91.756 Y104.14 E.01154
G1 X83.4 Y95.784 E.35612
G1 X83.4 Y96.296 E.01544
M73 P90 R2
G1 X91.244 Y104.14 E.3343
G1 X90.732 Y104.141 E.01543
G1 X83.4 Y96.809 E.31248
G1 X83.4 Y97.321 E.01544
G1 X90.22 Y104.141 E.29065
G1 X89.708 Y104.142 E.01543
G1 X83.4 Y97.834 E.26883
G1 X83.4 Y98.346 E.01544
G1 X89.196 Y104.142 E.24701
G1 X88.684 Y104.143 E.01543
G1 X83.4 Y98.859 E.22519
G1 X83.4 Y99.371 E.01544
G1 X88.172 Y104.143 E.20337
G1 X87.66 Y104.144 E.01543
G1 X83.4 Y99.884 E.18154
G1 X83.4 Y100.396 E.01544
G1 X87.148 Y104.144 E.15972
G1 X86.636 Y104.145 E.01543
G1 X83.4 Y100.909 E.1379
G1 X83.4 Y101.421 E.01544
G1 X86.124 Y104.145 E.11608
G1 X85.612 Y104.146 E.01543
G1 X83.4 Y101.934 E.09425
G1 X83.4 Y102.446 E.01544
G1 X85.1 Y104.146 E.07243
G1 X84.588 Y104.146 E.01543
G1 X83.4 Y102.959 E.05061
G1 X83.4 Y103.471 E.01544
G1 X84.076 Y104.147 E.02879
G1 X83.86 Y104.147 E.0065
G1 X83.719 Y104.18 E.00437
G1 X83.633 Y104.217 E.00281
G1 X83.239 Y103.823 E.01679
M204 S500
G1 X80.933 Y106.139 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X79.505 Y106.139 E.04241
G1 X83.139 Y92.575 E.41694
G1 X83.139 Y91.861 E.02122
G1 X79.736 Y91.861 E.10105
G1 X83.043 Y95.167 E.13885
G1 X83.043 Y95.668 E.01487
G1 X78.861 Y96.789 E.12856
G1 X78.861 Y98.56 E.05259
G1 X83.043 Y102.742 E.17561
G1 X83.043 Y101.213 E.0454
G1 X78.861 Y102.334 E.12856
G1 X78.861 Y103.762 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11 I.359 J1.163 P1  F42000
G1 X98.2 Y97.8 Z11
G1 Z10.6
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
G1 X98.2 Y91.2 E.19596
G1 X121.8 Y91.2 E.7007
G1 X121.8 Y94.5 E.09798
M73 P91 R2
G1 X121.8 Y97.8 E.09798
G1 X98.26 Y97.8 E.69891
G1 X99.076 Y97.657 F42000
; FEATURE: Top surface
; LINE_WIDTH: 0.405
G1 F1657.092
G1 X98.503 Y97.085 E.02437
G1 X98.503 Y96.573 E.01542
G1 X99.427 Y97.497 E.03933
G1 X99.939 Y97.497 E.01542
G1 X98.503 Y96.061 E.06113
G1 X98.503 Y95.549 E.01542
G1 X100.451 Y97.497 E.08294
G1 X100.963 Y97.497 E.01542
G1 X98.503 Y95.037 E.10474
G1 X98.503 Y94.525 E.01542
G1 X101.475 Y97.497 E.12654
G1 X101.988 Y97.497 E.01542
G1 X98.503 Y94.012 E.14834
G1 X98.503 Y93.5 E.01542
G1 X102.5 Y97.497 E.17015
G1 X103.012 Y97.497 E.01542
G1 X98.503 Y92.988 E.19195
G1 X98.503 Y92.476 E.01542
G1 X103.524 Y97.497 E.21375
G1 X104.036 Y97.497 E.01542
G1 X98.503 Y91.964 E.23555
G1 X98.503 Y91.504 E.01387
G1 X98.555 Y91.504 E.00155
G1 X104.548 Y97.497 E.25517
G1 X105.06 Y97.497 E.01542
G1 X99.067 Y91.504 E.25517
G1 X99.579 Y91.504 E.01542
G1 X105.572 Y97.497 E.25517
G1 X106.084 Y97.497 E.01542
G1 X100.091 Y91.504 E.25517
G1 X100.603 Y91.504 E.01542
G1 X106.596 Y97.497 E.25517
G1 X107.108 Y97.497 E.01542
G1 X101.115 Y91.504 E.25517
G1 X101.627 Y91.504 E.01542
G1 X107.62 Y97.497 E.25517
G1 X108.132 Y97.497 E.01542
G1 X102.139 Y91.504 E.25517
G1 X102.651 Y91.504 E.01542
G1 X108.644 Y97.497 E.25517
G1 X109.156 Y97.497 E.01542
G1 X103.163 Y91.504 E.25517
G1 X103.675 Y91.504 E.01542
G1 X109.668 Y97.497 E.25517
G1 X110.18 Y97.497 E.01542
G1 X104.187 Y91.504 E.25517
G1 X104.7 Y91.504 E.01542
G1 X110.693 Y97.497 E.25517
G1 X111.205 Y97.497 E.01542
G1 X105.212 Y91.504 E.25517
G1 X105.724 Y91.504 E.01542
G1 X111.717 Y97.497 E.25517
G1 X112.229 Y97.497 E.01542
G1 X106.236 Y91.504 E.25517
G1 X106.748 Y91.504 E.01542
G1 X112.741 Y97.497 E.25517
G1 X113.253 Y97.497 E.01542
G1 X107.26 Y91.504 E.25517
G1 X107.772 Y91.504 E.01542
G1 X113.765 Y97.497 E.25517
G1 X114.277 Y97.497 E.01542
G1 X108.284 Y91.504 E.25517
G1 X108.796 Y91.504 E.01542
G1 X114.789 Y97.497 E.25517
G1 X115.301 Y97.497 E.01542
G1 X109.308 Y91.504 E.25517
G1 X109.82 Y91.504 E.01542
G1 X115.813 Y97.497 E.25517
G1 X116.325 Y97.497 E.01542
G1 X110.332 Y91.504 E.25517
G1 X110.844 Y91.504 E.01542
G1 X116.837 Y97.497 E.25517
G1 X117.349 Y97.497 E.01542
G1 X111.356 Y91.504 E.25517
G1 X111.868 Y91.504 E.01542
G1 X117.861 Y97.497 E.25517
G1 X118.373 Y97.497 E.01542
G1 X112.38 Y91.504 E.25517
G1 X112.892 Y91.504 E.01542
G1 X118.885 Y97.497 E.25517
G1 X119.398 Y97.497 E.01542
G1 X113.405 Y91.504 E.25517
G1 X113.917 Y91.504 E.01542
G1 X119.91 Y97.497 E.25517
G1 X120.422 Y97.497 E.01542
G1 X114.429 Y91.504 E.25517
G1 X114.941 Y91.504 E.01542
G1 X120.934 Y97.497 E.25517
G1 X121.446 Y97.497 E.01542
G1 X115.453 Y91.504 E.25517
G1 X115.965 Y91.504 E.01542
G1 X121.497 Y97.035 E.23553
G1 X121.497 Y96.523 E.01542
G1 X116.477 Y91.504 E.21372
G1 X116.989 Y91.504 E.01542
G1 X121.497 Y96.011 E.19192
G1 X121.497 Y95.499 E.01542
G1 X117.501 Y91.504 E.17012
G1 X118.013 Y91.504 E.01542
G1 X121.497 Y94.987 E.14832
G1 X121.497 Y94.475 E.01542
G1 X118.525 Y91.504 E.12652
G1 X119.037 Y91.504 E.01542
G1 X121.497 Y93.963 E.10471
G1 X121.497 Y93.451 E.01542
G1 X119.549 Y91.504 E.08291
G1 X120.061 Y91.504 E.01542
G1 X121.497 Y92.939 E.06111
G1 X121.497 Y92.427 E.01542
G1 X120.573 Y91.504 E.03931
G1 X121.085 Y91.504 E.01542
G1 X121.657 Y92.075 E.02435
; CHANGE_LAYER
; Z_HEIGHT: 10.8
; LAYER_HEIGHT: 0.2
M106 S196.35
; OBJECT_ID: 15
G1 E-.8 F1800
G17
G3 Z11 I-.043 J-1.216 P1  F42000
G1 X83.628 Y93.408 Z11
G1 Z10.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.72 Y93.49 E.00367
G1 X83.979 Y93.557 E.00794
G1 X92.443 Y93.557 E.25131
G1 X92.443 Y99 E.1616
M73 P92 R2
G1 X92.443 Y104.443 E.1616
G1 X84 Y104.443 E.25067
G1 X83.72 Y104.51 E.00855
G1 X83.541 Y104.67 E.00713
G1 X83.443 Y104.979 E.00961
G1 X83.443 Y106.443 E.04348
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.021 E.04348
G1 X83.541 Y93.33 E.00961
G1 X83.583 Y93.368 E.00168
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z11.2 I1.217 J0 P1  F42000
G1 X83.755 Y93.661
G1 Z10.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40533
G1 F1655.583
M204 S6000
G1 X83.4 Y94.016 E.01515
G1 X83.4 Y94.529 E.01544
G1 X84.076 Y93.853 E.02879
G1 X84.588 Y93.854 E.01543
G1 X83.4 Y95.041 E.05061
G1 X83.4 Y95.554 E.01544
G1 X85.1 Y93.854 E.07243
G1 X85.612 Y93.855 E.01543
G1 X83.4 Y96.066 E.09425
G1 X83.4 Y96.579 E.01544
G1 X86.124 Y93.855 E.11608
G1 X86.636 Y93.855 E.01543
G1 X83.4 Y97.091 E.1379
G1 X83.4 Y97.604 E.01544
G1 X87.148 Y93.856 E.15972
G1 X87.66 Y93.856 E.01543
G1 X83.4 Y98.116 E.18154
G1 X83.4 Y98.629 E.01544
G1 X88.172 Y93.857 E.20337
G1 X88.684 Y93.857 E.01543
G1 X83.4 Y99.141 E.22519
G1 X83.4 Y99.654 E.01544
G1 X89.196 Y93.858 E.24701
G1 X89.708 Y93.858 E.01543
G1 X83.4 Y100.166 E.26883
G1 X83.4 Y100.679 E.01544
G1 X90.22 Y93.859 E.29065
G1 X90.732 Y93.859 E.01543
G1 X83.4 Y101.191 E.31248
G1 X83.4 Y101.704 E.01544
G1 X91.244 Y93.86 E.3343
G1 X91.756 Y93.86 E.01543
G1 X83.4 Y102.216 E.35612
G1 X83.4 Y102.729 E.01544
G1 X92.139 Y93.99 E.37244
G1 X92.139 Y94.502 E.01544
G1 X83.4 Y103.242 E.37244
G1 X83.4 Y103.754 E.01544
G1 X92.139 Y95.015 E.37244
G1 X92.139 Y95.527 E.01544
G1 X83.4 Y104.267 E.37244
G1 X83.4 Y104.375 E.00325
G1 X83.572 Y104.244 E.00651
G1 X83.719 Y104.18 E.00481
G1 X83.86 Y104.147 E.00437
G1 X84.032 Y104.147 E.00519
G1 X92.139 Y96.04 E.3455
G1 X92.139 Y96.552 E.01544
G1 X84.545 Y104.146 E.32364
G1 X85.058 Y104.146 E.01546
G1 X92.139 Y97.065 E.30178
G1 X92.139 Y97.577 E.01544
G1 X85.571 Y104.146 E.27992
G1 X86.084 Y104.145 E.01546
G1 X92.139 Y98.09 E.25805
G1 X92.139 Y98.602 E.01544
G1 X86.597 Y104.145 E.23619
G1 X87.11 Y104.144 E.01546
G1 X92.139 Y99.115 E.21433
G1 X92.139 Y99.627 E.01544
G1 X87.623 Y104.144 E.19247
G1 X88.136 Y104.143 E.01546
G1 X92.139 Y100.14 E.17061
G1 X92.139 Y100.652 E.01544
G1 X88.649 Y104.143 E.14874
G1 X89.162 Y104.142 E.01546
G1 X92.139 Y101.165 E.12688
G1 X92.139 Y101.678 E.01544
G1 X89.675 Y104.142 E.10502
G1 X90.188 Y104.141 E.01546
G1 X92.139 Y102.19 E.08316
G1 X92.139 Y102.703 E.01544
G1 X90.701 Y104.141 E.0613
G1 X91.214 Y104.14 E.01546
G1 X92.139 Y103.215 E.03943
G1 X92.139 Y103.728 E.01544
G1 X91.566 Y104.301 E.02443
M204 S500
G1 X78.861 Y104.506 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y105.935 E.04241
G1 X79.065 Y106.139 E.0086
G1 X79.359 Y106.139 E.0087
G1 X83.139 Y92.029 E.43374
G1 X83.139 Y91.861 E.005
G1 X79.936 Y91.861 E.09511
G1 X83.043 Y94.967 E.13045
G1 X83.043 Y95.814 E.02515
G1 X78.861 Y96.935 E.12856
G1 X78.861 Y98.36 E.0423
G1 X83.043 Y102.542 E.17561
G1 X83.043 Y101.36 E.03511
G1 X78.861 Y102.48 E.12856
G1 X78.861 Y101.052 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I1.045 J.623 P1  F42000
G1 X83.421 Y93.397 Z11.2
G1 Z11
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.421 Y105.021 E.34513
G1 X83.443 Y105.069 E.00154
G1 X83.443 Y106.443 E.0408
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y92.738 E.03506
G1 X83.421 Y92.979 E.00717
G1 X83.421 Y93.337 E.01065
M204 S250
G1 X83.861 Y93.156 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.979 Y93.2 E.00373
G1 X92.8 Y93.2 E.26191
G1 X92.8 Y99 E.17221
G1 X92.8 Y104.8 E.17221
G1 X84 Y104.8 E.26128
M73 P93 R2
G1 X83.861 Y104.844 E.00433
G1 X83.8 Y104.979 E.00438
G1 X83.8 Y106.8 E.05408
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.021 E.05408
G1 X83.836 Y93.101 E.0026
G1 E-.8 F1800
G17
G3 Z11.4 I1.217 J0 P1  F42000
G1 X92.657 Y94.081
G1 Z11
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40769
G1 F1644.872
G1 X92.08 Y93.503 E.02477
G1 X91.564 Y93.503 E.01565
G1 X92.497 Y94.436 E.04001
G1 X92.497 Y94.952 E.01565
G1 X91.048 Y93.503 E.06213
G1 X90.532 Y93.503 E.01565
G1 X92.497 Y95.468 E.08426
G1 X92.497 Y95.984 E.01565
G1 X90.016 Y93.503 E.10639
G1 X89.5 Y93.503 E.01565
G1 X92.497 Y96.5 E.12852
G1 X92.497 Y97.015 E.01565
G1 X88.985 Y93.503 E.15064
G1 X88.469 Y93.503 E.01565
G1 X92.497 Y97.531 E.17277
G1 X92.497 Y98.047 E.01565
G1 X87.953 Y93.503 E.1949
G1 X87.437 Y93.503 E.01565
G1 X92.497 Y98.563 E.21703
G1 X92.497 Y99.079 E.01565
G1 X86.921 Y93.503 E.23915
G1 X86.405 Y93.503 E.01565
G1 X92.497 Y99.595 E.26128
G1 X92.497 Y100.111 E.01565
G1 X85.889 Y93.503 E.28341
G1 X85.374 Y93.503 E.01565
G1 X92.497 Y100.626 E.30554
G1 X92.497 Y101.142 E.01565
G1 X84.858 Y93.503 E.32766
G1 X84.342 Y93.503 E.01565
G1 X92.497 Y101.658 E.34979
G1 X92.497 Y102.174 E.01565
G1 X83.773 Y93.451 E.37418
G1 X83.725 Y93.423 E.00169
G1 X83.725 Y93.918 E.01501
G1 X92.497 Y102.69 E.37626
G1 X92.497 Y103.206 E.01565
G1 X83.725 Y94.434 E.37626
G1 X83.725 Y94.95 E.01565
G1 X92.497 Y103.722 E.37626
G1 X92.497 Y104.237 E.01565
G1 X83.725 Y95.466 E.37626
G1 X83.725 Y95.982 E.01565
G1 X92.24 Y104.497 E.36525
G1 X91.724 Y104.497 E.01565
G1 X83.725 Y96.497 E.34312
G1 X83.725 Y97.013 E.01565
G1 X91.208 Y104.497 E.32099
G1 X90.692 Y104.497 E.01565
G1 X83.725 Y97.529 E.29886
G1 X83.725 Y98.045 E.01565
G1 X90.176 Y104.497 E.27674
G1 X89.661 Y104.497 E.01565
G1 X83.725 Y98.561 E.25461
G1 X83.725 Y99.077 E.01565
G1 X89.145 Y104.497 E.23248
G1 X88.629 Y104.497 E.01565
G1 X83.725 Y99.593 E.21035
G1 X83.725 Y100.108 E.01565
G1 X88.113 Y104.497 E.18823
G1 X87.597 Y104.497 E.01565
G1 X83.725 Y100.624 E.1661
G1 X83.725 Y101.14 E.01565
G1 X87.081 Y104.497 E.14397
G1 X86.565 Y104.497 E.01565
G1 X83.725 Y101.656 E.12184
G1 X83.725 Y102.172 E.01565
G1 X86.05 Y104.497 E.09972
G1 X85.534 Y104.497 E.01565
G1 X83.725 Y102.688 E.07759
G1 X83.725 Y103.204 E.01565
G1 X85.018 Y104.497 E.05546
G1 X84.502 Y104.497 E.01565
G1 X83.725 Y103.72 E.03333
G1 X83.725 Y104.235 E.01565
G1 X84.147 Y104.657 E.0181
G1 E-.8 F1800
G17
G3 Z11.4 I.081 J-1.214 P1  F42000
G1 X78.861 Y104.306 Z11.4
G1 Z11
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X78.861 Y105.735 E.04241
G1 X79.265 Y106.139 E.017
G1 X79.212 Y106.139 E.00158
G1 X83.038 Y91.861 E.43891
G1 X80.136 Y91.861 E.08616
M73 P93 R1
G1 X83.118 Y94.842 E.1252
G1 X83.118 Y95.941 E.03261
G1 X78.861 Y97.081 E.13087
G1 X78.861 Y98.16 E.03202
G1 X83.118 Y102.417 E.17877
G1 X83.118 Y101.486 E.02765
G1 X78.861 Y102.627 E.13087
G1 X78.861 Y101.198 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.2
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.4 I1.045 J.623 P1  F42000
G1 X83.443 Y93.508 Z11.4
G1 Z11.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1566
M204 S6000
G1 X83.443 Y94 E.01459
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.448 E.05616
M204 S250
G1 X83.8 Y93.508 F42000
; FEATURE: Outer wall
G1 F1566
M204 S500
G1 X83.8 Y94 E.01459
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
M73 P94 R1
G1 X83.8 Y93.448 E.06676
G1 E-.8 F1800
G17
G3 Z11.6 I1.217 J0 P1  F42000
G1 X78.861 Y101.345
G1 Z11.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1566
M204 S6000
G1 X78.861 Y102.773 E.04241
G1 X83.139 Y101.626 E.13153
G1 X83.139 Y102.239 E.01818
G1 X78.861 Y97.96 E.17967
G1 X78.861 Y97.228 E.02173
G1 X83.139 Y96.081 E.13153
G1 X83.139 Y94.664 E.04209
G1 X80.336 Y91.861 E.11771
G1 X82.892 Y91.861 E.07588
G1 X79.066 Y106.139 E.43891
G1 X79.465 Y106.139 E.01187
G1 X78.861 Y105.535 E.0254
G1 X78.861 Y104.106 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.6 I1.116 J.484 P1  F42000
G1 X83.443 Y93.548 Z11.6
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1545
M204 S6000
G1 X83.443 Y94 E.01343
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.488 E.05732
M204 S250
G1 X83.8 Y93.548 F42000
; FEATURE: Outer wall
G1 F1545
M204 S500
G1 X83.8 Y94 E.01343
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.488 E.06792
G1 E-.8 F1800
G17
G3 Z11.8 I1.217 J0 P1  F42000
G1 X78.861 Y101.491
G1 Z11.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1545
M204 S6000
G1 X78.861 Y102.919 E.04241
G1 X83.139 Y101.773 E.13153
G1 X83.139 Y102.039 E.00789
G1 X78.861 Y97.76 E.17967
G1 X78.861 Y97.374 E.01145
G1 X83.139 Y96.228 E.13153
G1 X83.139 Y94.464 E.05237
G1 X80.536 Y91.861 E.10931
G1 X82.745 Y91.861 E.06559
G1 X78.919 Y106.139 E.43891
G1 X79.665 Y106.139 E.02215
G1 X78.861 Y105.335 E.0338
; CHANGE_LAYER
; Z_HEIGHT: 11.6
; LAYER_HEIGHT: 0.200001
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I1.134 J.442 P1  F42000
G1 X83.443 Y93.585 Z11.8
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1542
M204 S6000
G1 X83.443 Y94 E.01233
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.525 E.05843
M204 S250
G1 X83.8 Y93.585 F42000
; FEATURE: Outer wall
G1 F1542
M204 S500
G1 X83.8 Y94 E.01233
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.525 E.06903
G1 E-.8 F1800
G17
G3 Z12 I1.217 J0 P1  F42000
G1 X78.861 Y101.637
G1 Z11.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1542
M204 S6000
G1 X78.861 Y103.066 E.04241
G1 X83.139 Y101.919 E.13153
G1 X83.139 Y101.839 E.00239
G1 X78.861 Y97.56 E.17967
G1 X78.861 Y97.521 E.00116
G1 X83.139 Y96.374 E.13153
G1 X83.139 Y94.264 E.06266
G1 X80.736 Y91.861 E.10091
G1 X82.599 Y91.861 E.05531
G1 X78.861 Y105.812 E.42886
G1 X78.861 Y106.139 E.00972
G1 X79.865 Y106.139 E.02984
G1 X78.861 Y105.135 E.0422
; CHANGE_LAYER
; Z_HEIGHT: 11.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12 I1.131 J.45 P1  F42000
G1 X83.443 Y93.621 Z12
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1590
M204 S6000
G1 X83.443 Y94 E.01126
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.561 E.05949
M204 S250
G1 X83.8 Y93.621 F42000
; FEATURE: Outer wall
G1 F1590
M204 S500
G1 X83.8 Y94 E.01126
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.561 E.07009
M73 P95 R1
G1 E-.8 F1800
G17
G3 Z12.2 I1.217 J0 P1  F42000
G1 X83.139 Y92.602
G1 Z11.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1590
M204 S6000
G1 X83.139 Y91.861 E.02201
G1 X82.452 Y91.861 E.0204
G1 X78.861 Y105.266 E.41206
G1 X78.861 Y104.935 E.00984
G1 X80.065 Y106.139 E.05059
G1 X81.494 Y106.139 E.04241
M204 S500
G1 X78.861 Y101.784 F42000
G1 F1590
M204 S6000
G1 X78.861 Y103.212 E.04241
G1 X83.139 Y102.066 E.13153
G1 X83.139 Y101.639 E.01268
G1 X78.861 Y97.36 E.17967
G1 X78.861 Y97.667 E.00912
G1 X83.139 Y96.521 E.13153
G1 X83.139 Y94.064 E.07294
G1 X80.936 Y91.861 E.09251
G1 X79.836 Y91.861 E.03267
G1 X78.861 Y92.122 E.02998
G1 X78.861 Y93.55 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.2 I-.028 J1.217 P1  F42000
G1 X83.443 Y93.655 Z12.2
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1591
M204 S6000
G1 X83.443 Y94 E.01025
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.595 E.0605
M204 S250
G1 X83.8 Y93.655 F42000
; FEATURE: Outer wall
G1 F1591
M204 S500
G1 X83.8 Y94 E.01025
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.595 E.0711
G1 E-.8 F1800
G17
G3 Z12.4 I1.217 J0 P1  F42000
G1 X83.139 Y92.456
G1 Z12
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1591
M204 S6000
G1 X83.139 Y91.861 E.01767
G1 X82.306 Y91.861 E.02474
G1 X78.861 Y104.719 E.39526
G1 X78.861 Y104.735 E.00045
G1 X80.265 Y106.139 E.05899
G1 X81.694 Y106.139 E.04241
M204 S500
G1 X78.861 Y101.93 F42000
G1 F1591
M204 S6000
G1 X78.861 Y103.359 E.04241
G1 X83.139 Y102.212 E.13153
G1 X83.139 Y101.439 E.02297
G1 X78.861 Y97.16 E.17967
G1 X78.861 Y97.813 E.01941
G1 X83.139 Y96.667 E.13153
G1 X83.139 Y93.864 E.08323
G1 X81.136 Y91.861 E.08412
G1 X80.382 Y91.861 E.02238
G1 X78.861 Y92.268 E.04678
G1 X78.861 Y93.697 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I.003 J1.217 P1  F42000
G1 X83.443 Y93.687 Z12.4
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1584
M204 S6000
G1 X83.443 Y94 E.00929
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.627 E.06146
M204 S250
G1 X83.8 Y93.687 F42000
; FEATURE: Outer wall
G1 F1584
M204 S500
G1 X83.8 Y94 E.00929
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.627 E.07206
G1 E-.8 F1800
G17
G3 Z12.6 I1.217 J0 P1  F42000
G1 X83.139 Y98.242
G1 Z12.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1584
M204 S6000
G1 X83.139 Y96.813 E.04241
G1 X78.861 Y97.96 E.13153
G1 X78.861 Y96.96 E.0297
G1 X83.139 Y101.239 E.17967
G1 X83.139 Y102.359 E.03325
G1 X78.861 Y103.505 E.13153
M204 S500
G1 X81.894 Y106.139 F42000
G1 F1584
M204 S6000
G1 X80.465 Y106.139 E.04241
G1 X78.861 Y104.535 E.06739
G1 X78.861 Y104.173 E.01074
G1 X82.16 Y91.861 E.37847
G1 X83.139 Y91.861 E.02909
G1 X83.139 Y93.664 E.05354
G1 X81.336 Y91.861 E.07572
G1 X80.929 Y91.861 E.01209
G1 X78.861 Y92.415 E.06358
G1 X78.861 Y93.843 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.4
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.6 I.033 J1.217 P1  F42000
G1 X83.443 Y93.718 Z12.6
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1604
M204 S6000
G1 X83.443 Y94 E.00838
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.658 E.06237
M204 S250
G1 X83.8 Y93.718 F42000
; FEATURE: Outer wall
G1 F1604
M204 S500
G1 X83.8 Y94 E.00838
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.658 E.07297
G1 E-.8 F1800
G17
G3 Z12.8 I1.217 J0 P1  F42000
G1 X83.139 Y98.388
M73 P96 R1
G1 Z12.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1604
M204 S6000
G1 X83.139 Y96.96 E.04241
G1 X78.861 Y98.106 E.13153
G1 X78.861 Y96.76 E.03998
G1 X83.139 Y101.039 E.17967
G1 X83.139 Y102.505 E.04354
G1 X78.861 Y103.651 E.13153
G1 X82.013 Y91.861 E.36239
G1 X83.139 Y91.861 E.03344
G1 X83.139 Y93.464 E.0476
G1 X81.536 Y91.861 E.06732
G1 X81.475 Y91.861 E.00181
G1 X78.861 Y92.561 E.08037
G1 X78.861 Y93.99 E.04241
M204 S500
G1 X78.861 Y105.763 F42000
G1 F1604
M204 S6000
G1 X78.861 Y104.335 E.04241
G1 X80.665 Y106.139 E.07579
G1 X82.094 Y106.139 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.6
; LAYER_HEIGHT: 0.200001
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.8 I1.21 J.132 P1  F42000
G1 X83.443 Y93.747 Z12.8
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1602
M204 S6000
G1 X83.443 Y94 E.00752
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.687 E.06323
M204 S250
G1 X83.8 Y93.747 F42000
; FEATURE: Outer wall
G1 F1602
M204 S500
G1 X83.8 Y94 E.00752
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.687 E.07384
G1 E-.8 F1800
G17
G3 Z13 I1.217 J0 P1  F42000
G1 X83.139 Y95.678
G1 Z12.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1602
M204 S6000
G1 X83.139 Y97.106 E.04241
G1 X78.861 Y98.253 E.13153
G1 X78.861 Y96.56 E.05027
G1 X83.139 Y100.839 E.17967
G1 X83.139 Y102.651 E.05382
G1 X78.861 Y103.798 E.13153
G1 X78.861 Y104.135 E.01
G1 X80.865 Y106.139 E.08419
G1 X82.294 Y106.139 E.04241
M204 S500
G1 X78.861 Y103.619 F42000
G1 F1602
M204 S6000
G1 X78.861 Y103.08 E.01601
G1 X81.867 Y91.861 E.34488
G1 X81.736 Y91.861 E.00388
G1 X83.139 Y93.264 E.05892
G1 X83.139 Y91.861 E.04166
G1 X82.022 Y91.861 E.03319
G1 X78.861 Y92.708 E.09717
G1 X78.861 Y94.136 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I.096 J1.213 P1  F42000
G1 X83.443 Y93.774 Z13
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1605
M204 S6000
G1 X83.443 Y94 E.0067
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.714 E.06405
M204 S250
G1 X83.8 Y93.774 F42000
; FEATURE: Outer wall
G1 F1605
M204 S500
G1 X83.8 Y94 E.00671
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.714 E.07465
G1 E-.8 F1800
G17
G3 Z13.2 I1.217 J0 P1  F42000
G1 X83.139 Y95.824
G1 Z12.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1605
M204 S6000
G1 X83.139 Y97.253 E.04241
G1 X78.861 Y98.399 E.13153
G1 X78.861 Y96.36 E.06055
G1 X83.139 Y100.639 E.17967
G1 X83.139 Y102.798 E.06411
G1 X78.861 Y103.944 E.13153
G1 X81.065 Y106.139 E.09238
G1 X82.494 Y106.139 E.04241
M204 S500
G1 X78.861 Y103.756 F42000
G1 F1605
M204 S6000
G1 X78.861 Y102.534 E.03629
G1 X81.72 Y91.861 E.32808
M204 S500
G1 X81.936 Y91.861 F42000
G1 F1605
M204 S6000
G1 X83.139 Y93.064 E.05052
G1 X83.139 Y91.861 E.03573
G1 X82.568 Y91.861 E.01696
G1 X78.861 Y92.854 E.11396
G1 X78.861 Y91.861 E.0295
G1 X79.295 Y91.861 E.01291
; CHANGE_LAYER
; Z_HEIGHT: 13
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.2 I-.515 J1.102 P1  F42000
G1 X83.443 Y93.8 Z13.2
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1637
M204 S6000
G1 X83.443 Y94 E.00595
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.74 E.0648
M204 S250
G1 X83.8 Y93.8 F42000
; FEATURE: Outer wall
G1 F1637
M204 S500
G1 X83.8 Y94 E.00595
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
M73 P96 R0
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.74 E.07541
G1 E-.8 F1800
G17
G3 Z13.4 I1.217 J0 P1  F42000
G1 X83.139 Y95.971
G1 Z13
M73 P97 R0
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1637
M204 S6000
G1 X83.139 Y97.399 E.04241
G1 X78.861 Y98.546 E.13153
G1 X78.861 Y96.16 E.07084
G1 X83.139 Y100.439 E.17967
G1 X83.139 Y102.944 E.07439
G1 X78.861 Y104.091 E.13153
G1 X78.861 Y103.735 E.01057
G1 X81.265 Y106.139 E.10098
G1 X82.694 Y106.139 E.04241
M204 S500
G1 X78.861 Y103.416 F42000
G1 F1637
M204 S6000
G1 X78.861 Y101.987 E.04241
G1 X81.574 Y91.861 E.31128
G1 X78.861 Y91.861 E.08057
G1 X78.861 Y93 E.03384
G1 X83.114 Y91.861 E.13076
G1 X83.139 Y91.861 E.00074
G1 X83.139 Y92.864 E.02979
G1 X82.136 Y91.861 E.04213
; CHANGE_LAYER
; Z_HEIGHT: 13.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.4 I-1.013 J.674 P1  F42000
G1 X83.443 Y93.824 Z13.4
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.443 Y94 E.00524
G1 X83.443 Y106.443 E.36944
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y93.764 E.06551
M204 S250
G1 X83.8 Y93.824 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X83.8 Y94 E.00524
G1 X83.8 Y106.8 E.38004
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y93.764 E.07611
G1 E-.8 F1800
G17
G3 Z13.6 I1.217 J0 P1  F42000
G1 X82.782 Y93.192
G1 Z13.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X82.782 Y92.218 E.02892
G1 X82.328 Y92.218 E.01349
G1 X79.218 Y93.051 E.0956
G1 X79.218 Y96.317 E.09697
G1 X82.782 Y99.881 E.14967
G1 X82.782 Y97.641 E.06652
G1 X79.218 Y98.596 E.10957
G1 X79.218 Y97.168 E.04241
M204 S500
G1 X83.113 Y92.039 F42000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.38314
G1 F1763.565
M204 S6000
G1 X83.087 Y91.913 E.00363
G1 X82.961 Y91.887 E.00363
G1 X79.039 Y91.887 E.11094
G1 X78.913 Y91.913 E.00363
G1 X78.887 Y92.039 E.00363
G1 X78.887 Y105.961 E.39383
G1 X78.913 Y106.087 E.00363
G1 X79.039 Y106.113 E.00363
G1 X82.961 Y106.113 E.11094
G1 X83.087 Y106.087 E.00363
G1 X83.113 Y105.961 E.00363
G1 X83.113 Y92.099 E.39214
M204 S500
G1 X81.332 Y92.218 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X79.218 Y100.108 E.24254
G1 X79.218 Y101.536 E.04241
M204 S500
G1 X82.782 Y101.758 F42000
G1 F1680.297
M204 S6000
G1 X82.782 Y103.186 E.04241
G1 X79.218 Y104.141 E.10957
G1 X79.218 Y103.892 E.00741
G1 X81.108 Y105.782 E.07938
G1 X82.537 Y105.782 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 13.4
; LAYER_HEIGHT: 0.2
M106 S196.35
; OBJECT_ID: 15
M204 S500
G1 X83.443 Y106.443 Z13.4 F42000
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z13.8 I1.217 J0 P1  F42000
G1 X82.377 Y106.295
G1 Z13.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40424
; LAYER_HEIGHT: 0.4
M106 S255
G1 F935.003
M204 S6000
G1 X83.093 Y105.579 E.05404
G1 X83.093 Y104.937 E.03428
G1 X81.937 Y106.093 E.08724
G1 X81.295 Y106.093 E.03428
G1 X83.093 Y104.295 E.13571
G1 X83.093 Y103.652 E.03428
G1 X80.652 Y106.093 E.18419
G1 X80.01 Y106.093 E.03428
G1 X83.093 Y103.01 E.23266
G1 X83.093 Y102.367 E.03428
G1 X79.367 Y106.093 E.28114
G1 X78.907 Y106.093 E.02456
G1 X78.907 Y105.911 E.00972
G1 X83.093 Y101.725 E.31587
G1 X83.093 Y101.083 E.03428
G1 X78.907 Y105.269 E.31587
G1 X78.907 Y104.626 E.03428
G1 X83.093 Y100.44 E.31587
G1 X83.093 Y99.798 E.03428
G1 X78.907 Y103.984 E.31587
G1 X78.907 Y103.341 E.03428
G1 X83.093 Y99.155 E.31587
G1 X83.093 Y98.513 E.03428
G1 X78.907 Y102.699 E.31587
G1 X78.907 Y102.057 E.03428
G1 X83.093 Y97.871 E.31587
G1 X83.093 Y97.228 E.03428
G1 X78.907 Y101.414 E.31587
G1 X78.907 Y100.772 E.03428
G1 X83.093 Y96.586 E.31587
G1 X83.093 Y95.943 E.03428
G1 X78.907 Y100.129 E.31587
G1 X78.907 Y99.487 E.03428
G1 X83.093 Y95.301 E.31587
G1 X83.093 Y94.659 E.03428
G1 X78.907 Y98.845 E.31587
G1 X78.907 Y98.202 E.03428
M73 P98 R0
G1 X83.093 Y94.016 E.31587
G1 X83.093 Y93.374 E.03428
G1 X78.907 Y97.56 E.31587
G1 X78.907 Y96.917 E.03428
G1 X83.093 Y92.731 E.31587
G1 X83.093 Y92.089 E.03428
G1 X78.907 Y96.275 E.31587
G1 X78.907 Y95.633 E.03428
G1 X82.633 Y91.907 E.28113
G1 X81.99 Y91.907 E.03428
G1 X78.907 Y94.99 E.23266
G1 X78.907 Y94.348 E.03428
G1 X81.348 Y91.907 E.18418
G1 X80.705 Y91.907 E.03428
G1 X78.907 Y93.705 E.13571
G1 X78.907 Y93.063 E.03428
G1 X80.063 Y91.907 E.08723
G1 X79.421 Y91.907 E.03428
G1 X78.705 Y92.623 E.05404
M106 S196.35
; CHANGE_LAYER
; Z_HEIGHT: 13.6
; LAYER_HEIGHT: 0.200001
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.8 I-1.151 J.395 P1  F42000
G1 X83.443 Y106.443 Z13.8
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z14 I1.217 J0 P1  F42000
G1 X83.086 Y94
G1 Z13.6
G1 E.8 F1800
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X83.086 Y91.914 E.06193
G1 X78.914 Y91.914 E.12386
G1 X78.914 Y106.086 E.42077
G1 X83.086 Y106.086 E.12386
G1 X83.086 Y94.06 E.35705
M204 S500
G1 X81.24 Y104.24 F42000
; LINE_WIDTH: 0.52197
G1 F1252.479
M204 S6000
G1 X81.24 Y93.76 E.41741
G1 X80.76 Y93.76 E.01908
G1 X80.76 Y104.24 E.41741
G1 X81.18 Y104.24 E.01669
M204 S500
G1 X81.658 Y104.658 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X81.658 Y93.342 E.33595
G1 X80.342 Y93.342 E.03905
G1 X80.342 Y104.658 E.33595
G1 X81.598 Y104.658 E.03727
M204 S500
G1 X82.015 Y105.015 F42000
G1 F1680.343
M204 S6000
G1 X82.015 Y92.985 E.35716
G1 X79.985 Y92.985 E.06025
G1 X79.985 Y105.015 E.35716
G1 X81.955 Y105.015 E.05847
M204 S500
G1 X82.372 Y105.372 F42000
G1 F1680.343
M204 S6000
G1 X82.372 Y92.628 E.37836
G1 X79.628 Y92.628 E.08145
G1 X79.628 Y105.372 E.37836
G1 X82.312 Y105.372 E.07967
M204 S500
G1 X82.729 Y105.729 F42000
G1 F1680.343
M204 S6000
G1 X82.729 Y92.271 E.39956
G1 X79.271 Y92.271 E.10266
G1 X79.271 Y105.729 E.39956
G1 X82.669 Y105.729 E.10088
; CHANGE_LAYER
; Z_HEIGHT: 13.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
M204 S500
G1 X83.443 Y106.443 Z13.8 F42000
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X78.557 Y106.443 E.14506
G1 X78.557 Y91.557 E.44197
G1 X83.443 Y91.557 E.14506
G1 X83.443 Y94 E.07253
G1 X83.443 Y106.383 E.36766
M204 S250
G1 X83.8 Y106.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z14.2 I1.217 J0 P1  F42000
G1 X83.086 Y94
G1 Z13.8
G1 E.8 F1800
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X83.086 Y91.914 E.06193
G1 X78.914 Y91.914 E.12386
G1 X78.914 Y106.086 E.42077
G1 X83.086 Y106.086 E.12386
M73 P99 R0
G1 X83.086 Y94.06 E.35705
M204 S500
G1 X81.24 Y104.24 F42000
; LINE_WIDTH: 0.52197
G1 F1252.479
M204 S6000
G1 X81.24 Y93.76 E.41741
G1 X80.76 Y93.76 E.01908
G1 X80.76 Y104.24 E.41741
G1 X81.18 Y104.24 E.01669
M204 S500
G1 X81.658 Y104.658 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X81.658 Y93.342 E.33595
G1 X80.342 Y93.342 E.03905
G1 X80.342 Y104.658 E.33595
G1 X81.598 Y104.658 E.03727
M204 S500
G1 X82.015 Y105.015 F42000
G1 F1680.343
M204 S6000
G1 X82.015 Y92.985 E.35716
G1 X79.985 Y92.985 E.06025
G1 X79.985 Y105.015 E.35716
G1 X81.955 Y105.015 E.05847
M204 S500
G1 X82.372 Y105.372 F42000
G1 F1680.343
M204 S6000
G1 X82.372 Y92.628 E.37836
G1 X79.628 Y92.628 E.08145
G1 X79.628 Y105.372 E.37836
G1 X82.312 Y105.372 E.07967
M204 S500
G1 X82.729 Y105.729 F42000
G1 F1680.343
M204 S6000
G1 X82.729 Y92.271 E.39956
G1 X79.271 Y92.271 E.10266
G1 X79.271 Y105.729 E.39956
G1 X82.669 Y105.729 E.10088
; CHANGE_LAYER
; Z_HEIGHT: 14
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
M204 S250
G1 X83.8 Y106.8 Z14 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X78.2 Y106.8 E.16627
G1 X78.2 Y91.2 E.46317
G1 X83.8 Y91.2 E.16627
G1 X83.8 Y94 E.08313
G1 X83.8 Y106.74 E.37826
G1 E-.8 F1800
G17
G3 Z14.4 I1.217 J0 P1  F42000
G1 X82.917 Y106.657
G1 Z14
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40885
G1 F1639.658
G1 X83.496 Y106.077 E.02496
G1 X83.496 Y105.56 E.01575
G1 X82.56 Y106.497 E.04031
G1 X82.042 Y106.497 E.01575
G1 X83.496 Y105.042 E.06258
G1 X83.496 Y104.525 E.01575
G1 X81.525 Y106.497 E.08485
G1 X81.007 Y106.497 E.01575
G1 X83.496 Y104.007 E.10711
G1 X83.496 Y103.49 E.01575
G1 X80.49 Y106.497 E.12938
G1 X79.972 Y106.497 E.01575
G1 X83.496 Y102.972 E.15165
G1 X83.496 Y102.455 E.01575
G1 X79.455 Y106.497 E.17392
G1 X78.937 Y106.497 E.01575
G1 X83.496 Y101.937 E.19619
G1 X83.496 Y101.42 E.01575
G1 X78.503 Y106.413 E.21485
G1 X78.503 Y105.895 E.01575
G1 X83.496 Y100.902 E.21485
G1 X83.496 Y100.385 E.01575
G1 X78.503 Y105.378 E.21485
G1 X78.503 Y104.86 E.01575
G1 X83.496 Y99.867 E.21485
G1 X83.496 Y99.35 E.01575
G1 X78.503 Y104.343 E.21485
G1 X78.503 Y103.825 E.01575
G1 X83.496 Y98.832 E.21485
G1 X83.496 Y98.315 E.01575
G1 X78.503 Y103.308 E.21485
G1 X78.503 Y102.79 E.01575
G1 X83.496 Y97.797 E.21485
G1 X83.496 Y97.28 E.01575
G1 X78.503 Y102.273 E.21485
G1 X78.503 Y101.755 E.01575
G1 X83.496 Y96.762 E.21485
G1 X83.496 Y96.245 E.01575
G1 X78.503 Y101.238 E.21485
G1 X78.503 Y100.72 E.01575
G1 X83.496 Y95.727 E.21485
G1 X83.496 Y95.21 E.01575
G1 X78.503 Y100.203 E.21485
G1 X78.503 Y99.685 E.01575
G1 X83.496 Y94.692 E.21485
G1 X83.496 Y94.175 E.01575
G1 X78.503 Y99.168 E.21485
G1 X78.503 Y98.65 E.01575
G1 X83.496 Y93.657 E.21485
G1 X83.496 Y93.14 E.01575
G1 X78.503 Y98.133 E.21485
G1 X78.503 Y97.615 E.01575
G1 X83.496 Y92.622 E.21485
G1 X83.496 Y92.105 E.01575
G1 X78.503 Y97.098 E.21485
G1 X78.503 Y96.58 E.01575
G1 X83.496 Y91.587 E.21485
G1 X83.496 Y91.504 E.00255
G1 X83.063 Y91.504 E.0132
G1 X78.503 Y96.063 E.19618
G1 X78.503 Y95.545 E.01575
G1 X82.545 Y91.504 E.17392
G1 X82.028 Y91.504 E.01575
G1 X78.503 Y95.028 E.15165
G1 X78.503 Y94.51 E.01575
G1 X81.51 Y91.504 E.12938
G1 X80.993 Y91.504 E.01575
G1 X78.503 Y93.993 E.10711
G1 X78.503 Y93.475 E.01575
G1 X80.475 Y91.504 E.08484
G1 X79.958 Y91.504 E.01575
G1 X78.503 Y92.958 E.06257
G1 X78.503 Y92.44 E.01575
G1 X79.44 Y91.504 E.04031
G1 X78.923 Y91.504 E.01575
G1 X78.343 Y92.083 E.02495
; close powerlost recovery
M1003 S0
G1 E-.8 F1800
G17
G3 Z14.4 I1.217 J0 P1  F42000
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
M104 S0 ; turn off temperature
G28 X0  ; home X axis
M84     ; disable motors
M73 P100 R0
; EXECUTABLE_BLOCK_END

