; HEADER_BLOCK_START
; BambuStudio 02.08.02.61
; model printing time: 32m 33s; total estimated time: 32m 33s
; total layer number: 120
; total filament length [mm] : 1328.58
; total filament volume [cm^3] : 3195.60
; total filament weight [g] : 0.00
; filament_density: 0
; filament_diameter: 1.75
; max_z_height: 16.00
; filament: 1
; support_material_on_wipe_tower: 0
; HEADER_BLOCK_END

; CONFIG_BLOCK_START
; accel_to_decel_enable = 0
; accel_to_decel_factor = 50%
; activate_air_filtration = 0
; additional_cooling_fan_speed = 0
; additional_fan_full_speed_layer = 0
; alternate_extra_wall = 0
; ams_filament_load_time_ams = 0
; ams_filament_load_time_ams_lite = 0
; ams_filament_load_time_n3f_s = 0
; ams_filament_unload_time_ams = 0
; ams_filament_unload_time_ams_lite = 0
; ams_filament_unload_time_n3f_s = 0
; apply_scarf_seam_on_circles = 1
; auxiliary_fan = 0
; avoid_crossing_wall_includes_support = 0
; bed_custom_model = 
; bed_custom_texture = 
; bed_exclude_area = 
; bed_heat_soak_area = 
; bed_temperature_formula = by_first_filament
; before_layer_change_gcode = 
; best_object_pos = 0.5,0.5
; bottom_color_penetration_layers = 3
; bottom_shell_layers = 3
; bottom_shell_thickness = 0
; bottom_surface_density = 100%
; bottom_surface_pattern = zig-zag
; bridge_angle = 0
; bridge_flow = 1
; bridge_no_support = 0
; bridge_speed = 25
; brim_object_gap = 0
; brim_type = auto_brim
; brim_width = 0
; chamber_temperatures = 0
; change_filament_gcode = 
; circle_compensation_manual_offset = 0
; circle_compensation_speed = 200
; close_additional_fan_first_x_layers = 1
; close_fan_the_first_x_layers = 1
; complete_print_exhaust_fan_speed = 80
; cool_plate_temp = 35
; cool_plate_temp_initial_layer = 35
; cooling_filter_enabled = 0
; cooling_perimeter_transition_distance = 10
; cooling_slowdown_logic = uniform_cooling
; counter_coef_1 = 0
; counter_coef_2 = 0.025
; counter_coef_3 = -0.11
; counter_limit_max = 0.05
; counter_limit_min = -0.04
; counterbore_hole_bridging = none
; curr_bed_type = Cool Plate
; default_acceleration = 6000
; default_ams_type = -1
; default_filament_colour = ""
; default_filament_profile = "Bambu PLA Basic @BBL A1"
; default_jerk = 0
; default_print_profile = 0.20mm Standard @BBL A1
; deretraction_speed = 0
; detect_floating_vertical_shell = 1
; detect_narrow_internal_solid_infill = 1
; detect_overhang_wall = 1
; detect_thin_wall = 0
; diameter_limit = 50
; different_settings_to_system = ;;
; draft_shield = disabled
; during_print_exhaust_fan_speed = 60
; elefant_foot_compensation = 0.075
; embedding_wall_into_infill = 0
; enable_arc_fitting = 0
; enable_circle_compensation = 0
; enable_filament_dynamic_map = 0
; enable_height_slowdown = 0
; enable_long_retraction_when_cut = 2
; enable_mixed_color_sublayer = 0
; enable_order_independent_overlap_carving = 0
; enable_overhang_bridge_fan = 1
; enable_overhang_speed = 1
; enable_pre_heating = 0
; enable_pressure_advance = 0
; enable_prime_tower = 0
; enable_support = 1
; enable_support_ironing = 0
; enable_tower_interface_features = 0
; enable_wrapping_detection = 0
; enforce_support_layers = 0
; eng_plate_temp = 45
; eng_plate_temp_initial_layer = 45
; ensure_vertical_shell_thickness = enabled
; exclude_object = 1
; extruder_ams_count = 
; extruder_clearance_dist_to_rod = 56.5
; extruder_clearance_height_to_lid = 256
; extruder_clearance_height_to_rod = 25
; extruder_clearance_max_radius = 73
; extruder_colour = ""
; extruder_max_nozzle_count = 1
; extruder_nozzle_stats = 
; extruder_offset = 0x0
; extruder_printable_area = 
; extruder_printable_height = 0
; extruder_type = Direct Drive
; fan_cooling_layer_time = 80
; fan_direction = undefine
; fan_max_speed = 80
; fan_min_speed = 60
; farthest_point_timelapse = 0
; filament_adaptive_volumetric_speed = 0
; filament_adhesiveness_category = 0
; filament_bridge_speed = 25
; filament_change_length = 10
; filament_change_length_nc = 10
; filament_colour = #00AE42
; filament_cooling_before_tower = 10
; filament_cost = 0
; filament_density = 0
; filament_dev_ams_drying_ams_limitations = ""
; filament_dev_ams_drying_heat_distortion_temperature = 0
; filament_dev_ams_drying_temperature = 0
; filament_dev_ams_drying_time = 0
; filament_dev_chamber_drying_bed_temperature = 0
; filament_dev_chamber_drying_time = 0
; filament_dev_drying_cooling_temperature = 0
; filament_dev_drying_softening_temperature = 0
; filament_diameter = 1.75
; filament_enable_overhang_speed = 1
; filament_end_gcode = " "
; filament_extruder_compatibility = 0
; filament_extruder_variant = "Direct Drive Standard"
; filament_flow_ratio = 1
; filament_flush_temp = 0
; filament_flush_temp_fast = 0
; filament_flush_volumetric_speed = 0
; filament_ids = ""
; filament_is_mixed = 0
; filament_is_support = 0
; filament_map = 1
; filament_map_2 = 0
; filament_map_mode = Auto For Flush
; filament_max_volumetric_speed = 2
; filament_metal_stickiness = None
; filament_minimal_purge_on_wipe_tower = 15
; filament_mixed_components = ""
; filament_mixed_gradient = 0
; filament_mixed_gradient_curve = ""
; filament_mixed_gradient_per_part = 0
; filament_mixed_gradient_range = ""
; filament_mixed_sublayer_ratios = ""
; filament_notes = 
; filament_nozzle_map = 0
; filament_overhang_1_4_speed = 0
; filament_overhang_2_4_speed = 0
; filament_overhang_3_4_speed = 0
; filament_overhang_4_4_speed = 0
; filament_overhang_totally_speed = 10
; filament_pre_cooling_temperature = 0
; filament_pre_cooling_temperature_nc = 0
; filament_preheat_temperature_delta = 0
; filament_prime_volume = 45
; filament_prime_volume_nc = 60
; filament_printable = 3
; filament_ramming_travel_time = 0
; filament_ramming_travel_time_nc = 0
; filament_ramming_volumetric_speed = -1
; filament_ramming_volumetric_speed_nc = -1
; filament_retract_length_nc = 10
; filament_scarf_gap = 0
; filament_scarf_height = 10%
; filament_scarf_length = 10
; filament_scarf_seam_type = none
; filament_self_index = 1
; filament_settings_id = "Generic PLA @BBL A1"
; filament_shrink = 100%
; filament_soluble = 0
; filament_start_gcode = " "
; filament_tower_interface_pre_extrusion_dist = 10
; filament_tower_interface_pre_extrusion_length = 0
; filament_tower_interface_print_temp = -1
; filament_tower_interface_purge_volume = 20
; filament_tower_ironing_area = 4
; filament_type = PLA
; filament_velocity_adaptation_factor = 1
; filament_vendor = (Undefined)
; filament_volume_map = 0
; filename_format = [input_filename_base].gcode
; fill_multiline = 1
; filter_out_gap_fill = 0
; first_layer_print_sequence = 0
; first_x_layer_fan_speed = 0
; first_x_layer_part_fan_speed = 0
; flush_into_infill = 0
; flush_into_objects = 0
; flush_into_support = 1
; flush_multiplier = 1
; flush_multiplier_fast = 1.2
; flush_volumes_matrix = 0,280,280,280,280,0,280,280,280,280,0,280,280,280,280,0
; flush_volumes_vector = 140,140,140,140,140,140,140,140
; full_fan_speed_layer = 0
; fuzzy_skin = none
; fuzzy_skin_first_layer = 0
; fuzzy_skin_mode = displacement
; fuzzy_skin_noise_type = classic
; fuzzy_skin_octaves = 4
; fuzzy_skin_persistence = 0.5
; fuzzy_skin_point_distance = 0.8
; fuzzy_skin_scale = 1
; fuzzy_skin_thickness = 0.3
; gap_infill_speed = 30
; gcode_add_line_number = 0
; gcode_flavor = marlin
; grab_length = 17.4
; group_algo_with_time = 0
; has_filament_switcher = 0
; has_scarf_joint_seam = 0
; head_wrap_detect_zone = 226x224,256x224,256x256,226x256
; hole_coef_1 = 0
; hole_coef_2 = -0.025
; hole_coef_3 = 0.28
; hole_limit_max = 0.25
; hole_limit_min = 0.08
; hot_plate_temp = 65
; hot_plate_temp_initial_layer = 65
; hotend_cooling_rate = 2
; hotend_heating_rate = 2
; impact_strength_z = 0
; independent_support_layer_height = 1
; infill_combination = 0
; infill_direction = 45
; infill_instead_top_bottom_surfaces = 0
; infill_jerk = 9
; infill_lock_depth = 1
; infill_rotate_step = 0
; infill_shift_step = 0.4
; infill_wall_overlap = 15%
; inherits_group = ;;
; initial_layer_acceleration = 300
; initial_layer_flow_ratio = 1
; initial_layer_infill_speed = 60
; initial_layer_jerk = 9
; initial_layer_line_width = 0.4
; initial_layer_print_height = 0.2
; initial_layer_speed = 30
; initial_layer_travel_acceleration = 500
; inner_wall_acceleration = 0
; inner_wall_jerk = 9
; inner_wall_line_width = 0.4
; inner_wall_speed = 60
; interface_shells = 0
; interlocking_beam = 0
; interlocking_beam_layer_count = 2
; interlocking_beam_width = 0.8
; interlocking_boundary_avoidance = 2
; interlocking_depth = 2
; interlocking_orientation = 22.5
; internal_bridge_support_thickness = 0
; internal_solid_infill_line_width = 0.4
; internal_solid_infill_pattern = zig-zag
; internal_solid_infill_speed = 100
; ironing_direction = 45
; ironing_fan_speed = -1
; ironing_flow = 10%
; ironing_inset = 0
; ironing_pattern = zig-zag
; ironing_spacing = 0.1
; ironing_speed = 20
; ironing_type = no ironing
; is_infill_first = 0
; layer_change_gcode = 
; layer_height = 0.2
; line_width = 0.4
; locked_skeleton_infill_pattern = zigzag
; locked_skin_infill_pattern = crosszag
; long_retractions_when_cut = 0
; long_retractions_when_ec = 0
; machine_bed_mass_Y = 0
; machine_end_gcode = M104 S0 ; turn off temperature\nG28 X0  ; home X axis\nM84     ; disable motors\n
; machine_hotend_change_time = 0
; machine_load_filament_time = 25
; machine_max_acceleration_e = 5000,5000
; machine_max_acceleration_extruding = 12000,12000
; machine_max_acceleration_retracting = 1500,1250
; machine_max_acceleration_travel = 1500,1250
; machine_max_acceleration_x = 6000,6000
; machine_max_acceleration_y = 6000,6000
; machine_max_acceleration_z = 1500,1500
; machine_max_force_Y = 0
; machine_max_jerk_e = 3,3
; machine_max_jerk_x = 10,10
; machine_max_jerk_y = 10,10
; machine_max_jerk_z = 0.2,0.4
; machine_max_printed_mass = 0
; machine_max_speed_e = 120,120
; machine_max_speed_x = 500,200
; machine_max_speed_y = 500,200
; machine_max_speed_z = 30,30
; machine_min_extruding_rate = 0,0
; machine_min_travel_rate = 0,0
; machine_pause_gcode = 
; machine_prepare_compensation_time = 260
; machine_start_gcode = G28 ; home all axes\nG1 Z5 F5000 ; lift nozzle\n
; machine_switch_extruder_time = 5
; machine_unload_filament_time = 0
; master_extruder_id = 1
; max_bridge_length = 10
; max_layer_height = 0
; max_travel_detour_distance = 0
; min_bead_width = 85%
; min_feature_size = 25%
; min_layer_height = 0.07
; minimum_sparse_infill_area = 15
; mmu_segmented_region_interlocking_depth = 0
; mmu_segmented_region_max_width = 0
; monotonic_travel_into_wall = 0%
; no_slow_down_for_cooling_on_outwalls = 0
; nozzle_diameter = 0.4
; nozzle_flush_dataset = 0
; nozzle_height = 4.76
; nozzle_temperature = 200
; nozzle_temperature_initial_layer = 200
; nozzle_temperature_range_high = 240
; nozzle_temperature_range_low = 190
; nozzle_type = stainless_steel
; nozzle_volume = 92
; nozzle_volume_type = Standard
; only_one_wall_first_layer = 0
; ooze_prevention = 0
; other_layers_print_sequence = 0
; other_layers_print_sequence_nums = 0
; outer_wall_acceleration = 500
; outer_wall_jerk = 9
; outer_wall_line_width = 0
; outer_wall_speed = 60
; overhang_1_4_speed = 0
; overhang_2_4_speed = 0
; overhang_3_4_speed = 0
; overhang_4_4_speed = 0
; overhang_fan_speed = 100
; overhang_fan_threshold = 95%
; overhang_threshold_participating_cooling = 95%
; overhang_totally_speed = 10
; override_filament_scarf_seam_setting = 0
; override_process_overhang_speed = 0
; physical_extruder_map = 0
; post_process = 
; pre_start_fan_time = 0
; precise_outer_wall = 0
; precise_z_height = 0
; pressure_advance = 0.02
; prime_tower_brim_width = 3
; prime_tower_enable_framework = 0
; prime_tower_extra_rib_length = 0
; prime_tower_fillet_wall = 1
; prime_tower_flat_ironing = 0
; prime_tower_infill_gap = 150%
; prime_tower_lift_height = -1
; prime_tower_lift_speed = 90
; prime_tower_max_speed = 90
; prime_tower_rib_wall = 1
; prime_tower_rib_width = 8
; prime_tower_skip_points = 1
; prime_tower_width = 35
; prime_volume_mode = Default
; print_compatible_printers = "Bambu Lab A1 0.4 nozzle"
; print_extruder_id = 1
; print_extruder_variant = "Direct Drive Standard"
; print_flow_ratio = 1
; print_in_clockwise = 0
; print_sequence = by layer
; print_settings_id = sup
; printable_area = 0x0,200x0,200x200,0x200
; printable_height = 256
; printer_extruder_id = 1
; printer_extruder_variant = "Direct Drive Standard"
; printer_model = Bambu Lab A1
; printer_notes = 
; printer_settings_id = Bambu Lab A1 0.4 nozzle
; printer_structure = i3
; printer_technology = FFF
; printer_variant = 0.4
; printing_by_object_gcode = 
; process_notes = 
; raft_contact_distance = 0.1
; raft_expansion = 1.5
; raft_first_layer_density = 90%
; raft_first_layer_expansion = -1
; raft_layers = 0
; reduce_crossing_wall = 0
; reduce_fan_stop_start_freq = 0
; reduce_infill_retraction_mode = Auto
; required_nozzle_HRC = 0
; resolution = 0.01
; retract_before_wipe = 100%
; retract_length_toolchange = 10
; retract_lift_above = 0
; retract_lift_below = 255
; retract_restart_extra = 0
; retract_restart_extra_toolchange = 0
; retract_when_changing_layer = 0
; retraction_distances_when_cut = 18
; retraction_distances_when_ec = 10
; retraction_length = 0.8
; retraction_minimum_travel = 2
; retraction_speed = 30
; role_base_wipe_speed = 1
; scan_first_layer = 0
; scarf_angle_threshold = 155
; seam_gap = 15%
; seam_placement_away_from_overhangs = 0
; seam_position = aligned
; seam_slope_conditional = 1
; seam_slope_entire_loop = 0
; seam_slope_gap = 0
; seam_slope_inner_walls = 1
; seam_slope_min_length = 10
; seam_slope_start_height = 10%
; seam_slope_steps = 10
; seam_slope_type = none
; silent_mode = 0
; single_extruder_multi_material = 0
; skeleton_infill_density = 15%
; skeleton_infill_line_width = 0.4
; skin_infill_density = 15%
; skin_infill_depth = 2
; skin_infill_line_width = 0.4
; skirt_distance = 2
; skirt_height = 1
; skirt_loops = 1
; skirt_per_object = 1
; slice_closing_radius = 0.049
; slicing_mode = regular
; slow_down_for_layer_cooling = 1
; slow_down_layer_time = 5
; slow_down_min_speed = 10
; slowdown_end_acc = 100000
; slowdown_end_height = 400
; slowdown_end_speed = 1000
; slowdown_start_acc = 100000
; slowdown_start_height = 0
; slowdown_start_speed = 1000
; small_perimeter_speed = 50%
; small_perimeter_threshold = 0
; smooth_coefficient = 80
; smooth_speed_discontinuity_area = 1
; solid_infill_filament = 0
; sparse_infill_acceleration = 100%
; sparse_infill_anchor = 400%
; sparse_infill_anchor_max = 20
; sparse_infill_density = 20%
; sparse_infill_filament = 0
; sparse_infill_lattice_angle_1 = -45
; sparse_infill_lattice_angle_2 = 45
; sparse_infill_line_width = 0.4
; sparse_infill_pattern = cubic
; sparse_infill_speed = 100
; spiral_mode = 0
; spiral_mode_max_xy_smoothing = 200%
; spiral_mode_smooth = 0
; standby_temperature_delta = -5
; start_end_points = 30x-3,54x245
; supertack_plate_temp = 35
; supertack_plate_temp_initial_layer = 35
; support_air_filtration = 0
; support_angle = 0
; support_base_pattern = default
; support_base_pattern_spacing = 2.5
; support_bottom_interface_spacing = 0.5
; support_bottom_z_distance = 0.2
; support_chamber_temp_control = 0
; support_cooling_filter = 0
; support_critical_regions_only = 0
; support_expansion = 0
; support_fast_purge_mode = 0
; support_filament = 0
; support_interface_bottom_layers = 0
; support_interface_filament = 0
; support_interface_loop_pattern = 0
; support_interface_not_for_body = 1
; support_interface_pattern = auto
; support_interface_spacing = 0.5
; support_interface_speed = 80
; support_interface_top_layers = 3
; support_ironing_direction = 0
; support_ironing_flow = 10%
; support_ironing_inset = 0
; support_ironing_pattern = zig-zag
; support_ironing_spacing = 0.1
; support_ironing_speed = 20
; support_line_width = 0.4
; support_object_first_layer_gap = 0.2
; support_object_skip_flush = 0
; support_object_xy_distance = 0.35
; support_on_build_plate_only = 1
; support_remove_small_overhang = 1
; support_speed = 80
; support_style = default
; support_threshold_angle = 30
; support_top_z_distance = 0.2
; support_type = normal(auto)
; symmetric_infill_y_axis = 0
; temperature_vitrification = 100
; template_custom_gcode = 
; textured_plate_temp = 65
; textured_plate_temp_initial_layer = 65
; thick_bridges = 0
; thumbnail_size = 50x50
; time_lapse_gcode = 
; timelapse_type = 0
; top_area_threshold = 200%
; top_color_penetration_layers = 4
; top_one_wall_type = all top
; top_shell_layers = 4
; top_shell_thickness = 0.6
; top_solid_infill_flow_ratio = 1
; top_surface_acceleration = 500
; top_surface_density = 100%
; top_surface_jerk = 9
; top_surface_line_width = 0.4
; top_surface_pattern = zig-zag
; top_surface_speed = 100
; top_z_overrides_xy_distance = 0
; travel_acceleration = 500
; travel_jerk = 9
; travel_short_distance_acceleration = 250
; travel_speed = 700
; travel_speed_z = 0
; tree_support_branch_angle = 40
; tree_support_branch_diameter = 5
; tree_support_branch_diameter_angle = 5
; tree_support_branch_distance = 5
; tree_support_wall_count = -1
; upward_compatible_machine = "Bambu Lab H2D 0.4 nozzle";"Bambu Lab H2D Pro 0.4 nozzle";"Bambu Lab H2S 0.4 nozzle";"Bambu Lab P2S 0.4 nozzle";"Bambu Lab H2C 0.4 nozzle";"Bambu Lab X2D 0.4 nozzle";"Bambu Lab A2L 0.4 nozzle"
; use_firmware_retraction = 0
; use_relative_e_distances = 1
; vertical_shell_speed = 80%
; volumetric_speed_coefficients = ""
; wall_distribution_count = 1
; wall_filament = 0
; wall_generator = arachne
; wall_loops = 2
; wall_sequence = inner wall/outer wall
; wall_transition_angle = 10
; wall_transition_filter_deviation = 25%
; wall_transition_length = 100%
; wipe = 0
; wipe_distance = 2
; wipe_speed = 80%
; wipe_tower_no_sparse_layers = 0
; wipe_tower_rotation_angle = 0
; wipe_tower_x = 15
; wipe_tower_y = 220
; wrapping_detection_gcode = 
; wrapping_detection_layers = 20
; wrapping_exclude_area = 
; xy_contour_compensation = 0
; xy_hole_compensation = 0
; z_direction_outwall_speed_continuous = 0
; z_hop = 0.4
; z_hop_types = Spiral Lift
; CONFIG_BLOCK_END

; EXECUTABLE_BLOCK_START
M73 P0 R32
M201 X6000 Y6000 Z1500 E5000
M203 X500 Y500 Z30 E120
M204 P12000 R1500 T12000
M205 X10.00 Y10.00 Z0.20 E3.00
M106 S0
M190 S35 ; set bed temperature and wait for it to be reached
M104 S200 ; set nozzle temperature
; FEATURE: Custom
G28 ; home all axes
G1 Z5 F5000 ; lift nozzle
; MACHINE_START_GCODE_END
;VT0 H-1
M109 S200 ; set nozzle temperature and wait for it to be reached
G90
G21
M83 ; use relative distances for extrusion
M981 S1 P20000 ;open spaghetti detector
; CHANGE_LAYER
; Z_HEIGHT: 0.2
; LAYER_HEIGHT: 0.2
M106 S0
G1 E-.8 F1800
G1 X81.789 Y87.949 F42000
M204 S500
G1 Z.4
G1 Z.2
G1 E.8 F1800
; FEATURE: Skirt
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S300
G1 X82.846 Y87.184 E.03874
G1 X83.536 Y87.072 E.02077
G1 X116.464 Y87.072 E.97767
G1 X117.709 Y87.463 E.03875
G1 X118.211 Y87.949 E.02077
G1 X121.747 Y92.699 E.17581
G1 X122.179 Y94 E.04069
G1 X122.179 Y106 E.3563
G1 X121.747 Y107.301 E.04069
G1 X118.211 Y112.051 E.17582
G1 X117.154 Y112.816 E.03875
G1 X116.464 Y112.928 E.02077
G1 X83.536 Y112.928 E.97767
G1 X82.291 Y112.537 E.03875
G1 X81.789 Y112.051 E.02077
G1 X78.253 Y107.301 E.17582
G1 X77.821 Y106 E.04069
G1 X77.821 Y94 E.3563
G1 X78.253 Y92.699 E.04069
G1 X81.753 Y87.997 E.17403
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.195 J1.201 P1  F42000
G1 X116.264 Y93.6 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Support
G1 F1680.297
M204 S300
G1 X113.834 Y93.6 E.07214
G1 X113.6 Y93.834 E.00984
G1 X113.6 Y106.166 E.36613
G1 X113.834 Y106.4 E.00984
G1 X116.264 Y106.4 E.07214
G1 X116.264 Y110.55 E.12321
G1 X83.736 Y110.55 E.96579
G1 X83.736 Y106.4 E.12321
G1 X86.166 Y106.4 E.07214
G1 X86.4 Y106.166 E.00984
G1 X86.4 Y93.834 E.36613
G1 X86.166 Y93.6 E.00984
G1 X83.736 Y93.6 E.07214
G1 X83.736 Y89.45 E.12321
G1 X116.264 Y89.45 E.96579
G1 X116.264 Y93.546 E.12162
M204 S500
G1 X97.334 Y93.6 F42000
G1 F1680.297
M204 S300
G1 X102.666 Y93.6 E.15829
G1 X102.9 Y93.834 E.00984
G1 X102.9 Y106.166 E.36613
G1 X102.666 Y106.4 E.00984
G1 X97.334 Y106.4 E.15829
G1 X97.1 Y106.166 E.00984
G1 X97.1 Y93.834 E.36613
G1 X97.296 Y93.638 E.00825
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.815 J.904 P1  F42000
G1 X115.87 Y110.389 Z.6
G1 Z.2
G1 E.8 F1800
G1 F1680.297
M204 S300
G1 X115.87 Y106.721 E.1089
G1 X115.473 Y106.721 E.01178
G1 X115.473 Y110.228 E.10413
G1 X115.077 Y110.228 E.01178
G1 X115.077 Y106.721 E.10413
G1 X114.68 Y106.721 E.01178
G1 X114.68 Y110.228 E.10413
G1 X114.283 Y110.228 E.01178
G1 X114.283 Y106.721 E.10413
G1 X113.886 Y106.721 E.01178
G1 X113.886 Y110.228 E.10413
G1 X113.49 Y110.228 E.01178
G1 X113.49 Y106.51 E.11041
G1 X113.279 Y106.299 E.00885
G1 X113.279 Y93.701 E.37404
G1 X113.49 Y93.49 E.00885
G1 X113.49 Y89.772 E.11041
G1 X113.886 Y89.772 E.01178
G1 X113.886 Y93.279 E.10413
G1 X114.283 Y93.279 E.01178
G1 X114.283 Y89.772 E.10413
G1 X114.68 Y89.772 E.01178
G1 X114.68 Y93.279 E.10413
G1 X115.077 Y93.279 E.01178
G1 X115.077 Y89.772 E.10413
G1 X115.473 Y89.772 E.01178
G1 X115.473 Y93.279 E.10413
G1 X115.87 Y93.279 E.01178
G1 X115.87 Y89.611 E.1089
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-1.206 J-.161 P1  F42000
G1 X113.093 Y110.389 Z.6
G1 Z.2
G1 E.8 F1800
G1 F1680.297
M204 S300
G1 X113.093 Y89.772 E.61216
G1 X112.696 Y89.772 E.01178
G1 X112.696 Y110.228 E.60739
G1 X112.299 Y110.228 E.01178
G1 X112.299 Y89.772 E.60739
G1 X111.903 Y89.772 E.01178
M73 P1 R32
G1 X111.903 Y110.228 E.60739
G1 X111.506 Y110.228 E.01178
G1 X111.506 Y89.772 E.60739
G1 X111.109 Y89.772 E.01178
G1 X111.109 Y110.228 E.60739
G1 X110.712 Y110.228 E.01178
G1 X110.712 Y89.772 E.60739
G1 X110.316 Y89.772 E.01178
G1 X110.316 Y110.228 E.60739
G1 X109.919 Y110.228 E.01178
G1 X109.919 Y89.772 E.60739
G1 X109.522 Y89.772 E.01178
G1 X109.522 Y110.228 E.60739
G1 X109.125 Y110.228 E.01178
G1 X109.125 Y89.772 E.60739
G1 X108.729 Y89.772 E.01178
G1 X108.729 Y110.228 E.60739
G1 X108.332 Y110.228 E.01178
G1 X108.332 Y89.772 E.60739
G1 X107.935 Y89.772 E.01178
G1 X107.935 Y110.228 E.60739
G1 X107.538 Y110.228 E.01178
G1 X107.538 Y89.772 E.60739
G1 X107.142 Y89.772 E.01178
G1 X107.142 Y110.228 E.60739
G1 X106.745 Y110.228 E.01178
G1 X106.745 Y89.772 E.60739
G1 X106.348 Y89.772 E.01178
G1 X106.348 Y110.228 E.60739
G1 X105.951 Y110.228 E.01178
G1 X105.951 Y89.772 E.60739
G1 X105.555 Y89.772 E.01178
G1 X105.555 Y110.228 E.60739
G1 X105.158 Y110.228 E.01178
G1 X105.158 Y89.772 E.60739
G1 X104.761 Y89.772 E.01178
G1 X104.761 Y110.228 E.60739
G1 X104.364 Y110.228 E.01178
M73 P1 R31
G1 X104.364 Y89.772 E.60739
G1 X103.968 Y89.772 E.01178
G1 X103.968 Y110.228 E.60739
G1 X103.571 Y110.228 E.01178
G1 X103.571 Y89.772 E.60739
G1 X103.174 Y89.772 E.01178
G1 X103.174 Y110.228 E.60739
G1 X102.777 Y110.228 E.01178
G1 X102.777 Y106.721 E.10413
G1 X102.381 Y106.721 E.01178
G1 X102.381 Y110.228 E.10413
G1 X101.984 Y110.228 E.01178
G1 X101.984 Y106.721 E.10413
G1 X101.587 Y106.721 E.01178
G1 X101.587 Y110.228 E.10413
G1 X101.19 Y110.228 E.01178
G1 X101.19 Y106.721 E.10413
G1 X100.794 Y106.721 E.01178
G1 X100.794 Y110.228 E.10413
G1 X100.397 Y110.228 E.01178
M73 P2 R31
G1 X100.397 Y106.721 E.10413
G1 X100 Y106.721 E.01178
G1 X100 Y110.228 E.10413
G1 X99.603 Y110.228 E.01178
G1 X99.603 Y106.721 E.10413
G1 X99.207 Y106.721 E.01178
G1 X99.207 Y110.228 E.10413
G1 X98.81 Y110.228 E.01178
G1 X98.81 Y106.721 E.10413
G1 X98.413 Y106.721 E.01178
G1 X98.413 Y110.228 E.10413
G1 X98.016 Y110.228 E.01178
G1 X98.016 Y106.721 E.10413
G1 X97.62 Y106.721 E.01178
G1 X97.62 Y110.228 E.10413
G1 X97.223 Y110.228 E.01178
G1 X97.223 Y106.516 E.11024
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I1.12 J.477 P1  F42000
G1 X102.777 Y93.484 Z.6
G1 Z.2
G1 E.8 F1800
G1 F1680.297
M204 S300
G1 X102.777 Y89.772 E.11023
G1 X102.381 Y89.772 E.01178
G1 X102.381 Y93.279 E.10413
G1 X101.984 Y93.279 E.01178
G1 X101.984 Y89.772 E.10413
G1 X101.587 Y89.772 E.01178
G1 X101.587 Y93.279 E.10413
G1 X101.19 Y93.279 E.01178
G1 X101.19 Y89.772 E.10413
G1 X100.794 Y89.772 E.01178
G1 X100.794 Y93.279 E.10413
G1 X100.397 Y93.279 E.01178
G1 X100.397 Y89.772 E.10413
G1 X100 Y89.772 E.01178
G1 X100 Y93.279 E.10413
G1 X99.603 Y93.279 E.01178
G1 X99.603 Y89.772 E.10413
G1 X99.207 Y89.772 E.01178
G1 X99.207 Y93.279 E.10413
G1 X98.81 Y93.279 E.01178
G1 X98.81 Y89.772 E.10413
G1 X98.413 Y89.772 E.01178
G1 X98.413 Y93.279 E.10413
G1 X98.016 Y93.279 E.01178
G1 X98.016 Y89.772 E.10413
G1 X97.62 Y89.772 E.01178
G1 X97.62 Y93.279 E.10413
G1 X97.223 Y93.279 E.01178
G1 X97.223 Y89.772 E.10413
G1 X96.826 Y89.772 E.01178
G1 X96.826 Y110.228 E.60739
G1 X96.429 Y110.228 E.01178
G1 X96.429 Y89.772 E.60739
G1 X96.033 Y89.772 E.01178
G1 X96.033 Y110.228 E.60739
G1 X95.636 Y110.228 E.01178
G1 X95.636 Y89.772 E.60739
G1 X95.239 Y89.772 E.01178
G1 X95.239 Y110.228 E.60739
G1 X94.842 Y110.228 E.01178
G1 X94.842 Y89.772 E.60739
G1 X94.446 Y89.772 E.01178
G1 X94.446 Y110.228 E.60739
G1 X94.049 Y110.228 E.01178
G1 X94.049 Y89.772 E.60739
G1 X93.652 Y89.772 E.01178
G1 X93.652 Y110.228 E.60739
G1 X93.255 Y110.228 E.01178
G1 X93.255 Y89.772 E.60739
G1 X92.859 Y89.772 E.01178
G1 X92.859 Y110.228 E.60739
G1 X92.462 Y110.228 E.01178
G1 X92.462 Y89.772 E.60739
G1 X92.065 Y89.772 E.01178
G1 X92.065 Y110.228 E.60739
G1 X91.668 Y110.228 E.01178
G1 X91.668 Y89.772 E.60739
G1 X91.272 Y89.772 E.01178
G1 X91.272 Y110.228 E.60739
G1 X90.875 Y110.228 E.01178
G1 X90.875 Y89.772 E.60739
G1 X90.478 Y89.772 E.01178
G1 X90.478 Y110.228 E.60739
G1 X90.081 Y110.228 E.01178
G1 X90.081 Y89.772 E.60739
G1 X89.685 Y89.772 E.01178
M73 P3 R31
G1 X89.685 Y110.228 E.60739
G1 X89.288 Y110.228 E.01178
G1 X89.288 Y89.772 E.60739
G1 X88.891 Y89.772 E.01178
G1 X88.891 Y110.228 E.60739
G1 X88.494 Y110.228 E.01178
G1 X88.494 Y89.772 E.60739
G1 X88.098 Y89.772 E.01178
G1 X88.098 Y110.228 E.60739
G1 X87.701 Y110.228 E.01178
G1 X87.701 Y89.772 E.60739
G1 X87.304 Y89.772 E.01178
G1 X87.304 Y110.228 E.60739
G1 X86.907 Y110.228 E.01178
G1 X86.907 Y89.772 E.60739
G1 X86.511 Y89.772 E.01178
G1 X86.511 Y93.49 E.11041
G1 X86.299 Y93.279 E.00889
G1 X86.114 Y93.279 E.00549
G1 X86.114 Y89.772 E.10413
G1 X85.717 Y89.772 E.01178
G1 X85.717 Y93.279 E.10413
G1 X85.32 Y93.279 E.01178
G1 X85.32 Y89.772 E.10413
G1 X84.924 Y89.772 E.01178
G1 X84.924 Y93.279 E.10413
G1 X84.527 Y93.279 E.01178
G1 X84.527 Y89.772 E.10413
G1 X84.13 Y89.772 E.01178
G1 X84.13 Y93.439 E.1089
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-1.205 J.169 P1  F42000
G1 X86.511 Y110.389 Z.6
G1 Z.2
G1 E.8 F1800
G1 F1680.297
M204 S300
G1 X86.511 Y106.51 E.11518
G1 X86.299 Y106.721 E.00889
G1 X86.114 Y106.721 E.00549
G1 X86.114 Y110.228 E.10413
G1 X85.717 Y110.228 E.01178
G1 X85.717 Y106.721 E.10413
G1 X85.32 Y106.721 E.01178
G1 X85.32 Y110.228 E.10413
G1 X84.924 Y110.228 E.01178
G1 X84.924 Y106.721 E.10413
G1 X84.527 Y106.721 E.01178
G1 X84.527 Y110.228 E.10413
G1 X84.13 Y110.228 E.01178
G1 X84.13 Y106.561 E.1089
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I.048 J1.216 P1  F42000
G1 X114.632 Y105.368 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S300
G1 X114.632 Y94.632 E.31875
G1 X119.368 Y94.632 E.14061
G1 X119.368 Y97 E.07031
G1 X119.368 Y105.368 E.24845
G1 X114.692 Y105.368 E.13883
M204 S500
G1 X114.275 Y105.725 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S300
G1 X114.275 Y94.275 E.33996
G1 X119.725 Y94.275 E.16181
G1 X119.725 Y97 E.08091
G1 X119.725 Y105.725 E.25905
G1 X114.335 Y105.725 E.16003
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I1.217 J0 P1  F42000
G1 X114.775 Y104.486
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.40798
G1 F1643.565
M204 S300
G1 X115.353 Y105.065 E.02483
G1 X115.869 Y105.065 E.01567
G1 X114.936 Y104.131 E.04009
G1 X114.936 Y103.614 E.01567
G1 X116.386 Y105.065 E.06225
G1 X116.902 Y105.065 E.01567
G1 X114.936 Y103.098 E.08442
G1 X114.936 Y102.582 E.01567
G1 X117.418 Y105.065 E.10658
G1 X117.934 Y105.065 E.01567
G1 X114.936 Y102.066 E.12874
G1 X114.936 Y101.549 E.01567
G1 X118.451 Y105.065 E.1509
G1 X118.967 Y105.065 E.01567
G1 X114.936 Y101.033 E.17307
G1 X114.936 Y100.517 E.01567
G1 X119.065 Y104.646 E.17725
G1 X119.065 Y104.13 E.01567
G1 X114.936 Y100 E.17725
G1 X114.936 Y99.484 E.01567
G1 X119.065 Y103.613 E.17725
G1 X119.065 Y103.097 E.01567
G1 X114.936 Y98.968 E.17725
G1 X114.936 Y98.452 E.01567
G1 X119.065 Y102.581 E.17725
G1 X119.065 Y102.064 E.01567
G1 X114.936 Y97.935 E.17725
G1 X114.936 Y97.419 E.01567
G1 X119.065 Y101.548 E.17725
G1 X119.065 Y101.032 E.01567
G1 X114.936 Y96.903 E.17725
G1 X114.936 Y96.387 E.01567
G1 X119.065 Y100.516 E.17725
G1 X119.065 Y99.999 E.01567
G1 X114.936 Y95.87 E.17725
G1 X114.936 Y95.354 E.01567
G1 X119.065 Y99.483 E.17725
G1 X119.065 Y98.967 E.01567
G1 X115.033 Y94.935 E.17306
G1 X115.549 Y94.935 E.01567
G1 X119.065 Y98.451 E.1509
G1 X119.065 Y97.934 E.01567
G1 X116.066 Y94.935 E.12873
G1 X116.582 Y94.935 E.01567
G1 X119.065 Y97.418 E.10657
G1 X119.065 Y96.902 E.01567
M73 P4 R31
G1 X117.098 Y94.935 E.08441
G1 X117.615 Y94.935 E.01567
G1 X119.065 Y96.385 E.06224
G1 X119.065 Y95.869 E.01567
G1 X118.131 Y94.935 E.04008
G1 X118.647 Y94.935 E.01567
G1 X119.225 Y95.514 E.02482
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.515 J-1.103 P1  F42000
G1 X98.132 Y105.368 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S300
G1 X98.132 Y94.632 E.31875
G1 X101.868 Y94.632 E.11092
G1 X101.868 Y96.5 E.05546
G1 X101.868 Y105.368 E.26329
G1 X98.192 Y105.368 E.10914
M204 S500
G1 X97.775 Y105.725 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S300
G1 X97.775 Y94.275 E.33996
G1 X102.225 Y94.275 E.13212
G1 X102.225 Y96.5 E.06606
G1 X102.225 Y105.725 E.2739
G1 X97.835 Y105.725 E.13034
M204 S500
G1 X98.275 Y104.485 F42000
; FEATURE: Bottom surface
; LINE_WIDTH: 0.40884
G1 F1639.703
M204 S300
G1 X98.855 Y105.065 E.02495
G1 X99.372 Y105.065 E.01575
G1 X98.435 Y104.128 E.0403
G1 X98.435 Y103.61 E.01575
G1 X99.89 Y105.065 E.06257
G1 X100.407 Y105.065 E.01575
G1 X98.435 Y103.093 E.08484
G1 X98.435 Y102.575 E.01575
G1 X100.925 Y105.065 E.10711
G1 X101.442 Y105.065 E.01575
G1 X98.435 Y102.058 E.12937
G1 X98.435 Y101.54 E.01575
G1 X101.565 Y104.67 E.13464
G1 X101.565 Y104.152 E.01575
G1 X98.435 Y101.023 E.13464
G1 X98.435 Y100.505 E.01575
G1 X101.565 Y103.635 E.13464
G1 X101.565 Y103.117 E.01575
G1 X98.435 Y99.988 E.13464
G1 X98.435 Y99.47 E.01575
G1 X101.565 Y102.6 E.13464
G1 X101.565 Y102.082 E.01575
G1 X98.435 Y98.953 E.13464
G1 X98.435 Y98.436 E.01575
G1 X101.565 Y101.565 E.13464
G1 X101.565 Y101.047 E.01575
G1 X98.435 Y97.918 E.13464
G1 X98.435 Y97.401 E.01575
G1 X101.565 Y100.53 E.13464
G1 X101.565 Y100.012 E.01575
G1 X98.435 Y96.883 E.13464
G1 X98.435 Y96.366 E.01575
G1 X101.565 Y99.495 E.13464
G1 X101.565 Y98.977 E.01575
G1 X98.435 Y95.848 E.13464
G1 X98.435 Y95.331 E.01575
G1 X101.565 Y98.46 E.13464
G1 X101.565 Y97.942 E.01575
G1 X98.558 Y94.935 E.12938
G1 X99.075 Y94.935 E.01575
G1 X101.565 Y97.425 E.10711
G1 X101.565 Y96.907 E.01575
G1 X99.593 Y94.935 E.08484
G1 X100.11 Y94.935 E.01575
G1 X101.565 Y96.39 E.06257
G1 X101.565 Y95.872 E.01575
G1 X100.628 Y94.935 E.04031
G1 X101.145 Y94.935 E.01575
G1 X101.725 Y95.515 E.02495
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.628 J-1.042 P1  F42000
G1 X85.368 Y105.368 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S300
G1 X80.632 Y105.368 E.14061
G1 X80.632 Y94.632 E.31875
G1 X85.368 Y94.632 E.14061
G1 X85.368 Y97 E.07031
G1 X85.368 Y105.308 E.24667
M204 S500
G1 X85.725 Y105.725 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S300
G1 X80.275 Y105.725 E.16181
G1 X80.275 Y94.275 E.33996
G1 X85.725 Y94.275 E.16181
G1 X85.725 Y97 E.08091
G1 X85.725 Y105.665 E.25727
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I.282 J-1.184 P1  F42000
G1 X80.775 Y104.486 Z.6
G1 Z.2
G1 E.8 F1800
; FEATURE: Bottom surface
; LINE_WIDTH: 0.40798
G1 F1643.565
M204 S300
G1 X81.353 Y105.065 E.02483
G1 X81.869 Y105.065 E.01567
G1 X80.935 Y104.131 E.04009
G1 X80.935 Y103.614 E.01567
G1 X82.386 Y105.065 E.06225
G1 X82.902 Y105.065 E.01567
G1 X80.935 Y103.098 E.08442
G1 X80.935 Y102.582 E.01567
G1 X83.418 Y105.065 E.10658
G1 X83.934 Y105.065 E.01567
G1 X80.935 Y102.066 E.12874
G1 X80.935 Y101.549 E.01567
G1 X84.451 Y105.065 E.1509
G1 X84.967 Y105.065 E.01567
G1 X80.935 Y101.033 E.17307
G1 X80.935 Y100.517 E.01567
G1 X85.065 Y104.646 E.17725
G1 X85.065 Y104.13 E.01567
G1 X80.935 Y100 E.17725
G1 X80.935 Y99.484 E.01567
G1 X85.065 Y103.613 E.17725
G1 X85.065 Y103.097 E.01567
G1 X80.935 Y98.968 E.17725
G1 X80.935 Y98.452 E.01567
G1 X85.065 Y102.581 E.17725
G1 X85.065 Y102.064 E.01567
G1 X80.935 Y97.935 E.17725
G1 X80.935 Y97.419 E.01567
G1 X85.065 Y101.548 E.17725
G1 X85.065 Y101.032 E.01567
G1 X80.935 Y96.903 E.17725
G1 X80.935 Y96.387 E.01567
G1 X85.065 Y100.516 E.17725
G1 X85.065 Y99.999 E.01567
M73 P4 R30
G1 X80.935 Y95.87 E.17725
G1 X80.935 Y95.354 E.01567
G1 X85.065 Y99.483 E.17725
G1 X85.065 Y98.967 E.01567
G1 X81.033 Y94.935 E.17306
G1 X81.549 Y94.935 E.01567
G1 X85.065 Y98.451 E.1509
G1 X85.065 Y97.934 E.01567
G1 X82.066 Y94.935 E.12873
G1 X82.582 Y94.935 E.01567
G1 X85.065 Y97.418 E.10657
G1 X85.065 Y96.902 E.01567
G1 X83.098 Y94.935 E.08441
G1 X83.615 Y94.935 E.01567
G1 X85.065 Y96.385 E.06224
G1 X85.065 Y95.869 E.01567
G1 X84.131 Y94.935 E.04008
G1 X84.647 Y94.935 E.01567
G1 X85.225 Y95.514 E.02482
; CHANGE_LAYER
; Z_HEIGHT: 0.4
; LAYER_HEIGHT: 0.2
M106 S191.25
; open powerlost recovery
M1003 S1
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.6 I-.39 J1.153 P1  F42000
G1 X114.557 Y105.443 Z.6
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
M73 P5 R30
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z.8 I1.217 J0 P1  F42000
G1 X116.76 Y103.24
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.52197
G1 F1252.479
M204 S6000
G1 X117.24 Y103.24 E.01908
G1 X117.24 Y96.76 E.25808
G1 X116.76 Y96.76 E.01908
G1 X116.76 Y103.18 E.25569
M204 S500
G1 X116.342 Y103.658 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X117.658 Y103.658 E.03905
G1 X117.658 Y96.342 E.21719
G1 X116.342 Y96.342 E.03905
G1 X116.342 Y103.598 E.21541
M204 S500
G1 X115.985 Y104.015 F42000
G1 F1680.343
M204 S6000
G1 X118.015 Y104.015 E.06025
G1 X118.015 Y95.985 E.2384
G1 X115.985 Y95.985 E.06025
G1 X115.985 Y103.955 E.23661
M204 S500
G1 X115.628 Y104.372 F42000
G1 F1680.343
M204 S6000
G1 X118.372 Y104.372 E.08145
G1 X118.372 Y95.628 E.2596
G1 X115.628 Y95.628 E.08145
G1 X115.628 Y104.312 E.25782
M204 S500
G1 X115.271 Y104.729 F42000
G1 F1680.343
M204 S6000
G1 X118.729 Y104.729 E.10266
G1 X118.729 Y95.271 E.2808
G1 X115.271 Y95.271 E.10266
G1 X115.271 Y104.669 E.27902
M204 S500
G1 X114.914 Y105.086 F42000
G1 F1680.343
M204 S6000
G1 X119.086 Y105.086 E.12386
G1 X119.086 Y94.914 E.302
G1 X114.914 Y94.914 E.12386
G1 X114.914 Y105.026 E.30022
G1 E-.8 F1800
M204 S500
G17
G3 Z.8 I-.03 J-1.217 P1  F42000
G1 X98.057 Y105.443 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z.8 I1.178 J.305 P1  F42000
G1 X100.168 Y96.5 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.37905
G1 F1785.024
M204 S6000
G1 X100.168 Y96.332 E.0047
G1 X99.832 Y96.332 E.00939
G1 X99.832 Y103.668 E.20504
G1 X100.168 Y103.668 E.00939
G1 X100.168 Y96.56 E.19867
M204 S500
G1 X100.515 Y96.5 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.515 Y95.985 E.01528
G1 X99.485 Y95.985 E.03056
G1 X99.485 Y104.015 E.2384
G1 X100.515 Y104.015 E.03056
G1 X100.515 Y96.56 E.22133
M204 S500
G1 X100.872 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X100.872 Y95.628 E.02588
G1 X99.128 Y95.628 E.05176
G1 X99.128 Y104.372 E.2596
G1 X100.872 Y104.372 E.05176
G1 X100.872 Y96.56 E.23193
M204 S500
G1 X101.229 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.229 Y95.271 E.03648
G1 X98.771 Y95.271 E.07297
G1 X98.771 Y104.729 E.2808
G1 X101.229 Y104.729 E.07297
G1 X101.229 Y96.56 E.24254
M204 S500
G1 X101.586 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.586 Y94.914 E.04709
G1 X98.414 Y94.914 E.09417
G1 X98.414 Y105.086 E.302
G1 X101.586 Y105.086 E.09417
G1 X101.586 Y96.56 E.25314
G1 E-.8 F1800
M204 S500
G17
G3 Z.8 I-.587 J-1.066 P1  F42000
G1 X85.443 Y105.443 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z.8 I1.168 J-.342 P1  F42000
G1 X83.24 Y97 Z.8
G1 Z.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.52198
G1 F1252.453
M204 S6000
G1 X83.24 Y96.76 E.00954
G1 X82.76 Y96.76 E.01908
G1 X82.76 Y103.24 E.25809
G1 X83.24 Y103.24 E.01908
G1 X83.24 Y97.06 E.24616
M204 S500
G1 X83.658 Y97 F42000
; LINE_WIDTH: 0.39999
M73 P6 R30
G1 F1680.343
M204 S6000
G1 X83.658 Y96.342 E.01952
G1 X82.342 Y96.342 E.03905
G1 X82.342 Y103.658 E.21719
G1 X83.658 Y103.658 E.03905
G1 X83.658 Y97.06 E.19589
M204 S500
G1 X84.015 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.015 Y95.985 E.03013
G1 X81.985 Y95.985 E.06025
G1 X81.985 Y104.015 E.2384
G1 X84.015 Y104.015 E.06025
G1 X84.015 Y97.06 E.20649
M204 S500
G1 X84.372 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.372 Y95.628 E.04073
G1 X81.628 Y95.628 E.08145
G1 X81.628 Y104.372 E.2596
G1 X84.372 Y104.372 E.08145
G1 X84.372 Y97.06 E.21709
M204 S500
G1 X84.729 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.729 Y95.271 E.05133
G1 X81.271 Y95.271 E.10266
G1 X81.271 Y104.729 E.2808
G1 X84.729 Y104.729 E.10266
G1 X84.729 Y97.06 E.22769
M204 S500
G1 X85.086 Y97 F42000
G1 F1680.343
M204 S6000
G1 X85.086 Y94.914 E.06193
G1 X80.914 Y94.914 E.12386
G1 X80.914 Y105.086 E.302
G1 X85.086 Y105.086 E.12386
G1 X85.086 Y97.06 E.23829
; CHANGE_LAYER
; Z_HEIGHT: 0.494444
; LAYER_HEIGHT: 0.0944444
M106 S183.6
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z.8 I1.209 J.135 P1  F42000
G1 X85.715 Y91.429 Z.8
G1 Z.494
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.4
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z.894 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z.894
G1 Z.494
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 0.6
; LAYER_HEIGHT: 0.105556
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z.894
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z1 I1.217 J0 P1  F42000
G1 X116.76 Y103.24
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.52197
G1 F1252.479
M204 S6000
G1 X117.24 Y103.24 E.01908
G1 X117.24 Y96.76 E.25808
G1 X116.76 Y96.76 E.01908
M73 P7 R30
G1 X116.76 Y103.18 E.25569
M204 S500
G1 X116.342 Y103.658 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X117.658 Y103.658 E.03905
G1 X117.658 Y96.342 E.21719
G1 X116.342 Y96.342 E.03905
G1 X116.342 Y103.598 E.21541
M204 S500
G1 X115.985 Y104.015 F42000
G1 F1680.343
M204 S6000
G1 X118.015 Y104.015 E.06025
G1 X118.015 Y95.985 E.2384
G1 X115.985 Y95.985 E.06025
G1 X115.985 Y103.955 E.23661
M204 S500
G1 X115.628 Y104.372 F42000
G1 F1680.343
M204 S6000
G1 X118.372 Y104.372 E.08145
G1 X118.372 Y95.628 E.2596
G1 X115.628 Y95.628 E.08145
G1 X115.628 Y104.312 E.25782
M204 S500
G1 X115.271 Y104.729 F42000
G1 F1680.343
M204 S6000
G1 X118.729 Y104.729 E.10266
G1 X118.729 Y95.271 E.2808
G1 X115.271 Y95.271 E.10266
G1 X115.271 Y104.669 E.27902
M204 S500
G1 X114.914 Y105.086 F42000
G1 F1680.343
M204 S6000
G1 X119.086 Y105.086 E.12386
G1 X119.086 Y94.914 E.302
G1 X114.914 Y94.914 E.12386
G1 X114.914 Y105.026 E.30022
G1 E-.8 F1800
M204 S500
G17
G3 Z1 I-.03 J-1.217 P1  F42000
G1 X98.057 Y105.443 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z1 I1.178 J.305 P1  F42000
G1 X100.168 Y96.5 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.37905
G1 F1785.024
M204 S6000
G1 X100.168 Y96.332 E.0047
G1 X99.832 Y96.332 E.00939
G1 X99.832 Y103.668 E.20504
G1 X100.168 Y103.668 E.00939
G1 X100.168 Y96.56 E.19867
M204 S500
G1 X100.515 Y96.5 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.515 Y95.985 E.01528
G1 X99.485 Y95.985 E.03056
G1 X99.485 Y104.015 E.2384
G1 X100.515 Y104.015 E.03056
G1 X100.515 Y96.56 E.22133
M204 S500
G1 X100.872 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X100.872 Y95.628 E.02588
G1 X99.128 Y95.628 E.05176
G1 X99.128 Y104.372 E.2596
G1 X100.872 Y104.372 E.05176
G1 X100.872 Y96.56 E.23193
M204 S500
G1 X101.229 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.229 Y95.271 E.03648
G1 X98.771 Y95.271 E.07297
G1 X98.771 Y104.729 E.2808
G1 X101.229 Y104.729 E.07297
G1 X101.229 Y96.56 E.24254
M204 S500
G1 X101.586 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.586 Y94.914 E.04709
G1 X98.414 Y94.914 E.09417
G1 X98.414 Y105.086 E.302
G1 X101.586 Y105.086 E.09417
G1 X101.586 Y96.56 E.25314
G1 E-.8 F1800
M204 S500
G17
G3 Z1 I-.587 J-1.066 P1  F42000
G1 X85.443 Y105.443 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z1 I1.168 J-.342 P1  F42000
G1 X83.24 Y97 Z1
G1 Z.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.52198
G1 F1252.453
M204 S6000
G1 X83.24 Y96.76 E.00954
G1 X82.76 Y96.76 E.01908
G1 X82.76 Y103.24 E.25809
G1 X83.24 Y103.24 E.01908
G1 X83.24 Y97.06 E.24616
M204 S500
G1 X83.658 Y97 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X83.658 Y96.342 E.01952
G1 X82.342 Y96.342 E.03905
G1 X82.342 Y103.658 E.21719
G1 X83.658 Y103.658 E.03905
G1 X83.658 Y97.06 E.19589
M204 S500
G1 X84.015 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.015 Y95.985 E.03013
G1 X81.985 Y95.985 E.06025
G1 X81.985 Y104.015 E.2384
G1 X84.015 Y104.015 E.06025
M73 P7 R29
G1 X84.015 Y97.06 E.20649
M204 S500
G1 X84.372 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.372 Y95.628 E.04073
G1 X81.628 Y95.628 E.08145
G1 X81.628 Y104.372 E.2596
G1 X84.372 Y104.372 E.08145
G1 X84.372 Y97.06 E.21709
M204 S500
G1 X84.729 Y97 F42000
G1 F1680.343
M204 S6000
G1 X84.729 Y95.271 E.05133
G1 X81.271 Y95.271 E.10266
G1 X81.271 Y104.729 E.2808
G1 X84.729 Y104.729 E.10266
M73 P8 R29
G1 X84.729 Y97.06 E.22769
M204 S500
G1 X85.086 Y97 F42000
G1 F1680.343
M204 S6000
G1 X85.086 Y94.914 E.06193
G1 X80.914 Y94.914 E.12386
G1 X80.914 Y105.086 E.302
G1 X85.086 Y105.086 E.12386
G1 X85.086 Y97.06 E.23829
; CHANGE_LAYER
; Z_HEIGHT: 0.788889
; LAYER_HEIGHT: 0.188889
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1 I1.209 J.135 P1  F42000
G1 X85.715 Y91.429 Z1
G1 Z.789
G1 E.8 F1800
; FEATURE: Support
; LINE_WIDTH: 0.4
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z1.189 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z1.189
G1 Z.789
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 0.8
; LAYER_HEIGHT: 0.0111111
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z1.189
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z1.2 I1.217 J0 P1  F42000
G1 X115.588 Y105.14
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.02159
G1 X114.86 Y104.438 E.02082
G1 X117.427 Y94.86 E.29442
G1 X118.385 Y94.86 E.02844
G1 X119.14 Y95.615 E.03169
G1 X119.14 Y95.457 E.00469
G1 X114.86 Y96.604 E.13153
G1 X114.86 Y98.911 E.0685
G1 X119.14 Y103.19 E.17968
G1 X119.14 Y101.002 E.06495
G1 X114.86 Y102.149 E.13153
G1 X114.86 Y100.721 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z1.2 I-.329 J-1.172 P1  F42000
G1 X98.057 Y105.443 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
M73 P9 R29
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 X98.582 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X98.36 Y105.14 E.00659
G1 X98.36 Y103.933 E.03582
G1 X100.792 Y94.86 E.27888
G1 X100.672 Y94.86 E.00355
G1 X98.36 Y95.48 E.07105
G1 X98.36 Y97.56 E.06178
G1 X101.64 Y100.84 E.13769
G1 X101.64 Y100.146 E.02058
G1 X98.36 Y101.025 E.10079
G1 X98.36 Y99.597 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z1.2 I-.502 J-1.109 P1  F42000
G1 X85.443 Y105.443 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.2 I1.18 J-.3 P1  F42000
G1 X85.14 Y103.139 Z1.2
G1 Z.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.567 E.04241
G1 X83.005 Y105.14 E.06563
G1 X83.215 Y105.14 E.00625
G1 X80.86 Y102.785 E.09887
G1 X80.86 Y100.169 E.07767
G1 X85.14 Y99.022 E.13153
G1 X85.14 Y99.489 E.01386
G1 X80.86 Y95.21 E.17968
G1 X80.86 Y94.86 E.01038
G1 X84.156 Y94.86 E.09785
G1 X81.402 Y105.14 E.31597
G1 X80.86 Y105.14 E.01607
G1 X80.86 Y104.253 E.02634
; CHANGE_LAYER
; Z_HEIGHT: 1
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.2 I-.043 J1.216 P1  F42000
G1 X114.557 Y105.443 Z1.2
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z1.4 I1.217 J0 P1  F42000
G1 X115.041 Y105.14
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.00537
G1 X114.86 Y103.892 E.03704
G1 X117.281 Y94.86 E.27762
G1 X118.585 Y94.86 E.03873
G1 X119.14 Y95.415 E.02329
G1 X119.14 Y95.604 E.0056
G1 X114.86 Y96.75 E.13153
G1 X114.86 Y98.711 E.05822
G1 X119.14 Y102.99 E.17968
G1 X119.14 Y101.149 E.05467
G1 X114.86 Y102.295 E.13153
G1 X114.86 Y100.867 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z1.4 I-.32 J-1.174 P1  F42000
G1 X98.057 Y105.443 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z1.4 I.345 J1.167 P1  F42000
G1 X99.993 Y105.14 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X98.565 Y105.14 E.04241
G1 X98.36 Y104.935 E.00858
G1 X98.36 Y103.387 E.04598
G1 X100.645 Y94.86 E.26209
M204 S500
G1 X101.64 Y95.868 F42000
G1 F1680.297
M204 S6000
G1 X101.64 Y94.86 E.0299
G1 X101.218 Y94.86 E.01251
G1 X98.36 Y95.626 E.08785
G1 X98.36 Y97.36 E.05149
G1 X101.64 Y100.64 E.13769
G1 X101.64 Y100.293 E.0103
G1 X98.36 Y101.171 E.10079
G1 X98.36 Y99.743 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z1.4 I-.491 J-1.113 P1  F42000
G1 X85.443 Y105.443 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
M73 P10 R29
G1 E-.8 F1800
G17
G3 Z1.4 I1.175 J-.316 P1  F42000
G1 X85.14 Y103.286 Z1.4
G1 Z1
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.714 E.04241
G1 X83.551 Y105.14 E.04883
G1 X83.415 Y105.14 E.00403
G1 X80.86 Y102.585 E.10727
G1 X80.86 Y100.315 E.06739
G1 X85.14 Y99.169 E.13153
G1 X85.14 Y99.289 E.00357
G1 X80.86 Y95.01 E.17968
G1 X80.86 Y94.86 E.00444
G1 X84.01 Y94.86 E.0935
G1 X81.255 Y105.14 E.31597
G1 X80.86 Y105.14 E.01173
G1 X80.86 Y104.106 E.03068
; CHANGE_LAYER
; Z_HEIGHT: 1.08333
; LAYER_HEIGHT: 0.0833334
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.4 I1.137 J.435 P1  F42000
G1 X85.715 Y91.429 Z1.4
G1 Z1.083
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z1.483 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z1.483
G1 Z1.083
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 1.2
; LAYER_HEIGHT: 0.116667
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z1.483
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z1.6 I1.217 J0 P1  F42000
G1 X114.861 Y104.774
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y103.345 E.04241
G1 X117.134 Y94.861 E.26081
G1 X118.785 Y94.861 E.04902
G1 X119.139 Y95.215 E.01489
G1 X119.139 Y95.75 E.01588
G1 X114.861 Y96.897 E.13153
G1 X114.861 Y98.511 E.04793
G1 X119.139 Y102.79 E.17967
G1 X119.139 Y101.295 E.04438
G1 X114.861 Y102.442 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z1.6 I-.214 J-1.198 P1  F42000
G1 X98.057 Y105.443 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
M73 P10 R28
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
M73 P11 R28
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z1.6 I1.205 J.168 P1  F42000
G1 X98.718 Y98.946 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X98.718 Y97.518 E.04241
G1 X101.282 Y100.082 E.10768
G1 X101.282 Y100.535 E.01344
G1 X98.718 Y101.222 E.07883
G1 X98.718 Y101.507 E.00846
G1 X100.403 Y95.218 E.19333
G1 X100.431 Y95.218 E.00084
G1 X98.718 Y95.677 E.05268
G1 X98.718 Y97.105 E.04241
M204 S500
G1 X101.613 Y95.039 F42000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383223
G1 F1763.137
M204 S6000
G1 X101.587 Y94.913 E.00363
G1 X101.461 Y94.887 E.00363
G1 X98.539 Y94.887 E.08267
G1 X98.413 Y94.913 E.00363
G1 X98.387 Y95.039 E.00363
G1 X98.387 Y104.961 E.28074
G1 X98.413 Y105.087 E.00363
G1 X98.539 Y105.113 E.00363
G1 X101.461 Y105.113 E.08267
G1 X101.587 Y105.087 E.00363
G1 X101.613 Y104.961 E.00363
G1 X101.613 Y95.099 E.27905
G1 E-.8 F1800
M204 S500
G17
G3 Z1.6 I-.656 J-1.025 P1  F42000
G1 X85.443 Y105.443 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z1.6 I1.17 J-.335 P1  F42000
G1 X85.139 Y103.432 Z1.6
G1 Z1.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y104.86 E.04241
G1 X84.098 Y105.139 E.03202
G1 X83.615 Y105.139 E.01433
G1 X80.861 Y102.385 E.11566
G1 X80.861 Y100.462 E.0571
G1 X85.139 Y99.315 E.13153
G1 X85.139 Y99.089 E.00671
G1 X80.911 Y94.861 E.17755
G1 X83.863 Y94.861 E.08766
G1 X81.109 Y105.139 E.31596
G1 X80.861 Y105.139 E.00738
G1 X80.861 Y103.96 E.03503
; CHANGE_LAYER
; Z_HEIGHT: 1.37778
; LAYER_HEIGHT: 0.177778
M106 S188.7
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.6 I1.135 J.44 P1  F42000
G1 X85.715 Y91.429 Z1.6
G1 Z1.378
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z1.778 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z1.778
G1 Z1.378
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 1.4
; LAYER_HEIGHT: 0.0222222
; OBJECT_ID: 15
G1 E-.8 F1800
M73 P12 R28
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z1.778
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z1.8 I1.217 J0 P1  F42000
G1 X115.559 Y94.861
G1 Z1.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X116.988 Y94.861 E.04241
G1 X114.861 Y102.799 E.24401
G1 X114.861 Y102.588 E.00626
G1 X119.139 Y101.442 E.13153
G1 X119.139 Y102.59 E.03409
G1 X114.861 Y98.311 E.17967
G1 X114.861 Y97.043 E.03765
G1 X119.139 Y95.896 E.13153
G1 X119.139 Y95.015 E.02617
G1 X118.985 Y94.861 E.00649
G1 X117.557 Y94.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z1.8 I-.58 J-1.07 P1  F42000
G1 X98.057 Y105.443 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 X98.205 Y104.598 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.41727
; LAYER_HEIGHT: 0.4
M106 S255
G1 F877.52
M204 S6000
G1 X100.051 Y105.093 E.10866
G1 X101.593 Y105.093 E.08769
G1 X101.593 Y105.023 E.00401
G1 X98.407 Y104.169 E.18752
G1 X98.407 Y103.685 E.0275
G1 X101.593 Y104.539 E.18752
G1 X101.593 Y104.055 E.0275
G1 X98.407 Y103.201 E.18752
G1 X98.407 Y102.718 E.0275
G1 X101.593 Y103.571 E.18752
G1 X101.593 Y103.087 E.0275
G1 X98.407 Y102.234 E.18752
G1 X98.407 Y101.75 E.0275
G1 X101.593 Y102.604 E.18752
G1 X101.593 Y102.12 E.0275
G1 X98.407 Y101.266 E.18752
G1 X98.407 Y100.783 E.0275
G1 X101.593 Y101.636 E.18752
G1 X101.593 Y101.152 E.0275
G1 X98.407 Y100.299 E.18752
G1 X98.407 Y99.815 E.0275
G1 X101.593 Y100.669 E.18752
G1 X101.593 Y100.185 E.0275
G1 X98.407 Y99.331 E.18752
G1 X98.407 Y98.848 E.0275
G1 X101.593 Y99.701 E.18752
G1 X101.593 Y99.217 E.0275
G1 X98.407 Y98.364 E.18752
G1 X98.407 Y97.88 E.0275
G1 X101.593 Y98.734 E.18752
G1 X101.593 Y98.25 E.0275
G1 X98.407 Y97.396 E.18752
G1 X98.407 Y96.913 E.0275
G1 X101.593 Y97.766 E.18752
G1 X101.593 Y97.282 E.0275
G1 X98.407 Y96.429 E.18752
G1 X98.407 Y95.945 E.0275
G1 X101.593 Y96.799 E.18752
G1 X101.593 Y96.315 E.0275
G1 X98.407 Y95.461 E.18752
G1 X98.407 Y94.978 E.0275
G1 X101.593 Y95.831 E.18752
G1 X101.593 Y95.347 E.0275
G1 X99.194 Y94.705 E.14123
M106 S188.7
G1 E-.8 F1800
M204 S500
G17
G3 Z1.8 I-.749 J-.959 P1  F42000
G1 X85.443 Y105.443 Z1.8
G1 Z1.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.139 Y105.036 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y105.139 E.00309
G1 X83.815 Y105.139 E.03932
G1 X80.861 Y102.185 E.12406
G1 X80.861 Y100.608 E.04682
G1 X85.139 Y99.462 E.13153
G1 X85.139 Y98.889 E.017
G1 X81.111 Y94.861 E.16916
G1 X80.861 Y94.861 E.00743
G1 X80.861 Y95.063 E.00601
G1 X81.616 Y94.861 E.02322
G1 X83.717 Y94.861 E.06238
G1 X80.963 Y105.139 E.31596
G1 X82.391 Y105.139 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 1.6
; LAYER_HEIGHT: 0.2
M106 S196.35
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z1.8 I-.011 J1.217 P1  F42000
G1 X114.557 Y105.443 Z1.8
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
M73 P13 R28
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z2 I1.217 J0 P1  F42000
G1 X119.139 Y97.471
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y96.043 E.04241
G1 X114.861 Y97.189 E.13153
G1 X114.861 Y98.111 E.02736
G1 X119.139 Y102.39 E.17967
G1 X119.139 Y101.588 E.02381
G1 X114.861 Y102.735 E.13153
G1 X114.861 Y102.252 E.01431
G1 X116.841 Y94.861 E.22722
G1 X115.413 Y94.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.634 J-1.039 P1  F42000
G1 X98.057 Y105.443 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z2 I1.178 J.305 P1  F42000
G1 X100.168 Y96.5 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.37905
G1 F1785.024
M204 S6000
G1 X100.168 Y96.332 E.0047
G1 X99.832 Y96.332 E.00939
G1 X99.832 Y103.668 E.20504
G1 X100.168 Y103.668 E.00939
G1 X100.168 Y96.56 E.19867
M204 S500
G1 X100.515 Y96.5 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.515 Y95.985 E.01528
G1 X99.485 Y95.985 E.03056
G1 X99.485 Y104.015 E.2384
G1 X100.515 Y104.015 E.03056
G1 X100.515 Y96.56 E.22133
M204 S500
G1 X100.872 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X100.872 Y95.628 E.02588
G1 X99.128 Y95.628 E.05176
G1 X99.128 Y104.372 E.2596
G1 X100.872 Y104.372 E.05176
G1 X100.872 Y96.56 E.23193
M204 S500
G1 X101.229 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.229 Y95.271 E.03648
G1 X98.771 Y95.271 E.07297
G1 X98.771 Y104.729 E.2808
G1 X101.229 Y104.729 E.07297
G1 X101.229 Y96.56 E.24254
M204 S500
G1 X101.586 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.586 Y94.914 E.04709
G1 X98.414 Y94.914 E.09417
G1 X98.414 Y105.086 E.302
G1 X101.586 Y105.086 E.09417
G1 X101.586 Y96.56 E.25314
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I-.587 J-1.066 P1  F42000
G1 X85.443 Y105.443 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z2 I1.07 J-.58 P1  F42000
G1 X80.861 Y96.638 Z2
G1 Z1.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y95.209 E.04241
G1 X82.162 Y94.861 E.04002
G1 X83.57 Y94.861 E.0418
G1 X80.861 Y104.974 E.31087
G1 X80.861 Y105.139 E.00492
G1 X84.015 Y105.139 E.09366
G1 X80.861 Y101.985 E.13246
G1 X80.861 Y100.755 E.03653
G1 X85.139 Y99.608 E.13153
G1 X85.139 Y98.689 E.02729
G1 X81.311 Y94.861 E.16076
; CHANGE_LAYER
; Z_HEIGHT: 1.67222
; LAYER_HEIGHT: 0.0722222
M106 S188.7
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2 I.748 J.96 P1  F42000
G1 X85.715 Y91.429 Z2
G1 Z1.672
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
M73 P14 R28
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
M73 P14 R27
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z2.072 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z2.072
G1 Z1.672
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 1.8
; LAYER_HEIGHT: 0.127778
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z2.072
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z2.2 I1.217 J0 P1  F42000
G1 X119.139 Y97.618
G1 Z1.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y96.189 E.04241
G1 X114.861 Y97.336 E.13153
G1 X114.861 Y97.911 E.01708
G1 X119.139 Y102.19 E.17967
G1 X119.139 Y101.734 E.01352
G1 X114.861 Y102.881 E.13153
G1 X114.861 Y101.706 E.03488
G1 X116.695 Y94.861 E.21042
G1 X115.267 Y94.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.637 J-1.037 P1  F42000
G1 X98.057 Y105.443 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X98.057 Y94.557 E.32321
G1 X101.943 Y94.557 E.11537
G1 X101.943 Y96.5 E.05769
G1 X101.943 Y105.443 E.26552
G1 X98.117 Y105.443 E.11359
M204 S250
G1 X97.7 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z2.2 I1.178 J.305 P1  F42000
G1 X100.168 Y96.5 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.37905
G1 F1785.024
M204 S6000
G1 X100.168 Y96.332 E.0047
G1 X99.832 Y96.332 E.00939
G1 X99.832 Y103.668 E.20504
G1 X100.168 Y103.668 E.00939
G1 X100.168 Y96.56 E.19867
M204 S500
G1 X100.515 Y96.5 F42000
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X100.515 Y95.985 E.01528
G1 X99.485 Y95.985 E.03056
G1 X99.485 Y104.015 E.2384
G1 X100.515 Y104.015 E.03056
G1 X100.515 Y96.56 E.22133
M204 S500
G1 X100.872 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X100.872 Y95.628 E.02588
G1 X99.128 Y95.628 E.05176
G1 X99.128 Y104.372 E.2596
G1 X100.872 Y104.372 E.05176
G1 X100.872 Y96.56 E.23193
M204 S500
G1 X101.229 Y96.5 F42000
G1 F1680.343
M204 S6000
G1 X101.229 Y95.271 E.03648
G1 X98.771 Y95.271 E.07297
G1 X98.771 Y104.729 E.2808
G1 X101.229 Y104.729 E.07297
G1 X101.229 Y96.56 E.24254
M204 S500
G1 X101.586 Y96.5 F42000
M73 P15 R27
G1 F1680.343
M204 S6000
G1 X101.586 Y94.914 E.04709
G1 X98.414 Y94.914 E.09417
G1 X98.414 Y105.086 E.302
G1 X101.586 Y105.086 E.09417
G1 X101.586 Y96.56 E.25314
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I-.587 J-1.066 P1  F42000
G1 X85.443 Y105.443 Z2.2
G1 Z1.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.139 Y104.636 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y105.139 E.01496
G1 X84.215 Y105.139 E.02745
G1 X80.861 Y101.785 E.14085
G1 X80.861 Y100.901 E.02625
G1 X85.139 Y99.754 E.13153
G1 X85.139 Y98.489 E.03757
G1 X81.511 Y94.861 E.15236
G1 X80.861 Y94.861 E.01931
G1 X80.861 Y95.356 E.0147
G1 X82.709 Y94.861 E.05681
G1 X83.424 Y94.861 E.02123
G1 X80.861 Y104.427 E.29407
G1 X80.861 Y105.139 E.02114
G1 X81.577 Y105.139 E.02127
; CHANGE_LAYER
; Z_HEIGHT: 1.96667
; LAYER_HEIGHT: 0.166667
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.2 I1.165 J.352 P1  F42000
G1 X85.715 Y91.429 Z2.2
G1 Z1.967
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z2.367 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z2.367
G1 Z1.967
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 2
; LAYER_HEIGHT: 0.0333333
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z2.367
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
M73 P16 R27
G1 E-.8 F1800
G17
G3 Z2.4 I1.217 J0 P1  F42000
G1 X119.139 Y97.764
G1 Z2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y96.336 E.04241
G1 X114.861 Y97.482 E.13153
G1 X114.861 Y97.711 E.00679
G1 X119.139 Y101.99 E.17967
G1 X119.139 Y101.881 E.00324
G1 X114.861 Y103.027 E.13153
G1 X114.861 Y101.16 E.05546
G1 X116.548 Y94.861 E.19363
G1 X115.12 Y94.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.647 J-1.031 P1  F42000
G1 X97.7 Y105.8 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
G1 X97.7 Y94.2 E.34441
G1 X102.3 Y94.2 E.13658
G1 X102.3 Y96.5 E.06829
G1 X102.3 Y105.8 E.27612
G1 X97.76 Y105.8 E.1348
G1 E-.8 F1800
G17
G3 Z2.4 I.047 J1.216 P1  F42000
G1 X101.433 Y105.657 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40103
G1 F1675.463
G1 X101.997 Y105.094 E.02372
G1 X101.997 Y104.587 E.01508
G1 X101.087 Y105.497 E.03828
G1 X100.581 Y105.497 E.01508
G1 X101.997 Y104.081 E.05961
G1 X101.997 Y103.575 E.01508
G1 X100.075 Y105.497 E.08094
G1 X99.568 Y105.497 E.01508
G1 X101.997 Y103.068 E.10226
G1 X101.997 Y102.562 E.01508
G1 X99.062 Y105.497 E.12359
G1 X98.555 Y105.497 E.01508
G1 X101.997 Y102.055 E.14492
G1 X101.997 Y101.549 E.01508
G1 X98.049 Y105.497 E.16624
G1 X98.004 Y105.497 E.00135
G1 X98.004 Y105.035 E.01373
G1 X101.997 Y101.042 E.16815
G1 X101.997 Y100.536 E.01508
G1 X98.004 Y104.529 E.16815
G1 X98.004 Y104.022 E.01508
G1 X101.997 Y100.029 E.16815
G1 X101.997 Y99.523 E.01508
G1 X98.004 Y103.516 E.16815
G1 X98.004 Y103.01 E.01508
G1 X101.997 Y99.017 E.16815
G1 X101.997 Y98.51 E.01508
G1 X98.004 Y102.503 E.16815
G1 X98.004 Y101.997 E.01508
G1 X101.997 Y98.004 E.16815
G1 X101.997 Y97.497 E.01508
G1 X98.004 Y101.49 E.16815
G1 X98.004 Y100.984 E.01508
G1 X101.997 Y96.991 E.16815
G1 X101.997 Y96.484 E.01508
G1 X98.004 Y100.477 E.16815
G1 X98.004 Y99.971 E.01508
G1 X101.997 Y95.978 E.16815
G1 X101.997 Y95.471 E.01508
G1 X98.004 Y99.464 E.16815
G1 X98.004 Y98.958 E.01508
G1 X101.997 Y94.965 E.16815
G1 X101.997 Y94.503 E.01374
G1 X101.952 Y94.503 E.00134
G1 X98.004 Y98.452 E.16626
G1 X98.004 Y97.945 E.01508
G1 X101.445 Y94.503 E.14493
G1 X100.939 Y94.503 E.01508
G1 X98.004 Y97.439 E.1236
G1 X98.004 Y96.932 E.01508
G1 X100.432 Y94.503 E.10228
G1 X99.926 Y94.503 E.01508
G1 X98.004 Y96.426 E.08095
G1 X98.004 Y95.919 E.01508
G1 X99.419 Y94.503 E.05962
G1 X98.913 Y94.503 E.01508
G1 X98.004 Y95.413 E.03829
G1 X98.004 Y94.906 E.01508
G1 X98.567 Y94.343 E.02373
G1 E-.8 F1800
G17
G3 Z2.4 I-.786 J-.929 P1  F42000
G1 X85.443 Y105.443 Z2.4
G1 Z2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.139 Y104.436 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y105.139 E.0209
G1 X84.415 Y105.139 E.02151
G1 X80.861 Y101.585 E.14925
G1 X80.861 Y101.047 E.01596
G1 X85.139 Y99.901 E.13153
G1 X85.139 Y98.289 E.04786
G1 X81.711 Y94.861 E.14396
G1 X80.861 Y94.861 E.02525
G1 X80.861 Y95.502 E.01905
G1 X83.278 Y94.861 E.07425
G1 X80.861 Y103.881 E.27728
G1 X80.861 Y105.139 E.03736
G1 X81.03 Y105.139 E.00504
; CHANGE_LAYER
; Z_HEIGHT: 2.2
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.4 I-.011 J1.217 P1  F42000
G1 X114.557 Y105.443 Z2.4
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z2.6 I1.217 J0 P1  F42000
G1 X119.14 Y97.91
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y96.482 E.04241
G1 X114.86 Y97.629 E.13153
G1 X114.86 Y97.511 E.0035
G1 X119.14 Y101.79 E.17968
G1 X119.14 Y102.027 E.00704
G1 X114.86 Y103.174 E.13153
G1 X114.86 Y100.614 E.07602
G1 X116.402 Y94.86 E.17684
G1 X117.83 Y94.86 E.04241
M73 P17 R27
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I-.378 J-1.157 P1  F42000
G1 X85.443 Y105.443 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
M73 P17 R26
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z2.6 I1.215 J-.074 P1  F42000
G1 X85.14 Y94.951 Z2.6
G1 Z2.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y94.86 E.0027
G1 X83.802 Y94.86 E.03971
G1 X80.86 Y95.649 E.09042
G1 X80.86 Y94.86 E.0234
G1 X81.911 Y94.86 E.03119
G1 X85.14 Y98.089 E.13557
G1 X85.14 Y100.047 E.05814
G1 X80.86 Y101.194 E.13153
G1 X80.86 Y101.385 E.00567
G1 X84.615 Y105.14 E.15766
G1 X80.86 Y105.14 E.11148
G1 X80.86 Y103.335 E.05358
G1 X83.131 Y94.86 E.2605
; CHANGE_LAYER
; Z_HEIGHT: 2.26111
; LAYER_HEIGHT: 0.061111
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.6 I.972 J.732 P1  F42000
G1 X85.715 Y91.429 Z2.6
G1 Z2.261
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X103.029 Y94.286 E.43057
G1 X103.029 Y93.781 E.02081
G1 X102.719 Y93.471 E.01805
G1 X97.281 Y93.471 E.22421
G1 X96.971 Y93.781 E.01805
G1 X96.971 Y94.286 E.02081
G1 X86.529 Y94.286 E.43057
G1 X86.529 Y97.143 E.1178
G1 X96.971 Y97.143 E.43057
G1 X96.971 Y100 E.1178
G1 X86.529 Y100 E.43057
G1 X86.529 Y102.857 E.1178
G1 X96.971 Y102.857 E.43057
G1 X96.971 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z2.661 I1.068 J.584 P1  F42000
G1 X103.029 Y94.464 Z2.661
G1 Z2.261
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X103.029 Y97.143 E.11044
G1 X113.471 Y97.143 E.43057
G1 X113.471 Y100 E.1178
G1 X103.029 Y100 E.43057
G1 X103.029 Y102.857 E.1178
G1 X113.471 Y102.857 E.43057
G1 X113.471 Y105.714 E.1178
G1 X103.029 Y105.714 E.43057
G1 X103.029 Y106.219 E.02081
G1 X102.719 Y106.529 E.01805
G1 X97.281 Y106.529 E.22421
G1 X96.971 Y106.219 E.01805
G1 X96.971 Y105.714 E.02081
G1 X86.529 Y105.714 E.43057
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 2.4
; LAYER_HEIGHT: 0.138889
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z2.661
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z2.8 I1.217 J0 P1  F42000
M73 P18 R26
G1 X116.543 Y105.14
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.114 Y105.14 E.04241
G1 X114.86 Y104.886 E.01066
G1 X114.86 Y103.32 E.04648
G1 X119.14 Y102.174 E.13153
G1 X119.14 Y101.59 E.01733
G1 X114.86 Y97.311 E.17968
G1 X114.86 Y97.775 E.01378
G1 X119.14 Y96.628 E.13153
G1 X119.14 Y94.86 E.0525
G1 X116.256 Y94.86 E.08563
G1 X114.86 Y100.067 E.16005
G1 X114.86 Y101.496 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I-.162 J-1.206 P1  F42000
G1 X85.443 Y105.443 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z2.8 I.294 J-1.181 P1  F42000
G1 X83.387 Y105.14 Z2.8
G1 Z2.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X84.815 Y105.14 E.04241
G1 X80.86 Y101.185 E.16606
G1 X80.86 Y101.34 E.00461
G1 X85.14 Y100.194 E.13153
G1 X85.14 Y97.889 E.06842
G1 X82.111 Y94.86 E.12717
G1 X82.985 Y94.86 E.02595
G1 X80.86 Y102.789 E.2437
G1 X80.86 Y104.217 E.04241
M204 S500
G1 X80.86 Y97.223 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y95.795 E.04241
G1 X84.348 Y94.86 E.10722
G1 X85.14 Y94.86 E.02349
G1 X85.14 Y95.498 E.01892
; CHANGE_LAYER
; Z_HEIGHT: 2.55556
; LAYER_HEIGHT: 0.155555
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z2.8 I1.205 J.17 P1  F42000
G1 X85.715 Y91.429 Z2.8
G1 Z2.556
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z2.956 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z2.956
G1 Z2.556
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 2.6
; LAYER_HEIGHT: 0.0444443
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z2.956
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
M73 P19 R26
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z3 I1.217 J0 P1  F42000
G1 X114.86 Y100.949
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y99.521 E.04241
G1 X116.109 Y94.86 E.14325
G1 X119.14 Y94.86 E.08997
G1 X119.14 Y96.775 E.05684
G1 X114.86 Y97.921 E.13153
G1 X114.86 Y97.111 E.02407
G1 X119.14 Y101.39 E.17968
G1 X119.14 Y102.32 E.02761
G1 X114.86 Y103.467 E.13153
G1 X114.86 Y104.686 E.0362
G1 X115.314 Y105.14 E.01906
G1 X118.9 Y105.14 E.10647
G1 X119.14 Y104.246 E.02747
G1 X119.14 Y102.818 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I-.095 J-1.213 P1  F42000
G1 X85.443 Y105.443 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z3 I.794 J-.922 P1  F42000
G1 X80.86 Y101.487 Z3
G1 Z2.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y100.34 E.13153
G1 X85.14 Y97.689 E.07871
G1 X82.311 Y94.86 E.11878
G1 X82.838 Y94.86 E.01566
G1 X80.86 Y102.242 E.22691
G1 X80.86 Y105.14 E.08602
G1 X85.015 Y105.14 E.12336
G1 X80.86 Y100.985 E.17445
G1 X80.86 Y95.941 E.14975
G1 X84.895 Y94.86 E.12401
G1 X85.14 Y94.86 E.00726
G1 X85.14 Y96.044 E.03514
; CHANGE_LAYER
; Z_HEIGHT: 2.8
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3 I-.37 J1.159 P1  F42000
G1 X114.557 Y105.443 Z3
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z3.2 I1.217 J0 P1  F42000
G1 X116.943 Y105.14
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.514 Y105.14 E.04241
G1 X114.86 Y104.486 E.02745
G1 X114.86 Y103.613 E.02591
G1 X119.14 Y102.466 E.13153
G1 X119.14 Y103.699 E.03661
G1 X118.754 Y105.14 E.04427
G1 X117.325 Y105.14 E.04241
M204 S500
G1 X114.86 Y100.403 F42000
G1 F1680.297
M204 S6000
G1 X114.86 Y98.974 E.04241
G1 X115.963 Y94.86 E.12646
G1 X114.86 Y94.86 E.03273
G1 X114.86 Y96.911 E.06088
G1 X119.14 Y101.19 E.17968
G1 X119.14 Y96.921 E.12674
G1 X114.86 Y98.068 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I-.296 J-1.18 P1  F42000
G1 X85.443 Y105.443 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z3.2 I.862 J-.859 P1  F42000
G1 X80.86 Y100.785 Z3.2
G1 Z2.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y105.064 E.17968
G1 X85.14 Y100.486 E.13591
G1 X80.86 Y101.633 E.13153
G1 X80.86 Y101.696 E.00186
G1 X82.692 Y94.86 E.21011
G1 X82.511 Y94.86 E.00538
G1 X85.14 Y97.489 E.11038
G1 X85.14 Y94.941 E.07565
G1 X80.86 Y96.088 E.13153
G1 X80.86 Y97.516 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 2.85
; LAYER_HEIGHT: 0.05
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.2 I.951 J.759 P1  F42000
G1 X85.715 Y91.429 Z3.2
M73 P20 R26
G1 Z2.85
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
M73 P20 R25
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z3.25 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z3.25
G1 Z2.85
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 3
; LAYER_HEIGHT: 0.15
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z3.25
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z3.4 I1.217 J0 P1  F42000
G1 X117.143 Y105.14
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.714 Y105.14 E.04241
G1 X114.86 Y104.286 E.03585
G1 X114.86 Y103.759 E.01563
G1 X119.14 Y102.613 E.13153
G1 X119.14 Y103.153 E.01604
G1 X118.607 Y105.14 E.06106
G1 X117.179 Y105.14 E.04241
M204 S500
G1 X119.14 Y99.562 F42000
G1 F1680.297
M204 S6000
G1 X119.14 Y100.99 E.04241
G1 X114.86 Y96.711 E.17968
G1 X114.86 Y94.86 E.05494
G1 X115.816 Y94.86 E.02838
G1 X114.86 Y98.428 E.10966
G1 X114.86 Y98.214 E.00634
G1 X119.14 Y97.068 E.13153
G1 X119.14 Y95.639 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I-.34 J-1.169 P1  F42000
G1 X85.443 Y105.443 Z3.4
G1 Z3
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z3.4 I.879 J-.842 P1  F42000
G1 X80.86 Y100.585 Z3.4
M73 P21 R25
G1 Z3
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.864 E.17968
G1 X85.14 Y100.633 E.12563
G1 X80.86 Y101.779 E.13153
G1 X80.86 Y101.149 E.01871
G1 X82.546 Y94.86 E.19331
G1 X82.711 Y94.86 E.00491
G1 X85.14 Y97.289 E.10198
G1 X85.14 Y95.088 E.06536
G1 X80.86 Y96.234 E.13153
G1 X80.86 Y97.663 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 3.14444
; LAYER_HEIGHT: 0.144444
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.4 I.96 J.748 P1  F42000
G1 X85.715 Y91.429 Z3.4
G1 Z3.144
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z3.544 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z3.544
G1 Z3.144
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 3.2
; LAYER_HEIGHT: 0.0555556
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z3.544
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z3.6 I1.217 J0 P1  F42000
G1 X117.343 Y105.14
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.914 Y105.14 E.04241
G1 X114.86 Y104.086 E.04425
G1 X114.86 Y103.906 E.00534
G1 X119.14 Y102.759 E.13153
G1 X119.14 Y102.607 E.00453
G1 X118.461 Y105.14 E.07786
G1 X119.14 Y105.14 E.02015
G1 X119.14 Y104.39 E.02226
M204 S500
G1 X119.14 Y99.362 F42000
G1 F1680.297
M204 S6000
G1 X119.14 Y100.79 E.04241
G1 X114.86 Y96.511 E.17968
G1 X114.86 Y94.86 E.049
G1 X115.67 Y94.86 E.02403
G1 X114.86 Y97.882 E.09286
G1 X114.86 Y98.361 E.01423
G1 X119.14 Y97.214 E.13153
G1 X119.14 Y95.786 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I-.335 J-1.17 P1  F42000
G1 X85.443 Y105.443 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
M73 P22 R25
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z3.6 I.529 J-1.096 P1  F42000
G1 X80.86 Y103.354 Z3.6
G1 Z3.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y101.926 E.04241
G1 X85.14 Y100.779 E.13153
G1 X85.14 Y104.664 E.11534
G1 X80.86 Y100.385 E.17968
G1 X80.86 Y100.603 E.00648
G1 X82.399 Y94.86 E.17652
G1 X82.911 Y94.86 E.01519
G1 X85.14 Y97.089 E.09358
G1 X85.14 Y95.234 E.05508
G1 X80.86 Y96.381 E.13153
G1 X80.86 Y97.809 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 3.4
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.6 I-.269 J1.187 P1  F42000
G1 X114.557 Y105.443 Z3.6
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z3.8 I1.217 J0 P1  F42000
G1 X119.14 Y102.906
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y104.052 E.13153
G1 X114.86 Y103.886 E.00495
G1 X116.114 Y105.14 E.05265
G1 X118.314 Y105.14 E.06532
G1 X119.14 Y102.06 E.09466
G1 X119.14 Y100.59 E.04365
G1 X114.86 Y96.311 E.17968
M204 S500
G1 X116.952 Y94.86 F42000
G1 F1680.297
M204 S6000
G1 X115.524 Y94.86 E.04241
G1 X114.86 Y97.335 E.07607
G1 X114.86 Y98.507 E.0348
G1 X119.14 Y97.361 E.13153
G1 X119.14 Y95.932 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I-.331 J-1.171 P1  F42000
G1 X85.443 Y105.443 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z3.8 I.503 J-1.108 P1  F42000
G1 X80.86 Y103.501 Z3.8
G1 Z3.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y102.072 E.04241
G1 X85.14 Y100.926 E.13153
G1 X85.14 Y104.464 E.10506
G1 X80.86 Y100.185 E.17968
G1 X80.86 Y100.057 E.00381
G1 X82.253 Y94.86 E.15972
G1 X83.111 Y94.86 E.02548
G1 X85.14 Y96.889 E.08518
G1 X85.14 Y95.381 E.04479
G1 X80.86 Y96.527 E.13153
G1 X80.86 Y95.099 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 3.43889
; LAYER_HEIGHT: 0.0388887
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z3.8 I.734 J.971 P1  F42000
G1 X85.715 Y91.429 Z3.8
G1 Z3.439
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z3.839 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z3.839
M73 P23 R25
G1 Z3.439
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 3.6
; LAYER_HEIGHT: 0.161111
; OBJECT_ID: 15
G1 E-.8 F1800
M73 P23 R24
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z3.839
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z4 I1.217 J0 P1  F42000
G1 X119.14 Y104.48
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.052 E.04241
G1 X114.86 Y104.199 E.13153
G1 X114.86 Y103.686 E.01523
G1 X116.314 Y105.14 E.06105
G1 X118.168 Y105.14 E.05504
G1 X119.14 Y101.514 E.11145
G1 X119.14 Y100.39 E.03337
G1 X114.86 Y96.111 E.17968
M204 S500
G1 X116.805 Y94.86 F42000
G1 F1680.297
M204 S6000
G1 X115.377 Y94.86 E.04241
G1 X114.86 Y96.789 E.05927
G1 X114.86 Y98.654 E.05537
G1 X119.14 Y97.507 E.13153
G1 X119.14 Y96.079 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I-.326 J-1.173 P1  F42000
G1 X85.443 Y105.443 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z4 I1.21 J-.131 P1  F42000
G1 X85.14 Y99.644 Z4
G1 Z3.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y101.072 E.04241
G1 X80.86 Y102.219 E.13153
G1 X80.86 Y105.14 E.08672
G1 X84.897 Y105.14 E.11986
G1 X85.14 Y104.235 E.0278
G1 X85.14 Y104.264 E.00085
G1 X80.86 Y99.985 E.17968
G1 X80.86 Y99.51 E.01409
G1 X82.106 Y94.86 E.14293
G1 X83.311 Y94.86 E.03576
G1 X85.14 Y96.689 E.07679
G1 X85.14 Y95.527 E.03451
G1 X80.86 Y96.674 E.13153
G1 X80.86 Y95.245 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 3.73333
; LAYER_HEIGHT: 0.133333
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4 I.752 J.957 P1  F42000
G1 X85.715 Y91.429 Z4
G1 Z3.733
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
M73 P24 R24
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z4.133 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z4.133
G1 Z3.733
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 3.8
; LAYER_HEIGHT: 0.0666666
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z4.133
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z4.2 I1.217 J0 P1  F42000
G1 X119.14 Y104.627
G1 Z3.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.199 E.04241
G1 X114.86 Y104.345 E.13153
G1 X114.86 Y103.486 E.02552
G1 X116.514 Y105.14 E.06944
G1 X118.022 Y105.14 E.04475
G1 X119.14 Y100.967 E.12825
G1 X119.14 Y100.19 E.02308
G1 X114.86 Y95.911 E.17968
G1 X114.86 Y96.242 E.00984
G1 X115.231 Y94.86 E.04248
G1 X119.14 Y94.86 E.11606
G1 X119.14 Y97.653 E.08292
G1 X114.86 Y98.8 E.13153
G1 X114.86 Y100.228 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I-.212 J-1.198 P1  F42000
G1 X85.443 Y105.443 Z4.2
G1 Z3.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y104.064 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y99.785 E.17968
G1 X80.86 Y98.964 E.02438
G1 X81.96 Y94.86 E.12613
G1 X83.511 Y94.86 E.04605
G1 X85.14 Y96.489 E.06839
G1 X85.14 Y95.673 E.02422
G1 X80.86 Y96.82 E.13153
G1 X80.86 Y95.392 E.04241
M204 S500
G1 X80.86 Y103.793 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y102.365 E.04241
G1 X85.14 Y101.219 E.13153
G1 X85.14 Y103.689 E.07334
G1 X84.751 Y105.14 E.0446
G1 X83.323 Y105.14 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 4
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.2 I-.012 J1.217 P1  F42000
G1 X114.557 Y105.443 Z4.2
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
M73 P25 R24
G1 E-.8 F1800
G17
G3 Z4.4 I1.217 J0 P1  F42000
G1 X119.14 Y104.773
G1 Z4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.345 E.04241
G1 X114.86 Y104.491 E.13153
G1 X114.86 Y103.286 E.0358
G1 X116.714 Y105.14 E.07784
G1 X117.875 Y105.14 E.03447
G1 X119.14 Y100.421 E.14504
G1 X119.14 Y99.99 E.0128
G1 X114.86 Y95.711 E.17968
G1 X115.084 Y94.86 E.02611
G1 X119.14 Y94.86 E.1204
G1 X119.14 Y97.8 E.08727
G1 X114.86 Y98.946 E.13153
G1 X114.86 Y100.375 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I-.207 J-1.199 P1  F42000
G1 X85.443 Y105.443 Z4.4
G1 Z4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y103.864 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y99.585 E.17968
G1 X80.86 Y98.417 E.03467
G1 X81.814 Y94.86 E.10933
G1 X83.711 Y94.86 E.05633
G1 X85.14 Y96.289 E.05999
G1 X85.14 Y95.82 E.01394
G1 X80.86 Y96.966 E.13153
G1 X80.86 Y95.538 E.04241
M204 S500
G1 X80.86 Y103.94 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y102.511 E.04241
G1 X85.14 Y101.365 E.13153
G1 X85.14 Y103.142 E.05277
G1 X84.604 Y105.14 E.06139
G1 X83.176 Y105.14 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 4.02778
; LAYER_HEIGHT: 0.0277777
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.4 I1.197 J.222 P1  F42000
G1 X85.715 Y91.429 Z4.4
G1 Z4.028
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z4.428 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z4.428
G1 Z4.028
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 4.2
; LAYER_HEIGHT: 0.172222
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z4.428
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
M73 P26 R24
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z4.6 I1.217 J0 P1  F42000
G1 X119.14 Y104.92
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.491 E.04241
G1 X114.86 Y104.638 E.13153
G1 X114.86 Y103.086 E.04609
G1 X116.914 Y105.14 E.08624
G1 X117.729 Y105.14 E.02418
G1 X119.14 Y99.875 E.16184
G1 X119.14 Y99.79 E.00251
G1 X114.86 Y95.511 E.17968
G1 X114.86 Y99.093 E.10635
G1 X119.14 Y97.946 E.13153
G1 X119.14 Y96.518 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I-.312 J-1.176 P1  F42000
G1 X85.443 Y105.443 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
M73 P26 R23
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z4.6 I1.16 J-.369 P1  F42000
G1 X85.14 Y103.664 Z4.6
G1 Z4.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y99.385 E.17968
G1 X80.86 Y97.871 E.04495
G1 X81.667 Y94.86 E.09254
G1 X83.911 Y94.86 E.06662
G1 X85.14 Y96.089 E.05159
G1 X85.14 Y95.966 E.00365
G1 X80.86 Y97.113 E.13153
M204 S500
G1 X80.86 Y104.086 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y102.658 E.04241
G1 X85.14 Y101.511 E.13153
G1 X85.14 Y102.596 E.0322
G1 X84.458 Y105.14 E.07819
G1 X83.03 Y105.14 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 4.32222
; LAYER_HEIGHT: 0.122222
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.6 I1.194 J.234 P1  F42000
G1 X85.715 Y91.429 Z4.6
G1 Z4.322
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z4.722 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z4.722
G1 Z4.322
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 4.4
; LAYER_HEIGHT: 0.0777779
; OBJECT_ID: 15
G1 E-.8 F1800
M73 P27 R23
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z4.722
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z4.8 I1.217 J0 P1  F42000
G1 X119.14 Y102.209
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.638 E.04241
G1 X114.86 Y104.784 E.13153
G1 X114.86 Y102.886 E.05637
G1 X117.114 Y105.14 E.09464
G1 X117.582 Y105.14 E.0139
G1 X119.14 Y99.328 E.17863
G1 X119.14 Y99.59 E.00777
G1 X114.86 Y95.311 E.17968
G1 X114.86 Y99.239 E.11663
G1 X119.14 Y98.093 E.13153
G1 X119.14 Y96.664 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I-.307 J-1.178 P1  F42000
G1 X85.443 Y105.443 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z4.8 I.355 J-1.164 P1  F42000
G1 X80.86 Y104.233 Z4.8
G1 Z4.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y102.804 E.04241
G1 X85.14 Y101.658 E.13153
G1 X85.14 Y102.05 E.01163
G1 X84.312 Y105.14 E.09498
G1 X85.14 Y105.14 E.02458
G1 X85.14 Y103.464 E.04975
G1 X80.86 Y99.185 E.17968
G1 X80.86 Y100.613 E.04241
M204 S500
G1 X80.86 Y95.629 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y94.86 E.02281
G1 X81.521 Y94.86 E.0196
G1 X80.86 Y97.325 E.07574
G1 X80.86 Y97.259 E.00194
G1 X85.14 Y96.113 E.13153
G1 X85.14 Y95.889 E.00663
G1 X84.111 Y94.86 E.04319
G1 X82.683 Y94.86 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 4.6
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z4.8 I-.383 J1.155 P1  F42000
G1 X114.557 Y105.443 Z4.8
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z5 I1.217 J0 P1  F42000
G1 X119.14 Y102.356
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.784 E.04241
G1 X114.86 Y104.931 E.13153
G1 X114.86 Y102.686 E.06666
G1 X117.314 Y105.14 E.10304
G1 X117.436 Y105.14 E.00361
G1 X119.14 Y98.782 E.19543
G1 X119.14 Y98.239 E.01611
G1 X114.86 Y99.386 E.13153
G1 X114.86 Y95.111 E.12692
G1 X119.14 Y99.39 E.17968
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I-.215 J-1.198 P1  F42000
G1 X85.443 Y105.443 Z5
G1 Z4.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z5 I.323 J-1.173 P1  F42000
G1 X80.86 Y104.379 Z5
M73 P28 R23
G1 Z4.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y102.951 E.04241
G1 X85.14 Y101.804 E.13153
G1 X85.14 Y101.503 E.00894
G1 X84.165 Y105.14 E.11178
G1 X85.14 Y105.14 E.02893
G1 X85.14 Y103.264 E.05569
G1 X80.86 Y98.985 E.17968
G1 X80.86 Y100.413 E.04241
M204 S500
G1 X82.803 Y94.86 F42000
G1 F1680.297
M204 S6000
G1 X81.374 Y94.86 E.04241
G1 X80.86 Y96.778 E.05895
G1 X80.86 Y97.406 E.01863
G1 X85.14 Y96.259 E.13153
G1 X85.14 Y95.689 E.01692
G1 X84.311 Y94.86 E.0348
G1 X82.883 Y94.86 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 4.61667
; LAYER_HEIGHT: 0.0166669
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5 I.939 J.775 P1  F42000
G1 X85.715 Y91.429 Z5
G1 Z4.617
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z5.017 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z5.017
G1 Z4.617
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 4.8
; LAYER_HEIGHT: 0.183333
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z5.017
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z5.2 I1.217 J0 P1  F42000
G1 X119.14 Y102.502
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y103.931 E.04241
G1 X114.86 Y105.077 E.13153
G1 X114.86 Y102.486 E.07694
G1 X117.514 Y105.14 E.11143
G1 X117.29 Y105.14 E.00667
G1 X119.14 Y98.235 E.21223
G1 X119.14 Y98.385 E.00446
G1 X114.86 Y99.532 E.13153
G1 X114.86 Y94.911 E.13721
G1 X119.14 Y99.19 E.17968
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I-.222 J-1.197 P1  F42000
G1 X85.443 Y105.443 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
M73 P29 R23
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z5.2 I1.199 J-.209 P1  F42000
G1 X85.14 Y101.951 Z5.2
G1 Z4.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y103.097 E.13153
G1 X80.86 Y104.525 E.04241
M204 S500
G1 X85.14 Y99.528 F42000
G1 F1680.297
M204 S6000
G1 X85.14 Y100.957 E.04241
G1 X84.019 Y105.14 E.12858
G1 X85.14 Y105.14 E.03328
G1 X85.14 Y103.064 E.06163
G1 X80.86 Y98.785 E.17968
G1 X80.86 Y97.552 E.03661
G1 X85.14 Y96.405 E.13153
G1 X85.14 Y95.489 E.02721
G1 X84.511 Y94.86 E.0264
G1 X81.228 Y94.86 E.09748
G1 X80.86 Y96.232 E.04215
G1 X80.86 Y97.373 E.0339
; CHANGE_LAYER
; Z_HEIGHT: 4.91111
; LAYER_HEIGHT: 0.111111
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.2 I.943 J.77 P1  F42000
G1 X85.715 Y91.429 Z5.2
G1 Z4.911
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
M73 P29 R22
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z5.311 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z5.311
G1 Z4.911
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 5
; LAYER_HEIGHT: 0.0888891
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z5.311
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z5.4 I1.217 J0 P1  F42000
G1 X114.86 Y104.025
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.0331
G1 X115.174 Y105.14 E.00931
G1 X119.14 Y104.077 E.1219
G1 X119.14 Y98.99 E.15104
G1 X115.01 Y94.86 E.1734
G1 X119.14 Y94.86 E.12261
G1 X119.14 Y97.689 E.08398
G1 X117.143 Y105.14 E.22902
G1 X117.714 Y105.14 E.01696
G1 X114.86 Y102.286 E.11983
G1 X114.86 Y99.678 E.07741
M73 P30 R22
G1 X119.14 Y98.532 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I-.245 J-1.192 P1  F42000
G1 X85.443 Y105.443 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z5.4 I1.211 J-.118 P1  F42000
G1 X85.14 Y98.982 Z5.4
G1 Z5
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y100.41 E.04241
G1 X83.872 Y105.14 E.14537
G1 X80.86 Y105.14 E.08943
G1 X80.86 Y103.244 E.05629
G1 X85.14 Y102.097 E.13153
G1 X85.14 Y102.864 E.02277
G1 X80.86 Y98.585 E.17968
G1 X80.86 Y97.698 E.02632
G1 X85.14 Y96.552 E.13153
G1 X85.14 Y95.289 E.03749
G1 X84.711 Y94.86 E.018
G1 X81.081 Y94.86 E.10776
G1 X80.86 Y95.685 E.02535
G1 X80.86 Y97.114 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 5.2
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.4 I-.292 J1.181 P1  F42000
G1 X114.557 Y105.443 Z5.4
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z5.6 I1.217 J0 P1  F42000
G1 X114.86 Y104.571
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.01688
G1 X115.72 Y105.14 E.02553
G1 X119.14 Y104.223 E.1051
G1 X119.14 Y102.795 E.04241
M204 S500
G1 X119.14 Y95.714 F42000
G1 F1680.297
M204 S6000
G1 X119.14 Y97.143 E.04241
G1 X116.997 Y105.14 E.24582
G1 X117.914 Y105.14 E.02724
G1 X114.86 Y102.086 E.12823
G1 X114.86 Y99.825 E.06713
G1 X119.14 Y98.678 E.13153
G1 X119.14 Y98.79 E.00332
G1 X115.21 Y94.86 E.165
G1 X116.638 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I-.391 J-1.152 P1  F42000
G1 X85.443 Y105.443 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z5.6 I1.212 J-.11 P1  F42000
G1 X85.14 Y98.436 Z5.6
G1 Z5.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y99.864 E.04241
G1 X83.726 Y105.14 E.16217
G1 X80.86 Y105.14 E.08508
G1 X80.86 Y103.39 E.05195
G1 X85.14 Y102.243 E.13153
G1 X85.14 Y102.664 E.01249
G1 X80.86 Y98.385 E.17968
G1 X80.86 Y97.845 E.01604
G1 X85.14 Y96.698 E.13153
G1 X85.14 Y95.089 E.04778
G1 X84.911 Y94.86 E.0096
G1 X83.483 Y94.86 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 5.20556
; LAYER_HEIGHT: 0.00555563
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.6 I1.02 J.664 P1  F42000
G1 X85.715 Y91.429 Z5.6
G1 Z5.206
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
M73 P31 R22
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z5.606 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z5.606
G1 Z5.206
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 5.4
; LAYER_HEIGHT: 0.194445
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z5.606
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z5.8 I1.217 J0 P1  F42000
G1 X114.86 Y105.118
G1 Z5.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.00065
G1 X116.267 Y105.14 E.04175
G1 X119.14 Y104.37 E.08831
G1 X119.14 Y105.14 E.02286
G1 X118.114 Y105.14 E.03044
G1 X114.86 Y101.886 E.13663
G1 X114.86 Y99.971 E.05684
G1 X119.14 Y98.825 E.13153
G1 X119.14 Y98.59 E.00697
G1 X115.41 Y94.86 E.1566
G1 X119.14 Y94.86 E.11073
G1 X119.14 Y96.596 E.05153
G1 X116.85 Y105.14 E.26261
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I-.012 J-1.217 P1  F42000
G1 X85.443 Y105.443 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z5.8 I.198 J-1.201 P1  F42000
G1 X82.151 Y105.14 Z5.8
G1 Z5.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.58 Y105.14 E.04241
G1 X85.14 Y99.317 E.17896
G1 X85.14 Y96.845 E.07342
G1 X80.86 Y97.991 E.13153
G1 X80.86 Y98.185 E.00575
G1 X85.14 Y102.464 E.17968
G1 X85.14 Y102.39 E.0022
G1 X80.86 Y103.536 E.13153
G1 X80.86 Y102.108 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 5.5
; LAYER_HEIGHT: 0.0999999
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z5.8 I1.108 J.504 P1  F42000
G1 X85.715 Y91.429 Z5.8
G1 Z5.5
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
M73 P32 R22
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z5.9 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z5.9
G1 Z5.5
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 5.6
; LAYER_HEIGHT: 0.0999999
; OBJECT_ID: 15
G1 E-.8 F1800
M73 P32 R21
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z5.9
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z6 I1.217 J0 P1  F42000
G1 X114.86 Y95.539
G1 Z5.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y94.86 E.02015
G1 X115.61 Y94.86 E.02226
G1 X119.14 Y98.39 E.1482
G1 X119.14 Y98.971 E.01725
G1 X114.86 Y100.118 E.13153
G1 X114.86 Y101.686 E.04656
G1 X118.314 Y105.14 E.14503
G1 X119.14 Y105.14 E.0245
G1 X119.14 Y104.516 E.01851
G1 X116.813 Y105.14 E.07151
G1 X116.704 Y105.14 E.00324
G1 X119.14 Y96.05 E.27941
G1 X119.14 Y94.86 E.03531
G1 X118.9 Y94.86 E.0071
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I-.367 J-1.16 P1  F42000
G1 X85.443 Y105.443 Z6
G1 Z5.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.861 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.433 Y105.14 E.04241
G1 X85.14 Y98.771 E.19576
G1 X85.14 Y96.991 E.05285
G1 X80.86 Y98.138 E.13153
G1 X80.86 Y97.985 E.00454
G1 X85.14 Y102.264 E.17968
G1 X85.14 Y102.536 E.00808
G1 X80.86 Y103.683 E.13153
G1 X80.86 Y102.254 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 5.79444
; LAYER_HEIGHT: 0.194445
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6 I1.11 J.498 P1  F42000
G1 X85.715 Y91.429 Z6
G1 Z5.794
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
M73 P33 R21
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z6.194 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z6.194
G1 Z5.794
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 5.8
; LAYER_HEIGHT: 0.00555563
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z6.194
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z6.2 I1.217 J0 P1  F42000
G1 X114.86 Y95.339
G1 Z5.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y94.86 E.01422
G1 X115.81 Y94.86 E.02819
G1 X119.14 Y98.19 E.13981
G1 X119.14 Y99.117 E.02754
G1 X114.86 Y100.264 E.13153
G1 X114.86 Y101.486 E.03627
G1 X118.514 Y105.14 E.15342
G1 X119.14 Y105.14 E.01856
G1 X119.14 Y104.663 E.01416
G1 X117.36 Y105.14 E.05471
G1 X116.558 Y105.14 E.02381
G1 X119.14 Y95.503 E.29621
G1 X119.14 Y94.86 E.01909
G1 X118.354 Y94.86 E.02332
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I-.373 J-1.159 P1  F42000
G1 X85.443 Y105.443 Z6.2
G1 Z5.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.715 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.287 Y105.14 E.04241
G1 X85.14 Y98.225 E.21255
G1 X85.14 Y97.137 E.03228
G1 X80.86 Y98.284 E.13153
G1 X80.86 Y97.785 E.01482
G1 X85.14 Y102.064 E.17968
G1 X85.14 Y102.683 E.01837
G1 X80.86 Y103.829 E.13153
G1 X80.86 Y102.401 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 6
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.2 I-.109 J1.212 P1  F42000
G1 X114.557 Y105.443 Z6.2
G1 Z6
M73 P34 R21
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z6.4 I1.217 J0 P1  F42000
G1 X118.714 Y105.14
G1 Z6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y101.286 E.16182
G1 X114.86 Y100.41 E.02599
G1 X119.14 Y99.264 E.13153
G1 X119.14 Y97.99 E.03782
G1 X116.01 Y94.86 E.13141
G1 X119.14 Y94.86 E.09292
G1 X119.14 Y94.957 E.00286
G1 X116.411 Y105.14 E.313
G1 X117.906 Y105.14 E.04439
G1 X119.14 Y104.809 E.03792
G1 X119.14 Y103.381 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I-.074 J-1.215 P1  F42000
G1 X85.443 Y105.443 Z6.4
G1 Z6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.569 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.14 Y105.14 E.04241
G1 X85.14 Y97.678 E.22935
G1 X85.14 Y97.284 E.01171
G1 X80.86 Y98.43 E.13153
G1 X80.86 Y97.585 E.02511
G1 X85.14 Y101.864 E.17968
G1 X85.14 Y102.829 E.02865
G1 X80.86 Y103.976 E.13153
G1 X80.86 Y102.547 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 6.08889
; LAYER_HEIGHT: 0.0888891
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.4 I1.115 J.487 P1  F42000
G1 X85.715 Y91.429 Z6.4
G1 Z6.089
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z6.489 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z6.489
G1 Z6.089
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 6.2
; LAYER_HEIGHT: 0.111111
; OBJECT_ID: 15
G1 E-.8 F1800
M73 P35 R21
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z6.489
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z6.6 I1.217 J0 P1  F42000
G1 X114.86 Y96.44
G1 Z6.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.012 E.04241
G1 X115.425 Y94.86 E.01735
G1 X116.21 Y94.86 E.02331
G1 X119.14 Y97.79 E.12301
G1 X119.14 Y99.41 E.04811
G1 X114.86 Y100.557 E.13153
G1 X114.86 Y101.086 E.0157
G1 X118.914 Y105.14 E.17022
G1 X119.14 Y105.14 E.00669
G1 X119.14 Y104.955 E.00547
G1 X118.452 Y105.14 E.02112
G1 X116.265 Y105.14 E.06496
G1 X119.019 Y94.86 E.31597
G1 X117.591 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I-.381 J-1.156 P1  F42000
G1 X85.443 Y105.443 Z6.6
G1 Z6.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.422 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X82.994 Y105.14 E.04241
G1 X85.14 Y97.132 E.24615
G1 X85.14 Y97.43 E.00886
G1 X80.86 Y98.577 E.13153
G1 X80.86 Y97.385 E.03539
G1 X85.14 Y101.664 E.17968
G1 X85.14 Y102.975 E.03894
G1 X80.86 Y104.122 E.13153
G1 X80.86 Y104.96 E.02487
G1 X81.04 Y105.14 E.00755
G1 X82.469 Y105.14 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 6.38333
; LAYER_HEIGHT: 0.183333
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.6 I1.184 J.28 P1  F42000
G1 X85.715 Y91.429 Z6.6
G1 Z6.383
M73 P35 R20
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z6.783 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z6.783
G1 Z6.383
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
M73 P36 R20
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 6.4
; LAYER_HEIGHT: 0.0166669
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z6.783
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z6.8 I1.217 J0 P1  F42000
G1 X114.86 Y96.586
G1 Z6.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.158 E.04241
G1 X115.971 Y94.86 E.03415
G1 X116.41 Y94.86 E.01302
G1 X119.14 Y97.59 E.11461
G1 X119.14 Y99.557 E.0584
G1 X114.86 Y100.703 E.13153
G1 X114.86 Y100.886 E.00542
G1 X119.114 Y105.14 E.17862
G1 X116.118 Y105.14 E.08896
G1 X118.873 Y94.86 E.31597
G1 X119.14 Y94.86 E.00793
G1 X119.14 Y96.022 E.03448
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I-.328 J-1.172 P1  F42000
G1 X85.443 Y105.443 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z6.8 I1.213 J-.098 P1  F42000
G1 X85.14 Y97.577 Z6.8
G1 Z6.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y98.723 E.13153
G1 X80.86 Y97.185 E.04568
G1 X85.14 Y101.464 E.17968
G1 X85.14 Y103.122 E.04923
G1 X80.86 Y104.268 E.13153
G1 X80.86 Y104.76 E.01459
G1 X81.24 Y105.14 E.01595
G1 X82.847 Y105.14 E.04772
G1 X85.14 Y96.585 E.26294
G1 X85.14 Y95.157 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 6.6
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z6.8 I-.402 J1.149 P1  F42000
G1 X114.557 Y105.443 Z6.8
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z7 I1.217 J0 P1  F42000
G1 X114.86 Y96.733
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.305 E.04241
G1 X116.518 Y94.86 E.05094
G1 X116.61 Y94.86 E.00274
G1 X119.14 Y97.39 E.10621
G1 X119.14 Y99.703 E.06868
G1 X114.86 Y100.85 E.13153
G1 X114.86 Y100.686 E.00487
G1 X119.14 Y104.965 E.17968
G1 X119.14 Y105.14 E.00519
G1 X115.972 Y105.14 E.09405
G1 X118.726 Y94.86 E.31597
G1 X119.14 Y94.86 E.01227
G1 X119.14 Y95.875 E.03013
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I-.332 J-1.171 P1  F42000
G1 X85.443 Y105.443 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
M73 P37 R20
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z7 I1.211 J-.121 P1  F42000
G1 X85.14 Y99.151 Z7
G1 Z6.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y97.723 E.04241
G1 X80.86 Y98.87 E.13153
G1 X80.86 Y96.985 E.05596
G1 X85.14 Y101.264 E.17968
G1 X85.14 Y103.268 E.05951
G1 X80.86 Y104.415 E.13153
G1 X80.86 Y104.56 E.0043
G1 X81.44 Y105.14 E.02435
G1 X82.701 Y105.14 E.03743
G1 X85.14 Y96.039 E.27974
G1 X85.14 Y94.86 E.03499
G1 X84.89 Y94.86 E.00742
; CHANGE_LAYER
; Z_HEIGHT: 6.67778
; LAYER_HEIGHT: 0.0777779
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7 I1.183 J.284 P1  F42000
G1 X85.715 Y91.429 Z7
G1 Z6.678
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z7.078 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z7.078
G1 Z6.678
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 6.8
; LAYER_HEIGHT: 0.122222
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z7.078
G1 Z6.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z7.2 I1.217 J0 P1  F42000
G1 X114.86 Y96.879
G1 Z6.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.451 E.04241
G1 X117.064 Y94.86 E.06774
G1 X116.81 Y94.86 E.00755
G1 X119.14 Y97.19 E.09782
G1 X119.14 Y99.85 E.07897
G1 X114.86 Y100.996 E.13153
G1 X114.86 Y100.486 E.01515
G1 X119.14 Y104.765 E.17968
G1 X119.14 Y105.14 E.01113
G1 X115.825 Y105.14 E.0984
G1 X118.58 Y94.86 E.31597
G1 X119.14 Y94.86 E.01662
G1 X119.14 Y95.729 E.02579
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I-.337 J-1.169 P1  F42000
G1 X85.443 Y105.443 Z7.2
G1 Z6.8
M73 P38 R20
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z7.2 I1.211 J-.124 P1  F42000
G1 X85.14 Y99.298 Z7.2
G1 Z6.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y97.87 E.04241
G1 X80.86 Y99.016 E.13153
G1 X80.86 Y96.785 E.06625
G1 X85.14 Y101.064 E.17968
G1 X85.14 Y103.415 E.0698
G1 X80.86 Y104.561 E.13153
G1 X80.86 Y104.36 E.00598
G1 X81.64 Y105.14 E.03275
G1 X82.555 Y105.14 E.02715
G1 X85.14 Y95.493 E.29653
G1 X85.14 Y94.86 E.01877
G1 X84.343 Y94.86 E.02364
; CHANGE_LAYER
; Z_HEIGHT: 6.97222
; LAYER_HEIGHT: 0.172222
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.2 I1.13 J.452 P1  F42000
G1 X85.715 Y91.429 Z7.2
G1 Z6.972
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z7.372 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z7.372
G1 Z6.972
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
M73 P38 R19
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 7
; LAYER_HEIGHT: 0.0277777
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z7.372
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z7.4 I1.217 J0 P1  F42000
G1 X114.86 Y97.026
G1 Z7
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.597 E.04241
G1 X117.611 Y94.86 E.08454
G1 X118.433 Y94.86 E.02443
G1 X115.679 Y105.14 E.31597
G1 X119.14 Y105.14 E.10275
M73 P39 R19
G1 X119.14 Y104.565 E.01707
G1 X114.86 Y100.286 E.17968
G1 X114.86 Y101.142 E.02544
G1 X119.14 Y99.996 E.13153
G1 X119.14 Y96.99 E.08925
G1 X117.01 Y94.86 E.08942
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I-.387 J-1.154 P1  F42000
G1 X85.443 Y105.443 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z7.4 I1.21 J-.127 P1  F42000
G1 X85.14 Y99.444 Z7.4
G1 Z7
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y98.016 E.04241
G1 X80.86 Y99.163 E.13153
G1 X80.86 Y96.585 E.07653
G1 X85.14 Y100.864 E.17968
G1 X85.14 Y103.561 E.08008
G1 X80.86 Y104.708 E.13153
G1 X80.86 Y104.16 E.01627
G1 X81.84 Y105.14 E.04115
G1 X82.408 Y105.14 E.01686
G1 X85.14 Y94.946 E.31333
G1 X85.14 Y94.86 E.00255
G1 X83.797 Y94.86 E.03986
; CHANGE_LAYER
; Z_HEIGHT: 7.2
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.4 I-.396 J1.151 P1  F42000
G1 X114.557 Y105.443 Z7.4
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z7.6 I1.217 J0 P1  F42000
G1 X114.86 Y97.172
G1 Z7.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y95.744 E.04241
G1 X118.157 Y94.86 E.10133
G1 X118.287 Y94.86 E.00386
G1 X115.533 Y105.14 E.31597
G1 X119.14 Y105.14 E.10709
G1 X119.14 Y104.365 E.023
G1 X114.86 Y100.086 E.17968
G1 X114.86 Y101.289 E.03572
G1 X119.14 Y100.142 E.13153
G1 X119.14 Y96.79 E.09954
G1 X117.21 Y94.86 E.08102
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I-.385 J-1.155 P1  F42000
G1 X85.443 Y105.443 Z7.6
G1 Z7.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y105.136 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y103.707 E.04241
G1 X80.86 Y104.854 E.13153
G1 X80.86 Y103.96 E.02656
G1 X82.04 Y105.14 E.04954
G1 X82.262 Y105.14 E.00658
G1 X85.016 Y94.86 E.31597
G1 X80.86 Y94.86 E.12339
G1 X80.86 Y96.385 E.04526
G1 X85.14 Y100.664 E.17968
G1 X85.14 Y98.162 E.07428
G1 X80.86 Y99.309 E.13153
G1 X80.86 Y100.737 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 7.26667
; LAYER_HEIGHT: 0.0666671
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.6 I1.079 J.563 P1  F42000
G1 X85.715 Y91.429 Z7.6
G1 Z7.267
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
M73 P40 R19
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z7.667 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z7.667
G1 Z7.267
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 7.4
; LAYER_HEIGHT: 0.133333
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z7.667
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z7.8 I1.217 J0 P1  F42000
G1 X119.14 Y101.717
G1 Z7.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y100.289 E.04241
G1 X114.86 Y101.435 E.13153
G1 X114.86 Y99.886 E.04601
G1 X119.14 Y104.165 E.17968
G1 X119.14 Y105.14 E.02894
G1 X115.386 Y105.14 E.11144
G1 X118.141 Y94.86 E.31597
M204 S500
G1 X115.982 Y94.86 F42000
G1 F1680.297
M204 S6000
G1 X117.41 Y94.86 E.04241
G1 X119.14 Y96.59 E.07262
G1 X119.14 Y94.86 E.05135
G1 X118.703 Y94.86 E.01295
G1 X114.86 Y95.89 E.11813
G1 X114.86 Y97.319 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I-.324 J-1.173 P1  F42000
G1 X85.443 Y105.443 Z7.8
G1 Z7.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.997 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y105.14 E.00424
G1 X85.14 Y103.854 E.03817
G1 X80.86 Y105 E.13153
G1 X80.86 Y103.76 E.03684
G1 X82.24 Y105.14 E.05794
G1 X82.115 Y105.14 E.00371
G1 X84.87 Y94.86 E.31597
G1 X80.86 Y94.86 E.11904
G1 X80.86 Y96.185 E.03932
G1 X85.14 Y100.464 E.17968
G1 X85.14 Y98.309 E.06399
G1 X80.86 Y99.455 E.13153
G1 X80.86 Y100.884 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 7.56111
; LAYER_HEIGHT: 0.161111
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z7.8 I1.083 J.556 P1  F42000
G1 X85.715 Y91.429 Z7.8
G1 Z7.561
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
M73 P41 R19
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z7.961 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z7.961
G1 Z7.561
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 7.6
; LAYER_HEIGHT: 0.0388889
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z7.961
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z8 I1.217 J0 P1  F42000
G1 X119.14 Y99.007
G1 Z7.6
M73 P41 R18
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y100.435 E.04241
G1 X114.86 Y101.582 E.13153
G1 X114.86 Y99.686 E.0563
G1 X119.14 Y103.965 E.17968
G1 X119.14 Y105.14 E.03488
G1 X115.24 Y105.14 E.11579
G1 X117.994 Y94.86 E.31597
G1 X117.61 Y94.86 E.0114
G1 X119.14 Y96.39 E.06422
G1 X119.14 Y94.89 E.04454
G1 X114.86 Y96.037 E.13153
G1 X114.86 Y94.86 E.03492
G1 X115.113 Y94.86 E.00749
G1 E-.8 F1800
M204 S500
G17
G3 Z8 I-.409 J-1.146 P1  F42000
G1 X85.443 Y105.443 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z8 I.361 J-1.162 P1  F42000
G1 X83.869 Y105.14 Z8
G1 Z7.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X82.44 Y105.14 E.04241
G1 X80.86 Y103.56 E.06634
G1 X80.86 Y105.14 E.04691
G1 X80.888 Y105.14 E.00081
G1 X85.14 Y104 E.13069
G1 X85.14 Y102.572 E.04241
M204 S500
G1 X81.969 Y105.14 F42000
G1 F1680.297
M204 S6000
G1 X84.723 Y94.86 E.31597
G1 X80.86 Y94.86 E.11469
M73 P42 R18
G1 X80.86 Y95.985 E.03338
G1 X85.14 Y100.264 E.17968
G1 X85.14 Y98.455 E.0537
G1 X80.86 Y99.602 E.13153
G1 X80.86 Y101.03 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 7.8
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8 I-.158 J1.207 P1  F42000
G1 X114.557 Y105.443 Z8
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z8.2 I1.217 J0 P1  F42000
G1 X119.14 Y99.153
G1 Z7.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y100.582 E.04241
G1 X114.86 Y101.728 E.13153
G1 X114.86 Y99.486 E.06658
G1 X119.14 Y103.765 E.17968
G1 X119.14 Y105.14 E.04082
G1 X115.093 Y105.14 E.12014
G1 X117.848 Y94.86 E.31597
G1 X117.81 Y94.86 E.00112
G1 X119.14 Y96.19 E.05583
G1 X119.14 Y95.036 E.03425
G1 X114.86 Y96.183 E.13153
G1 X114.86 Y94.86 E.03927
G1 X114.966 Y94.86 E.00314
G1 E-.8 F1800
M204 S500
G17
G3 Z8.2 I-.411 J-1.146 P1  F42000
G1 X85.443 Y105.443 Z8.2
G1 Z7.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.069 Y105.14 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X82.64 Y105.14 E.04241
G1 X80.86 Y103.36 E.07474
G1 X80.86 Y105.14 E.05285
G1 X81.434 Y105.14 E.01704
G1 X85.14 Y104.147 E.1139
G1 X85.14 Y102.718 E.04241
M204 S500
G1 X81.823 Y105.14 F42000
G1 F1680.297
M204 S6000
G1 X84.577 Y94.86 E.31597
G1 X80.86 Y94.86 E.11034
G1 X80.86 Y95.785 E.02745
G1 X85.14 Y100.064 E.17968
G1 X85.14 Y98.602 E.04342
G1 X80.86 Y99.748 E.13153
G1 X80.86 Y98.32 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 7.85556
; LAYER_HEIGHT: 0.0555553
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.2 I.995 J.701 P1  F42000
G1 X85.715 Y91.429 Z8.2
G1 Z7.856
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z8.256 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z8.256
G1 Z7.856
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
M73 P43 R18
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 8
; LAYER_HEIGHT: 0.144444
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z8.256
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z8.4 I1.217 J0 P1  F42000
G1 X119.14 Y99.3
G1 Z8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y100.728 E.04241
G1 X114.86 Y101.875 E.13153
G1 X114.86 Y99.286 E.07687
G1 X119.14 Y103.565 E.17968
G1 X119.14 Y105.14 E.04676
G1 X114.947 Y105.14 E.12448
G1 X117.701 Y94.86 E.31597
G1 X118.01 Y94.86 E.00917
G1 X119.14 Y95.99 E.04743
G1 X119.14 Y95.183 E.02396
G1 X114.86 Y96.329 E.13153
G1 X114.86 Y94.901 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8.4 I-.411 J-1.146 P1  F42000
G1 X85.443 Y105.443 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z8.4 I1.186 J-.272 P1  F42000
G1 X85.14 Y102.865 Z8.4
G1 Z8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.293 E.04241
G1 X81.981 Y105.14 E.0971
G1 X81.676 Y105.14 E.00904
G1 X84.43 Y94.86 E.31597
G1 X80.86 Y94.86 E.106
G1 X80.86 Y95.585 E.02151
G1 X85.14 Y99.864 E.17968
G1 X85.14 Y98.748 E.03313
G1 X80.86 Y99.895 E.13153
G1 X80.86 Y103.16 E.09695
G1 X82.84 Y105.14 E.08314
; CHANGE_LAYER
; Z_HEIGHT: 8.15
; LAYER_HEIGHT: 0.15
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.4 I1.191 J.25 P1  F42000
G1 X85.715 Y91.429 Z8.4
G1 Z8.15
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z8.55 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z8.55
G1 Z8.15
M73 P44 R18
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 8.2
; LAYER_HEIGHT: 0.0500002
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z8.55
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z8.6 I1.217 J0 P1  F42000
G1 X116.065 Y105.14
G1 Z8.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.03577
G1 X114.86 Y104.916 E.00664
G1 X117.555 Y94.86 E.3091
G1 X118.21 Y94.86 E.01945
G1 X119.14 Y95.79 E.03903
G1 X119.14 Y95.329 E.01368
G1 X114.86 Y96.476 E.13153
G1 X114.86 Y99.086 E.07749
G1 X119.14 Y103.365 E.17968
G1 X119.14 Y100.874 E.07394
G1 X114.86 Y102.021 E.13153
G1 X114.86 Y100.593 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8.6 I-.198 J-1.201 P1  F42000
G1 X85.443 Y105.443 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z8.6 I1.183 J-.286 P1  F42000
G1 X85.14 Y103.011 Z8.6
G1 Z8.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.44 E.04241
G1 X82.527 Y105.14 E.08031
G1 X81.53 Y105.14 E.02961
G1 X84.284 Y94.86 E.31597
G1 X80.86 Y94.86 E.10165
G1 X80.86 Y95.385 E.01557
G1 X85.14 Y99.664 E.17968
G1 X85.14 Y98.894 E.02285
G1 X80.86 Y100.041 E.13153
G1 X80.86 Y102.96 E.08666
M73 P44 R17
G1 X83.04 Y105.14 E.09153
; CHANGE_LAYER
; Z_HEIGHT: 8.4
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.6 I-.012 J1.217 P1  F42000
G1 X114.557 Y105.443 Z8.6
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z8.8 I1.217 J0 P1  F42000
G1 X115.519 Y105.14
G1 Z8.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.01955
G1 X114.86 Y104.37 E.02286
G1 X117.408 Y94.86 E.2923
G1 X118.41 Y94.86 E.02974
G1 X119.14 Y95.59 E.03063
G1 X119.14 Y95.476 E.00339
G1 X114.86 Y96.622 E.13153
G1 X114.86 Y98.886 E.06721
M73 P45 R17
G1 X119.14 Y103.165 E.17968
G1 X119.14 Y101.021 E.06366
G1 X114.86 Y102.167 E.13153
G1 X114.86 Y100.739 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z8.8 I-.192 J-1.202 P1  F42000
G1 X85.443 Y105.443 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z8.8 I1.179 J-.302 P1  F42000
G1 X85.14 Y103.158 Z8.8
G1 Z8.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.586 E.04241
G1 X83.073 Y105.14 E.06351
G1 X83.24 Y105.14 E.00496
G1 X80.86 Y102.76 E.09993
G1 X80.86 Y100.187 E.07637
G1 X85.14 Y99.041 E.13153
G1 X85.14 Y99.464 E.01256
G1 X80.86 Y95.185 E.17968
G1 X80.86 Y94.86 E.00963
G1 X84.138 Y94.86 E.0973
G1 X81.383 Y105.14 E.31597
G1 X80.86 Y105.14 E.01553
G1 X80.86 Y104.234 E.02688
; CHANGE_LAYER
; Z_HEIGHT: 8.44444
; LAYER_HEIGHT: 0.044445
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z8.8 I1.138 J.431 P1  F42000
G1 X85.715 Y91.429 Z8.8
G1 Z8.444
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z8.844 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z8.844
G1 Z8.444
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 8.6
; LAYER_HEIGHT: 0.155556
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z8.844
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
M73 P46 R17
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z9 I1.217 J0 P1  F42000
G1 X114.972 Y105.14
G1 Z8.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y105.14 E.00333
G1 X114.86 Y103.823 E.03908
G1 X117.262 Y94.86 E.2755
G1 X118.61 Y94.86 E.04002
G1 X119.14 Y95.39 E.02223
G1 X119.14 Y95.622 E.00689
G1 X114.86 Y96.769 E.13153
G1 X114.86 Y98.686 E.05692
G1 X119.14 Y102.965 E.17968
G1 X119.14 Y101.167 E.05337
G1 X114.86 Y102.314 E.13153
G1 X114.86 Y100.885 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9 I-.186 J-1.203 P1  F42000
G1 X85.443 Y105.443 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z9 I1.175 J-.318 P1  F42000
G1 X85.14 Y103.304 Z9
G1 Z8.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.732 E.04241
G1 X83.62 Y105.14 E.04671
G1 X83.44 Y105.14 E.00533
G1 X80.86 Y102.56 E.10833
G1 X80.86 Y100.334 E.06609
G1 X85.14 Y99.187 E.13153
G1 X85.14 Y99.264 E.00228
G1 X80.86 Y94.985 E.17968
G1 X80.86 Y94.86 E.00369
G1 X83.991 Y94.86 E.09296
G1 X81.237 Y105.14 E.31597
G1 X80.86 Y105.14 E.01118
G1 X80.86 Y104.088 E.03123
; CHANGE_LAYER
; Z_HEIGHT: 8.73889
; LAYER_HEIGHT: 0.138888
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9 I1.136 J.436 P1  F42000
G1 X85.715 Y91.429 Z9
G1 Z8.739
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z9.139 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z9.139
G1 Z8.739
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 8.8
; LAYER_HEIGHT: 0.0611115
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z9.139
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
M73 P47 R17
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z9.2 I1.217 J0 P1  F42000
G1 X114.86 Y104.705
G1 Z8.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y103.277 E.04241
G1 X117.116 Y94.86 E.25871
G1 X118.81 Y94.86 E.05031
G1 X119.14 Y95.19 E.01384
G1 X119.14 Y95.768 E.01718
G1 X114.86 Y96.915 E.13153
G1 X114.86 Y98.486 E.04663
G1 X119.14 Y102.765 E.17968
G1 X119.14 Y101.314 E.04309
G1 X114.86 Y102.46 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z9.2 I-.123 J-1.211 P1  F42000
G1 X85.443 Y105.443 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z9.2 I1.169 J-.337 P1  F42000
G1 X85.14 Y103.45 Z9.2
G1 Z8.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.879 E.04241
G1 X84.166 Y105.14 E.02992
G1 X83.64 Y105.14 E.01561
G1 X80.86 Y102.36 E.11673
G1 X80.86 Y100.48 E.0558
G1 X85.14 Y99.334 E.13153
G1 X85.14 Y99.064 E.00801
G1 X80.936 Y94.86 E.1765
G1 X83.845 Y94.86 E.08636
G1 X81.091 Y105.14 E.31597
G1 X80.86 Y105.14 E.00683
G1 X80.86 Y103.941 E.03558
; CHANGE_LAYER
; Z_HEIGHT: 9
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.2 I-.054 J1.216 P1  F42000
G1 X114.557 Y105.443 Z9.2
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z9.4 I1.217 J0 P1  F42000
G1 X119.14 Y97.343
G1 Z9
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y95.915 E.04241
G1 X114.86 Y97.061 E.13153
G1 X114.86 Y98.286 E.03635
G1 X119.14 Y102.565 E.17968
G1 X119.14 Y101.46 E.0328
G1 X114.86 Y102.607 E.13153
G1 X114.86 Y102.73 E.00367
G1 X116.969 Y94.86 E.24191
G1 X115.541 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9.4 I-.404 J-1.148 P1  F42000
G1 X85.443 Y105.443 Z9.4
G1 Z9
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
M73 P47 R16
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y105.01 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y105.14 E.00383
G1 X83.84 Y105.14 E.03857
G1 X80.86 Y102.16 E.12513
G1 X80.86 Y100.627 E.04552
G1 X85.14 Y99.48 E.13153
G1 X85.14 Y98.864 E.01829
G1 X81.136 Y94.86 E.16811
G1 X80.86 Y94.86 E.00818
G1 X80.86 Y95.081 E.00656
G1 X81.685 Y94.86 E.02535
G1 X83.698 Y94.86 E.05977
G1 X80.944 Y105.14 E.31597
G1 X82.372 Y105.14 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 9.03333
; LAYER_HEIGHT: 0.0333338
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.4 I1.182 J.288 P1  F42000
G1 X85.715 Y91.429 Z9.4
G1 Z9.033
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
M73 P48 R16
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z9.433 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z9.433
G1 Z9.033
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 9.2
; LAYER_HEIGHT: 0.166666
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z9.433
G1 Z9.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z9.6 I1.217 J0 P1  F42000
G1 X119.14 Y97.49
G1 Z9.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y96.061 E.04241
G1 X114.86 Y97.208 E.13153
G1 X114.86 Y98.086 E.02606
G1 X119.14 Y102.365 E.17968
G1 X119.14 Y101.606 E.02252
G1 X114.86 Y102.753 E.13153
G1 X114.86 Y102.184 E.0169
G1 X116.823 Y94.86 E.22511
G1 X115.394 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9.6 I-.405 J-1.147 P1  F42000
G1 X85.443 Y105.443 Z9.6
G1 Z9.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z9.6 I1.069 J-.581 P1  F42000
G1 X80.86 Y96.656 Z9.6
G1 Z9.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y95.228 E.04241
G1 X82.232 Y94.86 E.04215
G1 X83.552 Y94.86 E.0392
G1 X80.86 Y104.905 E.30877
G1 X80.86 Y105.14 E.00695
G1 X84.04 Y105.14 E.09441
G1 X80.86 Y101.96 E.13352
G1 X80.86 Y100.773 E.03523
M73 P49 R16
G1 X85.14 Y99.626 E.13153
G1 X85.14 Y98.664 E.02858
G1 X81.336 Y94.86 E.15971
; CHANGE_LAYER
; Z_HEIGHT: 9.32778
; LAYER_HEIGHT: 0.127778
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.6 I.751 J.958 P1  F42000
G1 X85.715 Y91.429 Z9.6
G1 Z9.328
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z9.728 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z9.728
G1 Z9.328
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 9.4
; LAYER_HEIGHT: 0.0722218
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z9.728
G1 Z9.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z9.8 I1.217 J0 P1  F42000
G1 X119.14 Y97.636
G1 Z9.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y96.208 E.04241
G1 X114.86 Y97.354 E.13153
G1 X114.86 Y97.886 E.01578
G1 X119.14 Y102.165 E.17968
G1 X119.14 Y101.753 E.01223
G1 X114.86 Y102.899 E.13153
G1 X114.86 Y101.638 E.03747
G1 X116.676 Y94.86 E.20832
G1 X115.248 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z9.8 I-.407 J-1.147 P1  F42000
G1 X85.443 Y105.443 Z9.8
G1 Z9.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y104.61 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
M73 P50 R16
G1 F1680.297
M204 S6000
G1 X85.14 Y105.14 E.01571
G1 X84.24 Y105.14 E.0267
G1 X80.86 Y101.76 E.14192
G1 X80.86 Y100.919 E.02495
G1 X85.14 Y99.773 E.13153
G1 X85.14 Y98.464 E.03886
G1 X81.536 Y94.86 E.15131
G1 X80.86 Y94.86 E.02006
G1 X80.86 Y95.374 E.01526
G1 X82.778 Y94.86 E.05895
G1 X83.406 Y94.86 E.01863
G1 X80.86 Y104.359 E.29197
G1 X80.86 Y105.14 E.02318
G1 X81.508 Y105.14 E.01923
; CHANGE_LAYER
; Z_HEIGHT: 9.6
; LAYER_HEIGHT: 0.200001
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z9.8 I-.011 J1.217 P1  F42000
G1 X114.557 Y105.443 Z9.8
G1 Z9.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z10 I1.217 J0 P1  F42000
G1 X119.14 Y97.782
G1 Z9.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y96.354 E.04241
G1 X114.86 Y97.501 E.13153
G1 X114.86 Y97.686 E.00549
G1 X119.14 Y101.965 E.17968
G1 X119.14 Y101.899 E.00195
G1 X114.86 Y103.046 E.13153
G1 X114.86 Y101.091 E.05804
G1 X116.53 Y94.86 E.19152
G1 X115.102 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10 I-.409 J-1.146 P1  F42000
G1 X85.443 Y105.443 Z10
G1 Z9.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.14 Y104.41 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y105.14 E.02165
G1 X84.44 Y105.14 E.02076
G1 X80.86 Y101.56 E.15032
G1 X80.86 Y101.066 E.01466
G1 X85.14 Y99.919 E.13153
G1 X85.14 Y98.264 E.04915
G1 X81.736 Y94.86 E.14291
G1 X80.86 Y94.86 E.026
G1 X80.86 Y95.521 E.0196
G1 X83.325 Y94.86 E.07574
G1 X83.259 Y94.86 E.00194
G1 X80.86 Y103.813 E.27518
G1 X80.86 Y105.14 E.0394
G1 X80.962 Y105.14 E.00301
; CHANGE_LAYER
; Z_HEIGHT: 9.62222
; LAYER_HEIGHT: 0.0222216
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10 I1.15 J.399 P1  F42000
G1 X85.715 Y91.429 Z10
G1 Z9.622
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E1.17801
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X102.689 Y94.286 E.44459
G1 X102.689 Y93.811 E.01956
G1 X97.311 Y93.811 E.2217
G1 X97.311 Y94.286 E.01956
G1 X86.529 Y94.286 E.44459
G1 X86.529 Y97.143 E.1178
G1 X97.311 Y97.143 E.44459
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z10.022 I1.095 J.532 P1  F42000
G1 X102.689 Y94.464 Z10.022
G1 Z9.622
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X102.689 Y97.143 E.11044
G1 X113.471 Y97.143 E.44459
M73 P50 R15
G1 X113.471 Y100 E.1178
G1 X102.689 Y100 E.44459
G1 X102.689 Y102.857 E.1178
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
M73 P51 R15
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
; CHANGE_LAYER
; Z_HEIGHT: 9.8
; LAYER_HEIGHT: 0.177778
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z10.022
G1 Z9.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z10.2 I1.217 J0 P1  F42000
G1 X119.14 Y97.929
G1 Z9.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.14 Y96.501 E.04241
G1 X114.86 Y97.647 E.13153
G1 X114.86 Y97.486 E.00479
G1 X119.14 Y101.765 E.17968
G1 X119.14 Y102.046 E.00834
G1 X114.86 Y103.192 E.13153
G1 X114.86 Y100.545 E.07861
G1 X116.384 Y94.86 E.17473
G1 X117.812 Y94.86 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10.2 I-.378 J-1.157 P1  F42000
G1 X85.443 Y105.443 Z10.2
G1 Z9.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z10.2 I1.215 J-.075 P1  F42000
G1 X85.14 Y95.02 Z10.2
G1 Z9.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y94.86 E.00474
G1 X83.871 Y94.86 E.03767
G1 X80.86 Y95.667 E.09254
G1 X80.86 Y94.86 E.02395
G1 X81.936 Y94.86 E.03194
G1 X85.14 Y98.064 E.13451
G1 X85.14 Y100.066 E.05943
G1 X80.86 Y101.212 E.13153
G1 X80.86 Y101.36 E.00438
G1 X84.64 Y105.14 E.15872
G1 X80.86 Y105.14 E.11223
G1 X80.86 Y103.266 E.05562
G1 X83.113 Y94.86 E.25838
; CHANGE_LAYER
; Z_HEIGHT: 9.91667
; LAYER_HEIGHT: 0.116667
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.2 I.97 J.735 P1  F42000
G1 X85.715 Y91.429 Z10.2
G1 Z9.917
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X91.072 Y91.429 E.22087
G1 X91.072 Y94.286 E.1178
G1 X86.529 Y94.286 E.18731
G1 X86.529 Y97.143 E.1178
G1 X91.072 Y97.143 E.18731
G1 X91.072 Y97.5 E.01473
G1 X94.643 Y97.5 E.14726
G1 X94.643 Y97.143 E.01473
G1 X97.311 Y97.143 E.11002
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z10.317 I.83 J.89 P1  F42000
G1 X103.25 Y100 Z10.317
G1 Z9.917
G1 E.8 F1800
; FEATURE: Support transition
G1 F1210.015
M204 S6000
G1 X102.857 Y100 E.0162
G1 X102.857 Y91.429 E.35342
G1 X103.428 Y91.429 E.02356
G1 X103.428 Y100 E.35342
G1 X104.285 Y100 E.03534
G1 X104.285 Y91.429 E.35342
G1 X105.142 Y91.429 E.03534
G1 X105.142 Y100 E.35342
G1 X105.999 Y100 E.03534
G1 X105.999 Y91.429 E.35342
G1 X106.857 Y91.429 E.03534
G1 X106.857 Y100 E.35342
G1 X107.714 Y100 E.03534
G1 X107.714 Y91.429 E.35342
M73 P52 R15
G1 X108.571 Y91.429 E.03534
G1 X108.571 Y100 E.35342
G1 X109.428 Y100 E.03534
G1 X109.428 Y91.429 E.35342
G1 X110.285 Y91.429 E.03534
G1 X110.285 Y100 E.35342
G1 X111.142 Y100 E.03534
G1 X111.142 Y91.429 E.35342
G1 X111.429 Y91.429 E.01182
G1 X111.429 Y100 E.35342
G1 X111.32 Y100 E.00446
M204 S500
G1 X111.786 Y91.429 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E.10308
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X111.786 Y94.286 E.06951
G1 X111.786 Y97.143 E.1178
G1 X113.471 Y97.143 E.06951
G1 X113.471 Y100 E.1178
G1 X111.786 Y100 E.06951
G1 X111.786 Y100.357 E.01473
G1 X102.689 Y100.357 E.37508
G1 X102.689 Y102.857 E.10307
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
G1 E-.8 F1800
M204 S500
G17
G3 Z10.317 I.619 J-1.048 P1  F42000
G1 X94.643 Y96.964 Z10.317
G1 Z9.917
G1 E.8 F1800
G1 F1210.015
M204 S6000
G1 X94.643 Y94.286 E.11044
G1 X97.311 Y94.286 E.11002
G1 X97.311 Y93.811 E.01956
G1 X102.5 Y93.811 E.21392
G1 X102.5 Y91.429 E.09824
G1 X94.643 Y91.429 E.32395
M204 S500
G1 X94.286 Y92.03 F42000
; FEATURE: Support transition
G1 F1210.015
M204 S6000
G1 X94.286 Y91.429 E.0248
G1 X94.001 Y91.429 E.01178
G1 X94.001 Y97.143 E.23562
G1 X93.143 Y97.143 E.03534
G1 X93.143 Y91.429 E.23562
G1 X92.286 Y91.429 E.03534
G1 X92.286 Y97.143 E.23562
G1 X91.429 Y97.143 E.03534
G1 X91.429 Y91.429 E.23562
; CHANGE_LAYER
; Z_HEIGHT: 10
; LAYER_HEIGHT: 0.083333
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z10.317
G1 Z10
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z10.4 I1.217 J0 P1  F42000
G1 X116.568 Y105.14
G1 Z10
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.14 Y105.14 E.04241
G1 X114.86 Y104.861 E.01172
G1 X114.86 Y103.339 E.04519
G1 X119.14 Y102.192 E.13153
G1 X119.14 Y101.565 E.01863
G1 X114.86 Y97.286 E.17968
G1 X114.86 Y97.794 E.01508
G1 X119.14 Y96.647 E.13153
G1 X119.14 Y94.86 E.05304
G1 X116.237 Y94.86 E.08618
G1 X114.86 Y99.998 E.15793
G1 X114.86 Y101.427 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10.4 I-.165 J-1.206 P1  F42000
G1 X85.443 Y105.443 Z10.4
G1 Z10
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z10.4 I.297 J-1.18 P1  F42000
G1 X83.412 Y105.14 Z10.4
G1 Z10
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X84.84 Y105.14 E.04241
G1 X80.86 Y101.16 E.16711
M73 P53 R15
G1 X80.86 Y101.359 E.00591
G1 X85.14 Y100.212 E.13153
G1 X85.14 Y97.864 E.06972
G1 X82.136 Y94.86 E.12612
G1 X82.966 Y94.86 E.02465
G1 X80.86 Y102.72 E.24159
G1 X80.86 Y104.148 E.04241
M204 S500
G1 X80.86 Y97.242 F42000
G1 F1680.297
M204 S6000
G1 X80.86 Y95.814 E.04241
G1 X84.417 Y94.86 E.10933
G1 X85.14 Y94.86 E.02144
G1 X85.14 Y95.567 E.02096
; CHANGE_LAYER
; Z_HEIGHT: 10.2
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.4 I-.387 J1.154 P1  F42000
G1 X114.557 Y105.443 Z10.4
G1 Z10.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z10.6 I1.217 J0 P1  F42000
G1 X114.86 Y100.88
G1 Z10.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y99.452 E.04241
G1 X116.091 Y94.86 E.14114
G1 X119.14 Y94.86 E.09052
G1 X119.14 Y96.793 E.05739
G1 X114.86 Y97.94 E.13153
G1 X114.86 Y97.086 E.02536
G1 X119.14 Y101.365 E.17968
G1 X119.14 Y102.338 E.02891
G1 X114.86 Y103.485 E.13153
G1 X114.86 Y104.661 E.0349
G1 X115.34 Y105.14 E.02011
G1 X118.882 Y105.14 E.10517
G1 X119.14 Y104.177 E.02959
G1 X119.14 Y102.749 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z10.6 I-.097 J-1.213 P1  F42000
G1 X85.443 Y105.443 Z10.6
G1 Z10.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z10.6 I.792 J-.924 P1  F42000
G1 X80.86 Y101.505 Z10.6
G1 Z10.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y100.358 E.13153
G1 X85.14 Y97.664 E.08
G1 X82.336 Y94.86 E.11772
G1 X82.82 Y94.86 E.01437
G1 X80.86 Y102.173 E.22479
G1 X80.86 Y105.14 E.08807
G1 X85.04 Y105.14 E.12411
G1 X80.86 Y100.96 E.17551
G1 X80.86 Y95.96 E.14845
G1 X84.964 Y94.86 E.12613
G1 X85.14 Y94.86 E.00522
G1 X85.14 Y96.113 E.03719
; CHANGE_LAYER
; Z_HEIGHT: 10.2111
; LAYER_HEIGHT: 0.0111113
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z10.6 I1.208 J.148 P1  F42000
G1 X85.715 Y91.429 Z10.6
G1 Z10.211
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X91.072 Y91.429 E.22087
G1 X91.072 Y94.286 E.1178
G1 X86.529 Y94.286 E.18731
G1 X86.529 Y97.143 E.1178
G1 X91.072 Y97.143 E.18731
G1 X91.072 Y97.5 E.01473
G1 X94.643 Y97.5 E.14726
G1 X94.643 Y97.143 E.01473
G1 X97.311 Y97.143 E.11002
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z10.611 I.803 J.914 P1  F42000
G1 X103.428 Y100.161 Z10.611
G1 Z10.211
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X103.428 Y91.429 E.36004
G1 X104.285 Y91.429 E.03534
G1 X104.285 Y100 E.35342
G1 X105.142 Y100 E.03534
G1 X105.142 Y91.429 E.35342
G1 X105.999 Y91.429 E.03534
G1 X105.999 Y100 E.35342
G1 X106.857 Y100 E.03534
G1 X106.857 Y91.429 E.35342
G1 X107.714 Y91.429 E.03534
G1 X107.714 Y100 E.35342
G1 X108.571 Y100 E.03534
G1 X108.571 Y91.429 E.35342
M73 P53 R14
G1 X109.428 Y91.429 E.03534
G1 X109.428 Y100 E.35342
G1 X110.285 Y100 E.03534
M73 P54 R14
G1 X110.285 Y91.429 E.35342
G1 X111.142 Y91.429 E.03534
G1 X111.142 Y100.161 E.36004
M204 S500
G1 X111.786 Y91.429 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E.10308
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X111.786 Y94.286 E.06951
G1 X111.786 Y97.143 E.1178
G1 X113.471 Y97.143 E.06951
G1 X113.471 Y100 E.1178
G1 X111.786 Y100 E.06951
G1 X111.786 Y100.357 E.01473
G1 X102.689 Y100.357 E.37508
G1 X102.689 Y102.857 E.10307
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
G1 E-.8 F1800
M204 S500
G17
G3 Z10.611 I.538 J-1.092 P1  F42000
G1 X91.429 Y97.304 Z10.611
G1 Z10.211
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X91.429 Y91.429 E.24224
G1 X92.286 Y91.429 E.03534
G1 X92.286 Y97.143 E.23562
G1 X93.143 Y97.143 E.03534
G1 X93.143 Y91.429 E.23562
G1 X94.001 Y91.429 E.03534
G1 X94.001 Y97.304 E.24224
M204 S500
G1 X94.643 Y96.964 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X94.643 Y94.286 E.11044
G1 X97.311 Y94.286 E.11002
G1 X97.311 Y93.811 E.01956
G1 X102.5 Y93.811 E.21392
G1 X102.5 Y91.429 E.09824
G1 X94.643 Y91.429 E.32395
; CHANGE_LAYER
; Z_HEIGHT: 10.4
; LAYER_HEIGHT: 0.188889
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z10.611
G1 Z10.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z10.8 I1.217 J0 P1  F42000
G1 X116.968 Y105.14
G1 Z10.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.54 Y105.14 E.04241
G1 X114.86 Y104.46 E.02851
G1 X114.86 Y103.631 E.02461
G1 X119.14 Y102.485 E.13153
G1 X119.14 Y103.631 E.03402
G1 X118.735 Y105.14 E.04638
G1 X117.307 Y105.14 E.04241
M204 S500
G1 X114.86 Y100.334 F42000
G1 F1680.297
M204 S6000
G1 X114.86 Y98.905 E.04241
G1 X115.944 Y94.86 E.12434
G1 X114.86 Y94.86 E.03218
G1 X114.86 Y96.886 E.06013
G1 X119.14 Y101.165 E.17968
G1 X119.14 Y96.94 E.12545
G1 X114.86 Y98.086 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z10.8 I-.295 J-1.181 P1  F42000
G1 X85.443 Y105.443 Z10.8
G1 Z10.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z10.8 I.864 J-.857 P1  F42000
G1 X80.86 Y100.76 Z10.8
G1 Z10.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y105.039 E.17968
G1 X85.14 Y100.505 E.13461
G1 X80.86 Y101.651 E.13153
G1 X80.86 Y101.627 E.00073
G1 X82.674 Y94.86 E.20799
G1 X82.536 Y94.86 E.00408
G1 X85.14 Y97.464 E.10932
G1 X85.14 Y94.96 E.07435
G1 X80.86 Y96.106 E.13153
G1 X80.86 Y97.535 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 10.5056
; LAYER_HEIGHT: 0.105556
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
M73 P55 R14
G3 Z10.8 I.953 J.757 P1  F42000
G1 X85.715 Y91.429 Z10.8
G1 Z10.506
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X91.072 Y91.429 E.22087
G1 X91.072 Y94.286 E.1178
G1 X86.529 Y94.286 E.18731
G1 X86.529 Y97.143 E.1178
G1 X91.072 Y97.143 E.18731
G1 X91.072 Y97.5 E.01473
G1 X94.643 Y97.5 E.14726
G1 X94.643 Y97.143 E.01473
G1 X97.311 Y97.143 E.11002
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z10.906 I.803 J.914 P1  F42000
G1 X103.428 Y100.161 Z10.906
G1 Z10.506
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X103.428 Y91.429 E.36004
G1 X104.285 Y91.429 E.03534
G1 X104.285 Y100 E.35342
G1 X105.142 Y100 E.03534
G1 X105.142 Y91.429 E.35342
G1 X105.999 Y91.429 E.03534
G1 X105.999 Y100 E.35342
G1 X106.857 Y100 E.03534
G1 X106.857 Y91.429 E.35342
G1 X107.714 Y91.429 E.03534
G1 X107.714 Y100 E.35342
G1 X108.571 Y100 E.03534
G1 X108.571 Y91.429 E.35342
G1 X109.428 Y91.429 E.03534
G1 X109.428 Y100 E.35342
G1 X110.285 Y100 E.03534
G1 X110.285 Y91.429 E.35342
G1 X111.142 Y91.429 E.03534
G1 X111.142 Y100.161 E.36004
M204 S500
G1 X111.786 Y91.429 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E.10308
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X111.786 Y94.286 E.06951
G1 X111.786 Y97.143 E.1178
G1 X113.471 Y97.143 E.06951
G1 X113.471 Y100 E.1178
G1 X111.786 Y100 E.06951
G1 X111.786 Y100.357 E.01473
G1 X102.689 Y100.357 E.37508
G1 X102.689 Y102.857 E.10307
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
G1 E-.8 F1800
M204 S500
G17
G3 Z10.906 I.538 J-1.092 P1  F42000
G1 X91.429 Y97.304 Z10.906
G1 Z10.506
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X91.429 Y91.429 E.24224
G1 X92.286 Y91.429 E.03534
G1 X92.286 Y97.143 E.23562
G1 X93.143 Y97.143 E.03534
G1 X93.143 Y91.429 E.23562
G1 X94.001 Y91.429 E.03534
G1 X94.001 Y97.304 E.24224
M204 S500
G1 X94.643 Y96.964 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X94.643 Y94.286 E.11044
G1 X97.311 Y94.286 E.11002
G1 X97.311 Y93.811 E.01956
G1 X102.5 Y93.811 E.21392
G1 X102.5 Y91.429 E.09824
G1 X94.643 Y91.429 E.32395
; CHANGE_LAYER
; Z_HEIGHT: 10.6
; LAYER_HEIGHT: 0.0944452
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z10.906
G1 Z10.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
M73 P56 R14
G1 E-.8 F1800
G17
G3 Z11 I1.217 J0 P1  F42000
G1 X117.168 Y105.14
G1 Z10.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.74 Y105.14 E.04241
G1 X114.86 Y104.261 E.03691
G1 X114.86 Y103.778 E.01433
G1 X119.14 Y102.631 E.13153
G1 X119.14 Y103.084 E.01344
G1 X118.589 Y105.14 E.06318
G1 X119.14 Y105.14 E.01635
G1 X119.14 Y104.262 E.02606
M204 S500
G1 X119.14 Y99.536 F42000
G1 F1680.297
M204 S6000
G1 X119.14 Y100.965 E.04241
G1 X114.86 Y96.686 E.17968
G1 X114.86 Y94.86 E.05419
G1 X115.798 Y94.86 E.02783
G1 X114.86 Y98.359 E.10754
G1 X114.86 Y98.233 E.00375
G1 X119.14 Y97.086 E.13153
G1 X119.14 Y95.658 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11 I-.339 J-1.169 P1  F42000
G1 X85.443 Y105.443 Z11
G1 Z10.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z11 I.881 J-.84 P1  F42000
G1 X80.86 Y100.56 Z11
G1 Z10.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.14 Y104.839 E.17968
G1 X85.14 Y100.651 E.12433
G1 X80.86 Y101.798 E.13153
G1 X80.86 Y101.081 E.0213
G1 X82.527 Y94.86 E.1912
G1 X82.736 Y94.86 E.0062
G1 X85.14 Y97.264 E.10092
G1 X85.14 Y95.106 E.06407
G1 X80.86 Y96.253 E.13153
G1 X80.86 Y97.681 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 10.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11 I.961 J.746 P1  F42000
G1 X85.715 Y91.429 Z11
G1 Z10.8
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.294444
G1 F1210.015
M204 S6000
G1 X91.072 Y91.429 E.22087
G1 X91.072 Y94.286 E.1178
G1 X86.529 Y94.286 E.18731
G1 X86.529 Y97.143 E.1178
G1 X91.072 Y97.143 E.18731
G1 X91.072 Y97.5 E.01473
G1 X94.643 Y97.5 E.14726
G1 X94.643 Y97.143 E.01473
G1 X97.311 Y97.143 E.11002
G1 X97.311 Y100 E.1178
G1 X86.529 Y100 E.44459
G1 X86.529 Y102.857 E.1178
G1 X97.311 Y102.857 E.44459
G1 X97.311 Y105.536 E.11044
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I.803 J.914 P1  F42000
G1 X103.428 Y100.161 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X103.428 Y91.429 E.36004
G1 X104.285 Y91.429 E.03534
G1 X104.285 Y100 E.35341
G1 X105.142 Y100 E.03534
G1 X105.142 Y91.429 E.35341
G1 X105.999 Y91.429 E.03534
G1 X105.999 Y100 E.35341
G1 X106.857 Y100 E.03534
G1 X106.857 Y91.429 E.35341
G1 X107.714 Y91.429 E.03534
G1 X107.714 Y100 E.35341
G1 X108.571 Y100 E.03534
G1 X108.571 Y91.429 E.35341
G1 X109.428 Y91.429 E.03534
G1 X109.428 Y100 E.35341
G1 X110.285 Y100 E.03534
G1 X110.285 Y91.429 E.35341
G1 X111.142 Y91.429 E.03534
G1 X111.142 Y100.161 E.36004
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I1.214 J.089 P1  F42000
G1 X111.786 Y91.429 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X114.286 Y91.429 E.10308
G1 X114.286 Y93.471 E.08422
G1 X113.781 Y93.471 E.0208
G1 X113.471 Y93.781 E.01805
G1 X113.471 Y94.286 E.02081
G1 X111.786 Y94.286 E.06951
G1 X111.786 Y97.143 E.1178
G1 X113.471 Y97.143 E.06951
G1 X113.471 Y100 E.1178
G1 X111.786 Y100 E.06951
G1 X111.786 Y100.357 E.01473
G1 X102.689 Y100.357 E.37508
G1 X102.689 Y102.857 E.10307
G1 X113.471 Y102.857 E.44459
G1 X113.471 Y105.714 E.1178
G1 X102.689 Y105.714 E.44459
G1 X102.689 Y106.189 E.01956
G1 X97.311 Y106.189 E.2217
G1 X97.311 Y105.714 E.01956
M73 P57 R14
G1 X86.529 Y105.714 E.44459
G1 X86.529 Y106.219 E.02081
M73 P57 R13
G1 X86.219 Y106.529 E.01805
G1 X85.715 Y106.529 E.02079
G1 X85.715 Y108.571 E.08422
G1 X114.286 Y108.571 E1.17801
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I.538 J-1.092 P1  F42000
G1 X91.429 Y97.304 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Support interface
G1 F1210.015
M204 S6000
G1 X91.429 Y91.429 E.24224
G1 X92.286 Y91.429 E.03534
G1 X92.286 Y97.143 E.23561
G1 X93.143 Y97.143 E.03534
G1 X93.143 Y91.429 E.23561
G1 X94.001 Y91.429 E.03534
G1 X94.001 Y97.304 E.24224
M204 S500
G1 X94.643 Y96.964 F42000
; FEATURE: Support
G1 F1210.015
M204 S6000
G1 X94.643 Y94.286 E.11044
G1 X97.311 Y94.286 E.11002
G1 X97.311 Y93.811 E.01956
G1 X102.5 Y93.811 E.21392
G1 X102.5 Y91.429 E.09824
G1 X94.643 Y91.429 E.32395
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I-.7 J.995 P1  F42000
G1 X114.557 Y105.443 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z11.2 I1.217 J0 P1  F42000
G1 X117.368 Y105.14
G1 Z10.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.94 Y105.14 E.04241
G1 X114.86 Y104.061 E.04531
G1 X114.86 Y103.924 E.00404
G1 X119.14 Y102.778 E.13153
G1 X119.14 Y102.538 E.00713
G1 X118.442 Y105.14 E.07998
G1 X119.14 Y105.14 E.0207
G1 X119.14 Y104.408 E.02171
M204 S500
G1 X119.14 Y99.336 F42000
G1 F1680.297
M204 S6000
G1 X119.14 Y100.765 E.04241
G1 X114.86 Y96.486 E.17968
G1 X114.86 Y94.86 E.04826
G1 X115.652 Y94.86 E.02349
G1 X114.86 Y97.813 E.09075
G1 X114.86 Y98.379 E.01682
G1 X119.14 Y97.233 E.13153
G1 X119.14 Y95.804 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I-.335 J-1.17 P1  F42000
G1 X85.443 Y105.443 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z11.2 I.526 J-1.097 P1  F42000
G1 X80.86 Y103.373 Z11.2
G1 Z10.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y101.944 E.04241
G1 X85.14 Y100.798 E.13153
G1 X85.14 Y104.639 E.11404
G1 X80.86 Y100.36 E.17968
G1 X80.86 Y100.534 E.00518
G1 X82.381 Y94.86 E.1744
G1 X82.936 Y94.86 E.01649
G1 X85.14 Y97.064 E.09252
G1 X85.14 Y95.253 E.05378
G1 X80.86 Y96.399 E.13153
G1 X80.86 Y94.971 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11
; LAYER_HEIGHT: 0.2
M106 S201.45
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.2 I-.361 J1.162 P1  F42000
G1 X114.557 Y105.443 Z11.2
G1 Z11
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z11.4 I1.217 J0 P1  F42000
G1 X119.14 Y102.924
G1 Z11
M73 P58 R13
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.86 Y104.071 E.13153
G1 X114.86 Y103.861 E.00624
G1 X116.14 Y105.14 E.05371
G1 X118.296 Y105.14 E.06403
G1 X119.14 Y101.991 E.09677
G1 X119.14 Y100.565 E.04236
G1 X114.86 Y96.286 E.17968
M204 S500
G1 X116.933 Y94.86 F42000
G1 F1680.297
M204 S6000
G1 X115.505 Y94.86 E.04241
G1 X114.86 Y97.266 E.07395
G1 X114.86 Y98.526 E.03739
G1 X119.14 Y97.379 E.13153
G1 X119.14 Y95.951 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11.4 I-.33 J-1.171 P1  F42000
G1 X85.443 Y105.443 Z11.4
G1 Z11
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z11.4 I.499 J-1.11 P1  F42000
G1 X80.86 Y103.519 Z11.4
G1 Z11
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.86 Y102.091 E.04241
G1 X85.14 Y100.944 E.13153
G1 X85.14 Y104.439 E.10376
G1 X80.86 Y100.16 E.17968
G1 X80.86 Y99.988 E.00511
G1 X82.234 Y94.86 E.1576
G1 X83.136 Y94.86 E.02677
G1 X85.14 Y96.864 E.08413
G1 X85.14 Y95.399 E.0435
G1 X80.86 Y96.546 E.13153
G1 X80.86 Y95.117 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.1
; LAYER_HEIGHT: 0.1
M106 S188.7
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.4 I.736 J.969 P1  F42000
G1 X85.715 Y91.429 Z11.4
G1 Z11.1
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z11.5 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z11.5
G1 Z11.1
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z11.5 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z11.5
G1 Z11.1
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
; CHANGE_LAYER
; Z_HEIGHT: 11.2
; LAYER_HEIGHT: 0.0999994
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z11.5
G1 Z11.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
M73 P59 R13
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z11.6 I1.217 J0 P1  F42000
G1 X119.139 Y104.499
G1 Z11.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.071 E.04241
G1 X114.861 Y104.217 E.13153
G1 X114.861 Y103.661 E.01652
G1 X116.339 Y105.139 E.0621
G1 X118.15 Y105.139 E.05375
G1 X119.139 Y101.445 E.11355
G1 X119.139 Y100.365 E.03209
G1 X114.861 Y96.086 E.17967
M204 S500
G1 X116.787 Y94.861 F42000
G1 F1680.297
M204 S6000
G1 X115.359 Y94.861 E.04241
G1 X114.861 Y96.72 E.05714
G1 X114.861 Y98.672 E.05797
G1 X119.139 Y97.525 E.13153
G1 X119.139 Y96.097 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11.6 I-.105 J-1.212 P1  F42000
G1 X108.243 Y97.043 Z11.6
G1 Z11.2
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.39999
M106 S255
G1 F600
G1 X105.757 Y97.043 E.07381
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y96.983 E.03512
M106 S188.7
M204 S250
G1 X108.6 Y97.4 F42000
M106 S255
G1 F600
M204 S500
G1 X105.4 Y97.4 E.09501
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.34 E.04572
M106 S188.7
G1 X107.932 Y96.9 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.41557
M106 S255
G1 F1500
M204 S6000
G1 X107.932 Y94.861 E.0632
G1 X107.559 Y94.861 E.01155
G1 X107.559 Y96.739 E.05822
G1 X107.186 Y96.739 E.01155
G1 X107.186 Y94.861 E.05822
G1 X106.814 Y94.861 E.01155
G1 X106.814 Y96.739 E.05822
G1 X106.441 Y96.739 E.01155
G1 X106.441 Y94.861 E.05822
G1 X106.068 Y94.861 E.01155
G1 X106.068 Y96.9 E.0632
M106 S188.7
G1 E-.8 F1800
M204 S500
G17
G3 Z11.6 I.233 J-1.194 P1  F42000
G1 X100.643 Y95.843 Z11.6
G1 Z11.2
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.39999
M106 S255
G1 F600
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M106 S188.7
M204 S250
G1 X101 Y96.2 F42000
M106 S255
G1 F600
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
M106 S188.7
G1 X100.5 Y95.325 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.4714
M106 S255
G1 F1400.299
M204 S6000
G1 X99.661 Y95.325 E.02991
G1 X99.661 Y94.896 E.01527
G1 X100.5 Y94.896 E.02991
M106 S188.7
G1 E-.8 F1800
M204 S500
G17
G3 Z11.6 I-.018 J-1.217 P1  F42000
G1 X92.789 Y95.011 Z11.6
G1 Z11.2
G1 E.8 F1800
; FEATURE: Overhang wall
; LINE_WIDTH: 0.46438
M106 S255
G1 F600
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M106 S188.7
M204 S250
G1 X92.4 Y95.4 F42000
; LINE_WIDTH: 0.39999
M106 S255
G1 F600
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
M106 S188.7
G1 E-.8 F1800
G17
G3 Z11.6 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z11.6
G1 Z11.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z11.6 I1.21 J-.131 P1  F42000
G1 X85.139 Y99.662 Z11.6
G1 Z11.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y101.091 E.04241
G1 X80.861 Y102.237 E.13153
G1 X80.861 Y105.139 E.08617
G1 X84.879 Y105.139 E.11931
G1 X85.139 Y104.167 E.0299
G1 X85.139 Y104.239 E.00214
G1 X80.861 Y99.96 E.17967
G1 X80.861 Y99.441 E.01541
G1 X82.088 Y94.861 E.14079
G1 X83.336 Y94.861 E.03706
G1 X85.139 Y96.664 E.07572
G1 X85.139 Y95.545 E.03321
G1 X80.861 Y96.692 E.13153
G1 X80.861 Y95.264 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.4
; LAYER_HEIGHT: 0.2
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.6 I.754 J.955 P1  F42000
G1 X85.715 Y91.429 Z11.6
G1 Z11.4
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
M73 P60 R13
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z11.8
G1 Z11.4
M73 P60 R12
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z11.8
G1 Z11.4
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I1.212 J.105 P1  F42000
G1 X114.557 Y105.443 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z11.8 I1.217 J0 P1  F42000
G1 X119.139 Y104.645
G1 Z11.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.217 E.04241
G1 X114.861 Y104.363 E.13153
G1 X114.861 Y103.461 E.02681
G1 X116.539 Y105.139 E.07049
G1 X118.003 Y105.139 E.04346
G1 X119.139 Y100.899 E.13035
G1 X119.139 Y100.165 E.0218
G1 X114.861 Y95.886 E.17967
G1 X114.861 Y96.173 E.00853
G1 X115.212 Y94.861 E.04035
G1 X119.139 Y94.861 E.1166
G1 X119.139 Y97.672 E.08347
G1 X114.861 Y98.818 E.13153
G1 X114.861 Y100.247 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I.404 J-1.148 P1  F42000
G1 X105.757 Y97.043 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z11.8 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z11.8
G1 Z11.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
M73 P61 R12
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X85.139 Y104.039 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y99.76 E.17967
G1 X80.861 Y98.895 E.02569
G1 X81.941 Y94.861 E.124
G1 X83.536 Y94.861 E.04735
G1 X85.139 Y96.464 E.06732
G1 X85.139 Y95.692 E.02292
G1 X80.861 Y96.838 E.13153
G1 X80.861 Y95.41 E.04241
M204 S500
G1 X80.861 Y103.812 F42000
G1 F1680.297
M204 S6000
G1 X80.861 Y102.383 E.04241
G1 X85.139 Y101.237 E.13153
G1 X85.139 Y103.62 E.07076
G1 X84.732 Y105.139 E.0467
G1 X83.304 Y105.139 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.6
; LAYER_HEIGHT: 0.200001
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z11.8 I-.012 J1.217 P1  F42000
G1 X114.557 Y105.443 Z11.8
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z12 I1.217 J0 P1  F42000
G1 X119.139 Y104.792
G1 Z11.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.363 E.04241
G1 X114.861 Y104.51 E.13153
G1 X114.861 Y103.261 E.03709
G1 X116.739 Y105.139 E.07889
G1 X117.857 Y105.139 E.03318
G1 X119.139 Y100.353 E.14714
G1 X119.139 Y99.965 E.01152
G1 X114.861 Y95.686 E.17967
G1 X114.861 Y95.627 E.00176
G1 X115.066 Y94.861 E.02355
G1 X119.139 Y94.861 E.12095
G1 X119.139 Y97.818 E.08782
G1 X114.861 Y98.965 E.13153
G1 X114.861 Y100.393 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z12 I.42 J-1.142 P1  F42000
G1 X105.757 Y97.043 Z12
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z12 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z12
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z12 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z12
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z12 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z12
G1 Z11.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z12 I1.15 J-.399 P1  F42000
G1 X85.139 Y103.839 Z12
G1 Z11.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y99.56 E.17967
G1 X80.861 Y98.348 E.03598
G1 X81.795 Y94.861 E.1072
G1 X83.736 Y94.861 E.05763
G1 X85.139 Y96.264 E.05892
G1 X85.139 Y95.838 E.01264
G1 X80.861 Y96.985 E.13153
G1 X80.861 Y95.556 E.04241
M204 S500
G1 X80.861 Y103.958 F42000
G1 F1680.297
M204 S6000
G1 X80.861 Y102.53 E.04241
G1 X85.139 Y101.383 E.13153
G1 X85.139 Y103.074 E.05019
G1 X84.586 Y105.139 E.06349
G1 X83.158 Y105.139 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 11.7
; LAYER_HEIGHT: 0.0999994
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12 I1.196 J.223 P1  F42000
G1 X85.715 Y91.429 Z12
G1 Z11.7
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
M73 P62 R12
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z12.1 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z12.1
G1 Z11.7
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z12.1 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z12.1
G1 Z11.7
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
; CHANGE_LAYER
; Z_HEIGHT: 11.8
; LAYER_HEIGHT: 0.1
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z12.1
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z12.2 I1.217 J0 P1  F42000
G1 X119.139 Y104.938
G1 Z11.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.51 E.04241
G1 X114.861 Y104.656 E.13153
G1 X114.861 Y103.061 E.04738
G1 X116.939 Y105.139 E.08729
G1 X117.71 Y105.139 E.02289
G1 X119.139 Y99.806 E.16394
G1 X119.139 Y99.765 E.00123
G1 X114.861 Y95.486 E.17967
G1 X114.861 Y99.111 E.10764
G1 X119.139 Y97.965 E.13153
G1 X119.139 Y96.536 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z12.2 I-.046 J-1.216 P1  F42000
G1 X105.757 Y97.043 Z12.2
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z12.2 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z12.2
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
M73 P63 R12
G1 E-.8 F1800
M204 S500
G17
G3 Z12.2 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z12.2
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z12.2 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z12.2
G1 Z11.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
M73 P63 R11
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z12.2 I.383 J-1.155 P1  F42000
G1 X80.861 Y104.105 Z12.2
G1 Z11.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y102.676 E.04241
G1 X85.139 Y101.53 E.13153
G1 X85.139 Y102.527 E.02962
G1 X84.44 Y105.139 E.08029
G1 X85.139 Y105.139 E.02078
G1 X85.139 Y103.639 E.04456
G1 X80.861 Y99.36 E.17967
G1 X80.861 Y97.802 E.04626
G1 X81.649 Y94.861 E.09041
G1 X83.936 Y94.861 E.06792
G1 X85.139 Y96.064 E.05053
G1 X85.139 Y95.985 E.00235
G1 X80.861 Y97.131 E.13153
; CHANGE_LAYER
; Z_HEIGHT: 12
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.2 I.927 J.789 P1  F42000
G1 X85.715 Y91.429 Z12.2
G1 Z12
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z12.4
G1 Z12
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z12.4
G1 Z12
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I1.212 J.105 P1  F42000
G1 X114.557 Y105.443 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
M73 P64 R11
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z12.4 I1.217 J0 P1  F42000
G1 X119.139 Y102.228
G1 Z12
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.656 E.04241
G1 X114.861 Y104.803 E.13153
G1 X114.861 Y102.861 E.05766
G1 X117.139 Y105.139 E.09569
G1 X117.564 Y105.139 E.0126
G1 X119.139 Y99.26 E.18074
G1 X119.139 Y99.565 E.00906
G1 X114.861 Y95.286 E.17967
G1 X114.861 Y99.258 E.11793
G1 X119.139 Y98.111 E.13153
G1 X119.139 Y96.683 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I-.033 J-1.217 P1  F42000
G1 X105.757 Y97.043 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z12.4 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z12.4 I.351 J-1.165 P1  F42000
G1 X80.861 Y104.251 Z12.4
G1 Z12
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y102.823 E.04241
G1 X85.139 Y101.676 E.13153
G1 X85.139 Y101.981 E.00905
G1 X84.293 Y105.139 E.09709
G1 X85.139 Y105.139 E.02513
G1 X85.139 Y103.439 E.0505
G1 X80.861 Y99.16 E.17967
G1 X80.861 Y100.588 E.04241
M204 S500
G1 X80.861 Y95.647 F42000
G1 F1680.297
M204 S6000
G1 X80.861 Y94.861 E.02336
G1 X81.502 Y94.861 E.01905
G1 X80.861 Y97.278 E.07425
G1 X85.139 Y96.131 E.13153
G1 X85.139 Y95.864 E.00793
G1 X84.136 Y94.861 E.04213
G1 X82.708 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.2
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.4 I-.384 J1.155 P1  F42000
G1 X114.557 Y105.443 Z12.4
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z12.6 I1.217 J0 P1  F42000
G1 X119.139 Y102.374
G1 Z12.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y103.803 E.04241
G1 X114.861 Y104.949 E.13153
G1 X114.861 Y102.661 E.06795
G1 X117.339 Y105.139 E.10409
G1 X117.418 Y105.139 E.00232
G1 X119.139 Y98.713 E.19753
G1 X119.139 Y98.257 E.01353
G1 X114.861 Y99.404 E.13153
G1 X114.861 Y95.086 E.12821
G1 X119.139 Y99.365 E.17967
G1 E-.8 F1800
M204 S500
G17
G3 Z12.6 I.208 J-1.199 P1  F42000
G1 X105.757 Y97.043 Z12.6
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
M73 P65 R11
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z12.6 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z12.6
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z12.6 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z12.6
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z12.6 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z12.6
G1 Z12.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z12.6 I1.2 J-.202 P1  F42000
G1 X85.139 Y101.823 Z12.6
G1 Z12.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y102.969 E.13153
G1 X80.861 Y98.96 E.11904
G1 X85.139 Y103.239 E.17967
G1 X85.139 Y105.139 E.05644
G1 X84.147 Y105.139 E.02947
G1 X85.139 Y101.435 E.11388
G1 X85.139 Y100.006 E.04241
M204 S500
G1 X82.908 Y94.861 F42000
G1 F1680.297
M204 S6000
G1 X84.336 Y94.861 E.04241
G1 X85.139 Y95.664 E.03373
G1 X85.139 Y96.277 E.01822
G1 X80.861 Y97.424 E.13153
G1 X80.861 Y96.709 E.02123
G1 X81.356 Y94.861 E.05681
G1 X82.784 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.3
; LAYER_HEIGHT: 0.1
M106 S191.25
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.6 I.925 J.79 P1  F42000
G1 X85.715 Y91.429 Z12.6
G1 Z12.3
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z12.7 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z12.7
G1 Z12.3
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z12.7 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z12.7
G1 Z12.3
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
M73 P66 R11
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
; CHANGE_LAYER
; Z_HEIGHT: 12.4
; LAYER_HEIGHT: 0.0999994
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z12.7
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z12.8 I1.217 J0 P1  F42000
G1 X119.139 Y102.521
G1 Z12.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
M73 P66 R10
G1 F1680.297
M204 S6000
G1 X119.139 Y103.949 E.04241
G1 X114.861 Y105.096 E.13153
G1 X114.861 Y102.461 E.07823
G1 X117.539 Y105.139 E.11248
G1 X117.271 Y105.139 E.00797
G1 X119.139 Y98.167 E.21433
G1 X119.139 Y98.404 E.00704
G1 X114.861 Y99.55 E.13153
G1 X114.861 Y94.886 E.1385
G1 X119.139 Y99.165 E.17967
G1 E-.8 F1800
M204 S500
G17
G3 Z12.8 I.191 J-1.202 P1  F42000
G1 X105.757 Y97.043 Z12.8
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z12.8 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z12.8
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z12.8 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z12.8
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z12.8 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z12.8
G1 Z12.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z12.8 I1.199 J-.21 P1  F42000
G1 X85.139 Y101.969 Z12.8
G1 Z12.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y103.116 E.13153
G1 X80.861 Y104.544 E.04241
M204 S500
G1 X85.139 Y99.46 F42000
G1 F1680.297
M204 S6000
G1 X85.139 Y100.888 E.04241
G1 X84 Y105.139 E.13068
G1 X85.139 Y105.139 E.03382
G1 X85.139 Y103.039 E.06238
G1 X80.861 Y98.76 E.17967
G1 X80.861 Y97.57 E.03531
G1 X85.139 Y96.424 E.13153
G1 X85.139 Y95.464 E.02851
G1 X84.536 Y94.861 E.02533
G1 X81.209 Y94.861 E.09878
G1 X80.861 Y96.162 E.04002
G1 X80.861 Y97.392 E.0365
; CHANGE_LAYER
; Z_HEIGHT: 12.6
; LAYER_HEIGHT: 0.200001
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z12.8 I.944 J.768 P1  F42000
G1 X85.715 Y91.429 Z12.8
G1 Z12.6
G1 E.8 F1800
; FEATURE: Support
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X105.714 Y91.429 E.83719
G1 X105.714 Y93.621 E.09179
G1 X105.043 Y93.621 E.02809
G1 X104.821 Y93.843 E.01313
G1 X104.821 Y94.286 E.01853
G1 X102.689 Y94.286 E.08929
G1 X102.689 Y93.811 E.01986
G1 X101.547 Y93.811 E.04779
G1 X101.357 Y93.621 E.01125
G1 X98.643 Y93.621 E.11359
G1 X98.453 Y93.811 E.01125
G1 X97.311 Y93.811 E.04779
G1 X97.311 Y94.286 E.01986
G1 X94.179 Y94.286 E.13115
G1 X94.179 Y95.757 E.06157
G1 X93.957 Y95.979 E.01313
G1 X92.043 Y95.979 E.0801
G1 X91.821 Y95.757 E.01313
G1 X91.821 Y94.286 E.06157
G1 X86.529 Y94.286 E.22156
G1 X86.529 Y97.143 E.1196
G1 X97.311 Y97.143 E.45138
G1 X97.311 Y100 E.1196
M73 P67 R10
G1 X86.529 Y100 E.45138
G1 X86.529 Y102.857 E.1196
G1 X97.311 Y102.857 E.45138
G1 X97.311 Y105.536 E.11212
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I.713 J.987 P1  F42000
G1 X109.179 Y96.964 Z13
G1 Z12.6
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X109.179 Y94.286 E.11212
G1 X113.471 Y94.286 E.1797
G1 X113.471 Y93.781 E.02113
G1 X113.781 Y93.471 E.01833
G1 X114.286 Y93.471 E.02112
G1 X114.286 Y91.429 E.08551
G1 X108.571 Y91.429 E.2392
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I-.558 J-1.081 P1  F42000
G1 X102.689 Y94.464 Z13
G1 Z12.6
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X102.689 Y97.143 E.11212
G1 X104.821 Y97.143 E.08929
G1 X104.821 Y97.757 E.0257
G1 X105.043 Y97.979 E.01313
G1 X108.957 Y97.979 E.16382
G1 X109.179 Y97.757 E.01313
G1 X109.179 Y97.143 E.0257
G1 X113.471 Y97.143 E.1797
G1 X113.471 Y100 E.1196
G1 X102.689 Y100 E.45138
G1 X102.689 Y102.857 E.1196
G1 X113.471 Y102.857 E.45138
G1 X113.471 Y105.714 E.1196
G1 X102.689 Y105.714 E.45138
G1 X102.689 Y106.189 E.01986
G1 X97.311 Y106.189 E.22509
G1 X97.311 Y105.714 E.01986
G1 X86.529 Y105.714 E.45138
G1 X86.529 Y106.219 E.02113
G1 X86.219 Y106.529 E.01833
G1 X85.715 Y106.529 E.02111
G1 X85.715 Y108.571 E.08551
G1 X114.286 Y108.571 E1.19599
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I1.212 J.105 P1  F42000
G1 X114.557 Y105.443 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z13 I1.217 J0 P1  F42000
G1 X114.861 Y104.094
G1 Z12.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y105.139 E.03105
G1 X115.243 Y105.139 E.01136
G1 X119.139 Y104.095 E.11977
G1 X119.139 Y98.965 E.15234
G1 X115.035 Y94.861 E.17233
G1 X119.139 Y94.861 E.12186
G1 X119.139 Y97.62 E.08194
G1 X117.125 Y105.139 E.23112
G1 X117.739 Y105.139 E.01825
G1 X114.861 Y102.261 E.12088
G1 X114.861 Y99.697 E.07612
G1 X119.139 Y98.55 E.13153
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I.136 J-1.209 P1  F42000
G1 X105.757 Y97.043 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z13 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
M73 P68 R10
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z13 I1.211 J-.117 P1  F42000
G1 X85.139 Y98.913 Z13
G1 Z12.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y100.342 E.04241
G1 X83.854 Y105.139 E.14747
G1 X80.861 Y105.139 E.08888
G1 X80.861 Y103.262 E.05575
G1 X85.139 Y102.115 E.13153
G1 X85.139 Y102.839 E.02147
G1 X80.861 Y98.56 E.17967
G1 X80.861 Y97.717 E.02503
G1 X85.139 Y96.57 E.13153
G1 X85.139 Y95.264 E.03879
G1 X84.736 Y94.861 E.01693
G1 X81.063 Y94.861 E.10906
G1 X80.861 Y95.616 E.02322
G1 X80.861 Y97.044 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.8
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13 I-.294 J1.181 P1  F42000
G1 X114.557 Y105.443 Z13
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z13.2 I1.217 J0 P1  F42000
G1 X114.861 Y104.64
G1 Z12.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y105.139 E.01483
G1 X115.79 Y105.139 E.02758
G1 X119.139 Y104.242 E.10297
G1 X119.139 Y102.814 E.04241
M204 S500
G1 X119.139 Y95.646 F42000
G1 F1680.297
M204 S6000
G1 X119.139 Y97.074 E.04241
G1 X116.978 Y105.139 E.24792
G1 X117.939 Y105.139 E.02854
G1 X114.861 Y102.061 E.12928
G1 X114.861 Y99.843 E.06584
G1 X119.139 Y98.697 E.13153
G1 X119.139 Y98.765 E.00202
G1 X115.235 Y94.861 E.16393
G1 X116.664 Y94.861 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z13.2 I-.239 J-1.193 P1  F42000
G1 X105.757 Y97.043 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z13.2 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z13.2 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z13.2 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z13.2 I1.212 J-.109 P1  F42000
G1 X85.139 Y98.367 Z13.2
G1 Z12.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.139 Y99.795 E.04241
G1 X83.708 Y105.139 E.16427
G1 X80.861 Y105.139 E.08453
G1 X80.861 Y103.408 E.0514
G1 X85.139 Y102.262 E.13153
G1 X85.139 Y102.639 E.01119
G1 X80.861 Y98.36 E.17967
G1 X80.861 Y97.863 E.01474
G1 X85.139 Y96.717 E.13153
G1 X85.139 Y95.064 E.04908
G1 X84.936 Y94.861 E.00854
G1 X83.508 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 12.9
; LAYER_HEIGHT: 0.0999994
M106 S181.05
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.2 I.569 J1.076 P1  F42000
G1 X86.137 Y93.472 Z13.2
G1 Z12.9
G1 E.8 F1800
; FEATURE: Support transition
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X85.715 Y93.472 E.01767
G1 X85.715 Y91.429 E.08552
G1 X86.108 Y91.429 E.01649
M204 S500
G1 X97.607 Y93.812 F42000
G1 F1191.826
M204 S6000
M73 P69 R10
G1 X98.286 Y93.812 E.0284
G1 X98.286 Y91.429 E.09975
G1 X99.143 Y91.429 E.03588
G1 X99.143 Y93.622 E.0918
G1 X100 Y93.622 E.03588
G1 X100 Y91.429 E.0918
G1 X100.857 Y91.429 E.03588
G1 X100.857 Y93.622 E.0918
G1 X101.357 Y93.622 E.02092
G1 X101.547 Y93.812 E.01125
G1 X101.714 Y93.812 E.00701
G1 X101.714 Y91.429 E.09975
G1 X102.571 Y91.429 E.03588
G1 X102.571 Y93.812 E.09975
G1 X102.688 Y93.812 E.00491
G1 X102.688 Y106.188 E.5181
G1 X102.571 Y106.188 E.00491
G1 X102.571 Y108.571 E.09975
G1 X103.428 Y108.571 E.03588
G1 X103.428 Y91.429 E.7176
G1 X104.285 Y91.429 E.03588
G1 X104.285 Y108.571 E.7176
G1 X105.142 Y108.571 E.03588
G1 X105.142 Y97.978 E.44343
G1 X105.043 Y97.978 E.00415
G1 X104.822 Y97.757 E.01312
G1 X104.822 Y93.843 E.16382
G1 X105.043 Y93.622 E.01312
G1 X105.142 Y93.622 E.00415
G1 X105.142 Y91.429 E.0918
G1 X105.714 Y91.429 E.02394
G1 X105.714 Y93.622 E.0918
G1 X105.321 Y93.622 E.01647
G1 E-.8 F1800
M204 S500
G17
G3 Z13.3 I-.059 J1.216 P1  F42000
G1 X109.142 Y93.807 Z13.3
G1 Z12.9
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X108.957 Y93.622 E.01097
G1 X108.571 Y93.622 E.01614
G1 X108.571 Y91.429 E.0918
G1 X109.428 Y91.429 E.03586
G1 X109.428 Y108.571 E.7176
G1 X110.285 Y108.571 E.03588
M73 P69 R9
G1 X110.285 Y91.429 E.7176
G1 X111.142 Y91.429 E.03588
G1 X111.142 Y108.571 E.7176
G1 X111.999 Y108.571 E.03588
G1 X111.999 Y91.429 E.7176
G1 X112.856 Y91.429 E.03588
G1 X112.856 Y108.571 E.7176
G1 X113.713 Y108.571 E.03588
G1 X113.713 Y106.46 E.08837
G1 X113.472 Y106.219 E.0143
G1 X113.472 Y93.781 E.52065
G1 X113.713 Y93.54 E.0143
G1 X113.713 Y91.429 E.08836
G1 X114.286 Y91.429 E.02396
G1 X114.286 Y93.472 E.08552
G1 X113.863 Y93.472 E.01767
M204 S500
G1 X109.142 Y97.793 F42000
G1 F1191.826
M204 S6000
G1 X108.957 Y97.978 E.01097
G1 X108.571 Y97.978 E.01616
G1 X108.571 Y108.571 E.44343
G1 X107.714 Y108.571 E.03588
G1 X107.714 Y97.978 E.44343
G1 X106.857 Y97.978 E.03588
G1 X106.857 Y108.571 E.44343
G1 X105.999 Y108.571 E.03588
G1 X105.999 Y97.978 E.44343
G1 X105.321 Y97.978 E.0284
G1 E-.8 F1800
M204 S500
G17
G3 Z13.3 I-1.146 J-.409 P1  F42000
G1 X102.393 Y106.188 Z13.3
G1 Z12.9
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X101.714 Y106.188 E.0284
G1 X101.714 Y108.571 E.09975
G1 X100.857 Y108.571 E.03588
G1 X100.857 Y106.188 E.09975
G1 X100 Y106.188 E.03588
G1 X100 Y108.571 E.09975
G1 X99.143 Y108.571 E.03588
G1 X99.143 Y106.188 E.09975
G1 X98.286 Y106.188 E.03588
G1 X98.286 Y108.571 E.09975
G1 X97.429 Y108.571 E.03588
G1 X97.429 Y106.188 E.09975
G1 X97.312 Y106.188 E.00491
G1 X97.312 Y93.812 E.5181
G1 X97.429 Y93.812 E.00491
G1 X97.429 Y91.429 E.09975
G1 X96.572 Y91.429 E.03588
G1 X96.572 Y108.571 E.7176
G1 X95.715 Y108.571 E.03588
G1 X95.715 Y91.429 E.7176
G1 X94.858 Y91.429 E.03588
G1 X94.858 Y108.571 E.7176
G1 X94.001 Y108.571 E.03588
G1 X94.001 Y95.935 E.52898
G1 X94.178 Y95.757 E.01053
G1 X94.178 Y93.843 E.0801
G1 X94.001 Y93.665 E.01053
G1 X94.001 Y91.429 E.09363
G1 X93.143 Y91.429 E.03588
G1 X93.143 Y93.622 E.0918
M73 P70 R9
G1 X92.465 Y93.622 E.0284
G1 E-.8 F1800
M204 S500
G17
G3 Z13.3 I-1.051 J.613 P1  F42000
G1 X93.84 Y95.978 Z13.3
G1 Z12.9
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X93.143 Y95.978 E.02916
G1 X93.143 Y108.571 E.52715
G1 X92.286 Y108.571 E.03588
G1 X92.286 Y95.978 E.52715
G1 X92.043 Y95.978 E.01018
G1 X91.822 Y95.757 E.01312
G1 X91.822 Y93.843 E.0801
G1 X92.043 Y93.622 E.01312
G1 X92.286 Y93.622 E.01018
G1 X92.286 Y91.429 E.0918
G1 X91.429 Y91.429 E.03588
G1 X91.429 Y108.571 E.7176
G1 X90.572 Y108.571 E.03588
G1 X90.572 Y91.429 E.7176
G1 X89.715 Y91.429 E.03588
G1 X89.715 Y108.571 E.7176
G1 X88.858 Y108.571 E.03588
G1 X88.858 Y91.429 E.7176
G1 X88.001 Y91.429 E.03588
G1 X88.001 Y108.571 E.7176
G1 X87.144 Y108.571 E.03588
G1 X87.144 Y91.429 E.7176
G1 X86.287 Y91.429 E.03588
G1 X86.287 Y93.54 E.08836
G1 X86.528 Y93.781 E.0143
G1 X86.528 Y106.219 E.52065
G1 X86.287 Y106.46 E.0143
G1 X86.287 Y108.571 E.08837
G1 X85.715 Y108.571 E.02396
G1 X85.715 Y106.528 E.08552
G1 X86.137 Y106.528 E.01767
M204 S500
G1 X113.863 Y106.528 F42000
G1 F1191.826
M204 S6000
G1 X114.286 Y106.528 E.01767
G1 X114.286 Y108.571 E.08552
G1 X113.892 Y108.571 E.01649
; CHANGE_LAYER
; Z_HEIGHT: 13
; LAYER_HEIGHT: 0.1
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z13.3
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z13.4 I1.217 J0 P1  F42000
G1 X114.908 Y105.139
G1 Z13
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X116.336 Y105.139 E.04241
G1 X119.139 Y104.388 E.08617
G1 X119.139 Y105.139 E.0223
G1 X118.139 Y105.139 E.02969
G1 X114.861 Y101.861 E.13768
G1 X114.861 Y99.99 E.05555
G1 X119.139 Y98.843 E.13153
G1 X119.139 Y98.565 E.00827
G1 X115.435 Y94.861 E.15553
G1 X119.139 Y94.861 E.10998
G1 X119.139 Y96.528 E.0495
G1 X116.832 Y105.139 E.26472
G1 E-.8 F1800
M204 S500
G17
G3 Z13.4 I.718 J-.982 P1  F42000
G1 X105.757 Y97.043 Z13.4
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z13.4 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z13.4
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z13.4 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z13.4
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z13.4 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z13.4
G1 Z13
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
M73 P71 R9
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z13.4 I.197 J-1.201 P1  F42000
G1 X82.133 Y105.139 Z13.4
G1 Z13
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.561 Y105.139 E.04241
G1 X85.139 Y99.249 E.18106
G1 X85.139 Y96.863 E.07084
G1 X80.861 Y98.01 E.13153
G1 X80.861 Y98.16 E.00446
G1 X85.139 Y102.439 E.17967
G1 X85.139 Y102.408 E.0009
G1 X80.861 Y103.555 E.13153
G1 X80.861 Y102.126 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 13.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.4 I1.089 J.544 P1  F42000
G1 X86.287 Y91.268 Z13.4
G1 Z13.2
G1 E.8 F1800
; FEATURE: Support interface
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X86.287 Y93.54 E.09509
G1 X86.528 Y93.781 E.0143
G1 X86.528 Y106.219 E.52065
G1 X86.287 Y106.46 E.0143
G1 X86.287 Y108.571 E.08837
G1 X87.144 Y108.571 E.03588
G1 X87.144 Y91.429 E.7176
G1 X88.001 Y91.429 E.03588
G1 X88.001 Y108.571 E.7176
G1 X88.858 Y108.571 E.03588
G1 X88.858 Y91.429 E.7176
G1 X89.715 Y91.429 E.03588
G1 X89.715 Y108.571 E.7176
G1 X90.572 Y108.571 E.03588
G1 X90.572 Y91.429 E.7176
G1 X91.429 Y91.429 E.03588
G1 X91.429 Y108.732 E.72433
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I0 J1.217 P1  F42000
G1 X94.001 Y108.732 Z13.6
G1 Z13.2
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X94.001 Y95.935 E.5357
G1 X93.957 Y95.978 E.00259
G1 X93.143 Y95.978 E.03405
G1 X93.143 Y108.571 E.52715
G1 X92.286 Y108.571 E.03588
G1 X92.286 Y95.978 E.52715
G1 X92.043 Y95.978 E.01018
G1 X91.822 Y95.757 E.01312
G1 X91.822 Y93.843 E.0801
G1 X92.043 Y93.622 E.01312
G1 X92.286 Y93.622 E.01018
G1 X92.286 Y91.429 E.0918
G1 X93.143 Y91.429 E.03588
G1 X93.143 Y93.622 E.0918
G1 X93.957 Y93.622 E.03405
G1 X94.001 Y93.665 E.00259
G1 X94.001 Y91.429 E.09363
G1 X94.858 Y91.429 E.03588
G1 X94.858 Y108.571 E.7176
G1 X95.715 Y108.571 E.03588
G1 X95.715 Y91.429 E.7176
G1 X96.572 Y91.429 E.03588
G1 X96.572 Y108.571 E.7176
G1 X97.429 Y108.571 E.03588
G1 X97.429 Y91.429 E.7176
G1 X98.286 Y91.429 E.03588
G1 X98.286 Y93.812 E.09975
G1 X98.453 Y93.812 E.00701
G1 X98.643 Y93.622 E.01125
G1 X99.143 Y93.622 E.02092
G1 X99.143 Y91.429 E.0918
G1 X100 Y91.429 E.03588
G1 X100 Y93.622 E.0918
G1 X100.857 Y93.622 E.03588
G1 X100.857 Y91.429 E.0918
G1 X101.714 Y91.429 E.03588
G1 X101.714 Y93.972 E.10648
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I-1.171 J-.333 P1  F42000
G1 X98.286 Y106.028 Z13.6
G1 Z13.2
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X98.286 Y108.571 E.10648
G1 X99.143 Y108.571 E.03588
G1 X99.143 Y106.188 E.09975
G1 X100 Y106.188 E.03588
G1 X100 Y108.571 E.09975
G1 X100.857 Y108.571 E.03588
G1 X100.857 Y106.188 E.09975
G1 X101.714 Y106.188 E.03588
G1 X101.714 Y108.571 E.09975
G1 X102.571 Y108.571 E.03588
M73 P72 R9
G1 X102.571 Y91.429 E.7176
G1 X103.428 Y91.429 E.03588
G1 X103.428 Y108.571 E.7176
G1 X104.285 Y108.571 E.03588
G1 X104.285 Y91.429 E.7176
G1 X105.142 Y91.429 E.03588
G1 X105.142 Y93.622 E.0918
G1 X105.043 Y93.622 E.00415
G1 X104.822 Y93.843 E.01312
G1 X104.822 Y97.757 E.16382
G1 X105.043 Y97.978 E.01312
G1 X105.142 Y97.978 E.00415
G1 X105.142 Y108.571 E.44343
G1 X105.999 Y108.571 E.03588
G1 X105.999 Y97.978 E.44343
G1 X106.857 Y97.978 E.03588
G1 X106.857 Y108.571 E.44343
G1 X107.714 Y108.571 E.03588
G1 X107.714 Y97.978 E.44343
G1 X108.571 Y97.978 E.03588
G1 X108.571 Y108.571 E.44343
G1 X109.428 Y108.571 E.03588
G1 X109.428 Y91.429 E.7176
G1 X110.285 Y91.429 E.03588
G1 X110.285 Y108.571 E.7176
G1 X111.142 Y108.571 E.03588
M73 P72 R8
G1 X111.142 Y91.429 E.7176
G1 X111.999 Y91.429 E.03588
G1 X111.999 Y108.571 E.7176
G1 X112.856 Y108.571 E.03588
G1 X112.856 Y91.429 E.7176
G1 X113.713 Y91.429 E.03588
G1 X113.713 Y93.54 E.08836
G1 X113.472 Y93.781 E.0143
G1 X113.472 Y106.219 E.52065
G1 X113.713 Y106.46 E.0143
G1 X113.713 Y108.732 E.09509
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I1.179 J.302 P1  F42000
G1 X114.557 Y105.443 Z13.6
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z13.6 I1.217 J0 P1  F42000
G1 X114.861 Y95.514
G1 Z13.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y94.861 E.01941
G1 X115.635 Y94.861 E.023
G1 X119.139 Y98.365 E.14714
G1 X119.139 Y98.99 E.01855
G1 X114.861 Y100.136 E.13153
G1 X114.861 Y101.661 E.04527
G1 X118.339 Y105.139 E.14608
G1 X119.139 Y105.139 E.02375
G1 X119.139 Y104.535 E.01796
G1 X116.882 Y105.139 E.06938
G1 X116.686 Y105.139 E.00585
G1 X119.139 Y95.981 E.28151
G1 X119.139 Y94.861 E.03327
G1 X118.832 Y94.861 E.00913
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I-.2 J-1.2 P1  F42000
G1 X105.757 Y97.043 Z13.6
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z13.6
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
M73 P73 R8
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z13.6
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z13.6 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z13.6
G1 Z13.2
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.843 Y105.139 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.415 Y105.139 E.04241
G1 X85.139 Y98.703 E.19786
G1 X85.139 Y97.01 E.05027
G1 X80.861 Y98.156 E.13153
G1 X80.861 Y97.96 E.00583
G1 X85.139 Y102.239 E.17967
G1 X85.139 Y102.555 E.00938
G1 X80.861 Y103.701 E.13153
G1 X80.861 Y102.273 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 13.4
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.6 I-.114 J1.212 P1  F42000
G1 X114.557 Y105.443 Z13.6
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z13.8 I1.217 J0 P1  F42000
G1 X114.861 Y95.314
G1 Z13.4
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y94.861 E.01347
G1 X115.835 Y94.861 E.02894
G1 X119.139 Y98.165 E.13874
G1 X119.139 Y99.136 E.02884
G1 X114.861 Y100.282 E.13153
G1 X114.861 Y101.461 E.03498
G1 X118.539 Y105.139 E.15447
G1 X119.139 Y105.139 E.01782
G1 X119.139 Y104.681 E.01361
G1 X117.429 Y105.139 E.05258
G1 X116.539 Y105.139 E.02642
G1 X119.139 Y95.435 E.29831
G1 X119.139 Y94.861 E.01705
G1 X118.285 Y94.861 E.02536
G1 E-.8 F1800
M204 S500
G17
G3 Z13.8 I-.209 J-1.199 P1  F42000
G1 X105.757 Y97.043 Z13.8
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z13.8 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z13.8
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z13.8 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z13.8
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z13.8 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z13.8
G1 Z13.4
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 X84.697 Y105.139 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.268 Y105.139 E.04241
G1 X85.139 Y98.156 E.21466
G1 X85.139 Y97.156 E.0297
G1 X80.861 Y98.302 E.13153
G1 X80.861 Y97.76 E.01611
G1 X85.139 Y102.039 E.17967
G1 X85.139 Y102.701 E.01967
G1 X80.861 Y103.848 E.13153
G1 X80.861 Y102.419 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 13.5
; LAYER_HEIGHT: 0.1
M106 S181.05
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z13.8 I-.624 J1.045 P1  F42000
G1 X91.429 Y108.732 Z13.8
M73 P74 R8
G1 Z13.5
G1 E.8 F1800
; FEATURE: Support interface
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X91.429 Y91.429 E.72433
G1 X90.572 Y91.429 E.03588
G1 X90.572 Y108.571 E.7176
G1 X89.715 Y108.571 E.03588
G1 X89.715 Y91.429 E.7176
G1 X88.858 Y91.429 E.03588
G1 X88.858 Y108.571 E.7176
G1 X88.001 Y108.571 E.03588
G1 X88.001 Y91.429 E.7176
G1 X87.144 Y91.429 E.03588
G1 X87.144 Y108.571 E.7176
G1 X86.287 Y108.571 E.03588
G1 X86.287 Y106.46 E.08837
G1 X86.528 Y106.219 E.0143
G1 X86.528 Y93.781 E.52065
G1 X86.287 Y93.54 E.0143
G1 X86.287 Y91.268 E.09509
G1 E-.8 F1800
M204 S500
G17
G3 Z13.9 I-.21 J1.199 P1  F42000
G1 X101.714 Y93.972 Z13.9
G1 Z13.5
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X101.714 Y91.429 E.10648
G1 X100.857 Y91.429 E.03588
G1 X100.857 Y93.622 E.0918
G1 X100 Y93.622 E.03588
G1 X100 Y91.429 E.0918
G1 X99.143 Y91.429 E.03588
G1 X99.143 Y93.622 E.0918
G1 X98.643 Y93.622 E.02092
G1 X98.453 Y93.812 E.01125
G1 X98.286 Y93.812 E.00701
G1 X98.286 Y91.429 E.09975
G1 X97.429 Y91.429 E.03588
G1 X97.429 Y108.571 E.7176
G1 X96.572 Y108.571 E.03588
G1 X96.572 Y91.429 E.7176
G1 X95.715 Y91.429 E.03588
G1 X95.715 Y108.571 E.7176
G1 X94.858 Y108.571 E.03588
G1 X94.858 Y91.429 E.7176
G1 X94.001 Y91.429 E.03588
G1 X94.001 Y93.665 E.09363
G1 X93.957 Y93.622 E.00259
G1 X93.143 Y93.622 E.03405
G1 X93.143 Y91.429 E.0918
G1 X92.286 Y91.429 E.03588
G1 X92.286 Y93.622 E.0918
G1 X92.043 Y93.622 E.01018
G1 X91.822 Y93.843 E.01312
G1 X91.822 Y95.757 E.0801
G1 X92.043 Y95.978 E.01312
G1 X92.286 Y95.978 E.01018
G1 X92.286 Y108.571 E.52715
G1 X93.143 Y108.571 E.03588
G1 X93.143 Y95.978 E.52715
G1 X93.957 Y95.978 E.03405
G1 X94.001 Y95.935 E.00259
G1 X94.001 Y108.732 E.5357
G1 E-.8 F1800
M204 S500
G17
G3 Z13.9 I.649 J1.029 P1  F42000
G1 X98.286 Y106.028 Z13.9
G1 Z13.5
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X98.286 Y108.571 E.10648
G1 X99.143 Y108.571 E.03588
G1 X99.143 Y106.188 E.09975
G1 X100 Y106.188 E.03588
G1 X100 Y108.571 E.09975
G1 X100.857 Y108.571 E.03588
G1 X100.857 Y106.188 E.09975
G1 X101.714 Y106.188 E.03588
G1 X101.714 Y108.571 E.09975
G1 X102.571 Y108.571 E.03588
G1 X102.571 Y91.429 E.7176
G1 X103.428 Y91.429 E.03588
G1 X103.428 Y108.571 E.7176
G1 X104.285 Y108.571 E.03588
G1 X104.285 Y91.429 E.7176
G1 X105.142 Y91.429 E.03588
G1 X105.142 Y93.622 E.0918
G1 X105.043 Y93.622 E.00415
G1 X104.822 Y93.843 E.01312
G1 X104.822 Y97.757 E.16382
G1 X105.043 Y97.978 E.01312
G1 X105.142 Y97.978 E.00415
G1 X105.142 Y108.571 E.44343
G1 X105.999 Y108.571 E.03588
M73 P75 R8
G1 X105.999 Y97.978 E.44343
G1 X106.857 Y97.978 E.03588
G1 X106.857 Y108.571 E.44343
G1 X107.714 Y108.571 E.03588
G1 X107.714 Y97.978 E.44343
G1 X108.571 Y97.978 E.03588
G1 X108.571 Y108.571 E.44343
G1 X109.428 Y108.571 E.03588
G1 X109.428 Y91.429 E.7176
G1 X110.285 Y91.429 E.03588
G1 X110.285 Y108.571 E.7176
G1 X111.142 Y108.571 E.03588
G1 X111.142 Y91.429 E.7176
G1 X111.999 Y91.429 E.03588
G1 X111.999 Y108.571 E.7176
G1 X112.856 Y108.571 E.03588
G1 X112.856 Y91.429 E.7176
G1 X113.713 Y91.429 E.03588
G1 X113.713 Y93.54 E.08836
G1 X113.472 Y93.781 E.0143
G1 X113.472 Y106.219 E.52065
G1 X113.713 Y106.46 E.0143
G1 X113.713 Y108.732 E.09509
; CHANGE_LAYER
; Z_HEIGHT: 13.6
; LAYER_HEIGHT: 0.1
; OBJECT_ID: 15
G1 E-.8 F1800
G1 X114.557 Y105.443 F42000
M204 S500
G1 Z13.9
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
M73 P75 R7
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z14 I1.217 J0 P1  F42000
G1 X114.861 Y95.114
G1 Z13.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y94.861 E.00753
G1 X116.035 Y94.861 E.03488
G1 X119.139 Y97.965 E.13034
G1 X119.139 Y99.282 E.03912
G1 X114.861 Y100.429 E.13153
G1 X114.861 Y101.261 E.02469
G1 X118.739 Y105.139 E.16287
G1 X119.139 Y105.139 E.01188
G1 X119.139 Y104.827 E.00926
G1 X117.975 Y105.139 E.03579
G1 X116.393 Y105.139 E.04699
G1 X119.139 Y94.888 E.3151
G1 X119.139 Y94.861 E.00083
G1 X117.739 Y94.861 E.04158
G1 E-.8 F1800
M204 S500
G17
G3 Z14 I-.218 J-1.197 P1  F42000
G1 X105.757 Y97.043 Z14
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z14 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z14
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z14 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z14
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z14 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z14
G1 Z13.6
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
M73 P76 R7
G1 X85.8 Y105.74 E.2595
G1 X84.55 Y105.139 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X83.122 Y105.139 E.04241
G1 X85.139 Y97.61 E.23145
G1 X85.139 Y97.302 E.00913
G1 X80.861 Y98.449 E.13153
G1 X80.861 Y97.56 E.0264
G1 X85.139 Y101.839 E.17967
G1 X85.139 Y102.847 E.02995
G1 X80.861 Y103.994 E.13153
G1 X80.861 Y102.566 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 13.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z14 I-.613 J1.051 P1  F42000
G1 X91.429 Y108.732 Z14
G1 Z13.8
G1 E.8 F1800
; FEATURE: Support interface
; LAYER_HEIGHT: 0.3
G1 F1191.826
M204 S6000
G1 X91.429 Y91.429 E.72433
G1 X90.572 Y91.429 E.03588
G1 X90.572 Y108.571 E.7176
G1 X89.715 Y108.571 E.03588
G1 X89.715 Y91.429 E.7176
G1 X88.858 Y91.429 E.03588
G1 X88.858 Y108.571 E.7176
G1 X88.001 Y108.571 E.03588
G1 X88.001 Y91.429 E.7176
G1 X87.144 Y91.429 E.03588
G1 X87.144 Y108.571 E.7176
G1 X86.287 Y108.571 E.03588
G1 X86.287 Y106.46 E.08837
G1 X86.528 Y106.219 E.0143
G1 X86.528 Y93.781 E.52065
G1 X86.287 Y93.54 E.0143
G1 X86.287 Y91.268 E.09509
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I-.21 J1.199 P1  F42000
G1 X101.714 Y93.972 Z14.2
G1 Z13.8
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X101.714 Y91.429 E.10648
G1 X100.857 Y91.429 E.03588
G1 X100.857 Y93.622 E.0918
G1 X100 Y93.622 E.03588
G1 X100 Y91.429 E.0918
G1 X99.143 Y91.429 E.03588
G1 X99.143 Y93.622 E.0918
G1 X98.643 Y93.622 E.02092
G1 X98.453 Y93.812 E.01125
G1 X98.286 Y93.812 E.00701
G1 X98.286 Y91.429 E.09975
G1 X97.429 Y91.429 E.03588
G1 X97.429 Y108.571 E.7176
G1 X96.572 Y108.571 E.03588
G1 X96.572 Y91.429 E.7176
G1 X95.715 Y91.429 E.03588
G1 X95.715 Y108.571 E.7176
G1 X94.858 Y108.571 E.03588
G1 X94.858 Y91.429 E.7176
G1 X94.001 Y91.429 E.03588
G1 X94.001 Y93.665 E.09363
G1 X93.957 Y93.622 E.00259
G1 X93.143 Y93.622 E.03405
G1 X93.143 Y91.429 E.0918
G1 X92.286 Y91.429 E.03588
G1 X92.286 Y93.622 E.0918
G1 X92.043 Y93.622 E.01018
G1 X91.822 Y93.843 E.01312
G1 X91.822 Y95.757 E.0801
G1 X92.043 Y95.978 E.01312
G1 X92.286 Y95.978 E.01018
G1 X92.286 Y108.571 E.52715
G1 X93.143 Y108.571 E.03588
G1 X93.143 Y95.978 E.52715
G1 X93.957 Y95.978 E.03405
G1 X94.001 Y95.935 E.00259
G1 X94.001 Y108.732 E.5357
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I.649 J1.029 P1  F42000
G1 X98.286 Y106.028 Z14.2
G1 Z13.8
G1 E.8 F1800
G1 F1191.826
M204 S6000
G1 X98.286 Y108.571 E.10648
G1 X99.143 Y108.571 E.03588
G1 X99.143 Y106.188 E.09975
G1 X100 Y106.188 E.03588
G1 X100 Y108.571 E.09975
G1 X100.857 Y108.571 E.03588
G1 X100.857 Y106.188 E.09975
G1 X101.714 Y106.188 E.03588
G1 X101.714 Y108.571 E.09975
G1 X102.571 Y108.571 E.03588
G1 X102.571 Y91.429 E.7176
G1 X103.428 Y91.429 E.03588
G1 X103.428 Y108.571 E.7176
G1 X104.285 Y108.571 E.03588
M73 P77 R7
G1 X104.285 Y91.429 E.7176
G1 X105.142 Y91.429 E.03588
G1 X105.142 Y93.622 E.0918
G1 X105.043 Y93.622 E.00415
G1 X104.822 Y93.843 E.01312
G1 X104.822 Y97.757 E.16382
G1 X105.043 Y97.978 E.01312
G1 X105.142 Y97.978 E.00415
G1 X105.142 Y108.571 E.44343
G1 X105.999 Y108.571 E.03588
G1 X105.999 Y97.978 E.44343
G1 X106.857 Y97.978 E.03588
G1 X106.857 Y108.571 E.44343
G1 X107.714 Y108.571 E.03588
G1 X107.714 Y97.978 E.44343
G1 X108.571 Y97.978 E.03588
G1 X108.571 Y108.571 E.44343
G1 X109.428 Y108.571 E.03588
G1 X109.428 Y91.429 E.7176
G1 X110.285 Y91.429 E.03588
G1 X110.285 Y108.571 E.7176
G1 X111.142 Y108.571 E.03588
G1 X111.142 Y91.429 E.7176
G1 X111.999 Y91.429 E.03588
G1 X111.999 Y108.571 E.7176
G1 X112.856 Y108.571 E.03588
G1 X112.856 Y91.429 E.7176
G1 X113.713 Y91.429 E.03588
G1 X113.713 Y93.54 E.08836
G1 X113.472 Y93.781 E.0143
G1 X113.472 Y106.219 E.52065
G1 X113.713 Y106.46 E.0143
G1 X113.713 Y108.732 E.09509
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I1.179 J.302 P1  F42000
G1 X114.557 Y105.443 Z14.2
G1 Z13.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
; LAYER_HEIGHT: 0.2
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z14.2 I1.217 J0 P1  F42000
G1 X114.861 Y96.458
G1 Z13.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y95.03 E.04241
G1 X115.493 Y94.861 E.01945
G1 X116.235 Y94.861 E.02203
G1 X119.139 Y97.765 E.12194
G1 X119.139 Y99.429 E.04941
G1 X114.861 Y100.575 E.13153
G1 X114.861 Y101.061 E.01441
G1 X118.939 Y105.139 E.17127
G1 X119.139 Y105.139 E.00594
G1 X119.139 Y104.974 E.00492
G1 X118.522 Y105.139 E.01899
G1 X116.246 Y105.139 E.06756
G1 X119 Y94.861 E.31596
G1 X119.139 Y94.861 E.00413
G1 X119.139 Y96.15 E.03828
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I-.081 J-1.214 P1  F42000
G1 X105.757 Y97.043 Z14.2
G1 Z13.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z14.2
G1 Z13.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z14.2
G1 Z13.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z14.2 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z14.2
G1 Z13.8
M73 P78 R7
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z14.2 I1.213 J-.097 P1  F42000
G1 X85.139 Y97.449 Z14.2
G1 Z13.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y98.595 E.13153
G1 X80.861 Y97.36 E.03668
G1 X85.139 Y101.639 E.17967
G1 X85.139 Y102.994 E.04024
G1 X80.861 Y104.14 E.13153
G1 X80.861 Y104.935 E.02358
G1 X81.065 Y105.139 E.0086
G1 X82.975 Y105.139 E.05671
G1 X85.139 Y97.063 E.24825
G1 X85.139 Y95.635 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 14
; LAYER_HEIGHT: 0.2
M106 S198.9
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z14.2 I-.385 J1.154 P1  F42000
G1 X114.557 Y105.443 Z14.2
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.557 Y94.557 E.32321
G1 X119.443 Y94.557 E.14506
G1 X119.443 Y97 E.07253
G1 X119.443 Y105.443 E.25068
G1 X114.617 Y105.443 E.14328
M204 S250
G1 X114.2 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.2 Y94.2 E.34441
G1 X119.8 Y94.2 E.16627
G1 X119.8 Y97 E.08313
G1 X119.8 Y105.8 E.26128
G1 X114.26 Y105.8 E.16449
G1 E-.8 F1800
G17
G3 Z14.4 I1.217 J0 P1  F42000
G1 X114.861 Y96.605
G1 Z14
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.861 Y95.177 E.04241
G1 X116.04 Y94.861 E.03625
G1 X116.435 Y94.861 E.01174
G1 X119.139 Y97.565 E.11354
G1 X119.139 Y99.575 E.05969
G1 X114.861 Y100.722 E.13153
G1 X114.861 Y100.861 E.00412
G1 X119.139 Y105.139 E.17967
G1 X116.1 Y105.139 E.09025
G1 X118.854 Y94.861 E.31596
G1 X119.139 Y94.861 E.00847
G1 X119.139 Y96.004 E.03394
G1 E-.8 F1800
M204 S500
G17
G3 Z14.4 I-.094 J-1.213 P1  F42000
G1 X105.757 Y97.043 Z14.4
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X105.757 Y94.557 E.07381
G1 X108.243 Y94.557 E.07381
M73 P78 R6
G1 X108.243 Y95.8 E.0369
G1 X108.243 Y97.043 E.0369
G1 X105.817 Y97.043 E.07203
M204 S250
G1 X105.4 Y97.4 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X105.4 Y94.2 E.09501
G1 X108.6 Y94.2 E.09501
G1 X108.6 Y95.8 E.0475
G1 X108.6 Y97.4 E.04751
G1 X105.46 Y97.4 E.09323
G1 X106.114 Y96.686 F42000
; FEATURE: Internal solid infill
G1 F1680.343
M204 S6000
G1 X107.886 Y96.686 E.0526
G1 X107.886 Y94.914 E.0526
G1 X106.114 Y94.914 E.0526
G1 X106.114 Y96.626 E.05082
M204 S500
G1 X106.471 Y96.329 F42000
G1 F1680.343
M204 S6000
G1 X107.529 Y96.329 E.0314
G1 X107.529 Y95.271 E.0314
G1 X106.471 Y95.271 E.0314
G1 X106.471 Y96.269 E.02962
M204 S500
G1 X106.825 Y95.975 F42000
; LINE_WIDTH: 0.39318
G1 F1713.013
M204 S6000
G1 X107.175 Y95.975 E.0102
G1 X107.175 Y95.625 E.0102
G1 X106.825 Y95.625 E.0102
G1 X106.825 Y95.915 E.00845
G1 E-.8 F1800
M204 S500
G17
G3 Z14.4 I.014 J-1.217 P1  F42000
G1 X100.643 Y95.843 Z14.4
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X99.357 Y95.843 E.03818
G1 X99.357 Y94.557 E.03818
G1 X100.643 Y94.557 E.03818
G1 X100.643 Y95.2 E.01909
G1 X100.643 Y95.783 E.01731
M204 S250
G1 X101 Y96.2 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X99 Y96.2 E.05938
G1 X99 Y94.2 E.05938
G1 X101 Y94.2 E.05938
G1 X101 Y95.2 E.02969
G1 X101 Y96.14 E.02791
G1 X99.768 Y95.432 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.50733
G1 F1291.962
M204 S6000
G1 X100.232 Y95.432 E.01793
G1 X100.232 Y94.968 E.01793
G1 X99.768 Y94.968 E.01793
G1 X99.768 Y95.372 E.01562
G1 E-.8 F1800
M204 S500
G17
G3 Z14.4 I.063 J-1.215 P1  F42000
G1 X92.789 Y95.011 Z14.4
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.46438
G1 F1423.623
M204 S6000
G1 X92.789 Y94.589 E.01477
G1 X93.211 Y94.589 E.01477
G1 X93.211 Y94.8 E.00738
G1 X93.211 Y95.011 E.00738
G1 X92.849 Y95.011 E.01267
M204 S250
G1 X92.4 Y95.4 F42000
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S500
G1 X92.4 Y94.2 E.03563
G1 X93.6 Y94.2 E.03563
G1 X93.6 Y94.8 E.01781
G1 X93.6 Y95.4 E.01781
G1 X92.46 Y95.4 E.03385
G1 E-.8 F1800
G17
G3 Z14.4 I-.998 J-.697 P1  F42000
G1 X85.443 Y105.443 Z14.4
G1 Z14
G1 E.8 F1800
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E.14506
G1 X80.557 Y94.557 E.32321
G1 X85.443 Y94.557 E.14506
G1 X85.443 Y97 E.07253
G1 X85.443 Y105.383 E.24889
M204 S250
G1 X85.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E.16627
G1 X80.2 Y94.2 E.34441
G1 X85.8 Y94.2 E.16627
G1 X85.8 Y97 E.08313
G1 X85.8 Y105.74 E.2595
G1 E-.8 F1800
G17
G3 Z14.4 I1.213 J-.098 P1  F42000
G1 X85.139 Y97.595 Z14.4
G1 Z14
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X80.861 Y98.742 E.13153
G1 X80.861 Y97.16 E.04697
G1 X85.139 Y101.439 E.17967
G1 X85.139 Y103.14 E.05053
G1 X80.861 Y104.287 E.13153
G1 X80.861 Y104.735 E.01329
G1 X81.265 Y105.139 E.017
G1 X82.829 Y105.139 E.04643
G1 X85.139 Y96.517 E.26504
G1 X85.139 Y95.089 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 14.2
; LAYER_HEIGHT: 0.2
M106 S175.95
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z14.4 I-.408 J1.146 P1  F42000
G1 X114.199 Y105.443 Z14.4
G1 Z14.2
M73 P79 R6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X114.129 Y105.443 E.00208
G1 X114.046 Y105.443 E.00244
G1 X113.964 Y105.443 E.00244
G1 X113.882 Y105.443 E.00244
G1 X113.8 Y105.443 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X86.2 Y105.443 E.81946
M106 S175.95
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X86.1 Y105.443 E.00297
G1 X86 Y105.443 E.00297
G1 X85.9 Y105.443 E.00297
G1 X85.8 Y105.443 E.00297
G1 X85.7 Y105.443 E.00297
G1 X85.6 Y105.443 E.00297
G1 X85.5 Y105.443 E.00297
G1 X85.4 Y105.443 E.00297
G1 X85.3 Y105.443 E.00297
G1 X85.2 Y105.443 E.00297
G1 X85.1 Y105.443 E.00297
G1 X85 Y105.443 E.00297
G1 X84.9 Y105.443 E.00297
G1 X84.8 Y105.443 E.00297
G1 X84.7 Y105.443 E.00297
G1 X84.6 Y105.443 E.00297
G1 X84.5 Y105.443 E.00297
G1 X84.4 Y105.443 E.00297
G1 X84.3 Y105.443 E.00297
G1 X80.557 Y105.443 E.11113
G1 X80.557 Y94.557 E.32321
G1 X84.639 Y94.557 E.1212
G1 X84.721 Y94.557 E.00244
G1 X84.804 Y94.557 E.00244
G1 X84.886 Y94.557 E.00244
G1 X84.968 Y94.557 E.00244
G1 X85.05 Y94.557 E.00244
G1 X85.132 Y94.557 E.00244
G1 X85.214 Y94.557 E.00244
G1 X85.296 Y94.557 E.00244
G1 X85.379 Y94.557 E.00244
G1 X85.461 Y94.557 E.00244
G1 X85.543 Y94.557 E.00244
G1 X85.625 Y94.557 E.00244
G1 X85.707 Y94.557 E.00244
G1 X85.789 Y94.557 E.00244
G1 X85.871 Y94.557 E.00244
G1 X85.954 Y94.557 E.00244
G1 X86.036 Y94.557 E.00244
G1 X86.118 Y94.557 E.00244
G1 X86.2 Y94.557 E.00244
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X92 Y94.557 E.1722
M106 S175.95
; FEATURE: Inner wall
M106 S255
G1 F600
M204 S6000
G1 X94 Y94.557 E.05938
M106 S175.95
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X98.6 Y94.557 E.13658
M106 S175.95
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X98.7 Y94.557 E.00297
G1 X98.8 Y94.557 E.00297
G1 X98.9 Y94.557 E.00297
G1 X99 Y94.557 E.00297
G1 X99.1 Y94.557 E.00297
G1 X99.2 Y94.557 E.00297
G1 X99.3 Y94.557 E.00297
G1 X99.4 Y94.557 E.00297
G1 X99.5 Y94.557 E.00297
G1 X99.6 Y94.557 E.00297
G1 X99.7 Y94.557 E.00297
G1 X99.8 Y94.557 E.00297
G1 X99.9 Y94.557 E.00297
G1 X100 Y94.557 E.00297
G1 X100.1 Y94.557 E.00297
G1 X100.2 Y94.557 E.00297
G1 X100.3 Y94.557 E.00297
G1 X100.4 Y94.557 E.00297
G1 X100.5 Y94.557 E.00297
G1 X100.64 Y94.557 E.00416
G1 X100.68 Y94.557 E.00119
G1 X100.72 Y94.557 E.00119
G1 X100.76 Y94.557 E.00119
G1 X100.8 Y94.557 E.00119
G1 X100.84 Y94.557 E.00119
G1 X100.88 Y94.557 E.00119
G1 X100.92 Y94.557 E.00119
G1 X100.96 Y94.557 E.00119
G1 X101 Y94.557 E.00119
G1 X101.04 Y94.557 E.00119
G1 X101.08 Y94.557 E.00119
G1 X101.12 Y94.557 E.00119
G1 X101.16 Y94.557 E.00119
G1 X101.2 Y94.557 E.00119
G1 X101.24 Y94.557 E.00119
G1 X101.28 Y94.557 E.00119
G1 X101.32 Y94.557 E.00119
G1 X101.36 Y94.557 E.00119
G1 X101.4 Y94.557 E.00119
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X105 Y94.557 E.10689
M106 S175.95
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X105.1 Y94.557 E.00297
G1 X105.2 Y94.557 E.00297
G1 X105.3 Y94.557 E.00297
G1 X105.4 Y94.557 E.00297
G1 X105.5 Y94.557 E.00297
G1 X105.6 Y94.557 E.00297
G1 X105.7 Y94.557 E.00297
G1 X105.8 Y94.557 E.00297
G1 X105.9 Y94.557 E.00297
G1 X106 Y94.557 E.00297
G1 X106.1 Y94.557 E.00297
G1 X106.2 Y94.557 E.00297
G1 X106.3 Y94.557 E.00297
G1 X106.4 Y94.557 E.00297
G1 X106.5 Y94.557 E.00297
G1 X106.6 Y94.557 E.00297
G1 X106.7 Y94.557 E.00297
G1 X106.8 Y94.557 E.00297
G1 X106.9 Y94.557 E.00297
G1 X107.1 Y94.557 E.00594
G1 X107.2 Y94.557 E.00297
G1 X107.3 Y94.557 E.00297
G1 X107.4 Y94.557 E.00297
G1 X107.5 Y94.557 E.00297
G1 X107.6 Y94.557 E.00297
G1 X107.7 Y94.557 E.00297
G1 X107.8 Y94.557 E.00297
G1 X107.9 Y94.557 E.00297
G1 X108 Y94.557 E.00297
G1 X108.1 Y94.557 E.00297
G1 X108.2 Y94.557 E.00297
G1 X108.3 Y94.557 E.00297
G1 X108.4 Y94.557 E.00297
G1 X108.5 Y94.557 E.00297
G1 X108.6 Y94.557 E.00297
G1 X108.7 Y94.557 E.00297
G1 X108.8 Y94.557 E.00297
G1 X108.9 Y94.557 E.00297
G1 X109 Y94.557 E.00297
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X113.8 Y94.557 E.14251
M106 S175.95
; FEATURE: Inner wall
G1 F1680.343
M204 S6000
G1 X113.9 Y94.557 E.00297
G1 X114 Y94.557 E.00297
G1 X114.1 Y94.557 E.00297
G1 X114.2 Y94.557 E.00297
G1 X114.3 Y94.557 E.00297
G1 X114.4 Y94.557 E.00297
G1 X114.5 Y94.557 E.00297
G1 X114.6 Y94.557 E.00297
G1 X114.7 Y94.557 E.00297
G1 X114.8 Y94.557 E.00297
G1 X114.9 Y94.557 E.00297
G1 X115 Y94.557 E.00297
G1 X115.1 Y94.557 E.00297
G1 X115.2 Y94.557 E.00297
G1 X115.3 Y94.557 E.00297
G1 X115.4 Y94.557 E.00297
G1 X115.5 Y94.557 E.00297
G1 X115.6 Y94.557 E.00297
G1 X115.7 Y94.557 E.00297
G1 X119.443 Y94.557 E.11113
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.443 E.1616
G1 X115.361 Y105.443 E.1212
G1 X115.279 Y105.443 E.00244
G1 X115.197 Y105.443 E.00244
G1 X115.114 Y105.443 E.00244
G1 X115.032 Y105.443 E.00244
G1 X114.95 Y105.443 E.00244
G1 X114.868 Y105.443 E.00244
G1 X114.786 Y105.443 E.00244
G1 X114.704 Y105.443 E.00244
G1 X114.621 Y105.443 E.00244
G1 X114.539 Y105.443 E.00244
G1 X114.457 Y105.443 E.00244
G1 X114.375 Y105.443 E.00244
G1 X114.293 Y105.443 E.00244
G1 X114.259 Y105.443 E.00102
M204 S250
G1 X114.199 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X114.1 Y105.8 E.00293
G1 X114 Y105.8 E.00297
G1 X113.9 Y105.8 E.00297
G1 X113.8 Y105.8 E.00297
M204 S250
G1 X113.8 Y105.8 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X86.2 Y105.8 E.81946
M106 S175.95
; FEATURE: Outer wall
G1 F1680.343
G1 X86.1 Y105.8 E.00297
G1 X86 Y105.8 E.00297
G1 X85.9 Y105.8 E.00297
G1 X85.8 Y105.8 E.00297
G1 X85.7 Y105.8 E.00297
G1 X85.6 Y105.8 E.00297
G1 X85.5 Y105.8 E.00297
G1 X85.4 Y105.8 E.00297
G1 X85.3 Y105.8 E.00297
G1 X85.2 Y105.8 E.00297
G1 X85.1 Y105.8 E.00297
G1 X85 Y105.8 E.00297
G1 X84.9 Y105.8 E.00297
G1 X84.8 Y105.8 E.00297
G1 X84.7 Y105.8 E.00297
G1 X84.6 Y105.8 E.00297
G1 X84.5 Y105.8 E.00297
G1 X84.4 Y105.8 E.00297
G1 X84.3 Y105.8 E.00297
G1 X80.2 Y105.8 E.12173
G1 X80.2 Y94.2 E.34441
G1 X84.3 Y94.2 E.12173
G1 X84.4 Y94.2 E.00297
G1 X84.5 Y94.2 E.00297
G1 X84.6 Y94.2 E.00297
G1 X84.7 Y94.2 E.00297
G1 X84.8 Y94.2 E.00297
G1 X84.9 Y94.2 E.00297
G1 X85 Y94.2 E.00297
G1 X85.1 Y94.2 E.00297
G1 X85.2 Y94.2 E.00297
G1 X85.3 Y94.2 E.00297
G1 X85.4 Y94.2 E.00297
G1 X85.5 Y94.2 E.00297
G1 X85.6 Y94.2 E.00297
G1 X85.7 Y94.2 E.00297
G1 X85.8 Y94.2 E.00297
G1 X85.9 Y94.2 E.00297
G1 X86 Y94.2 E.00297
G1 X86.1 Y94.2 E.00297
G1 X86.2 Y94.2 E.00297
M204 S250
G1 X86.2 Y94.2 F42000
; FEATURE: Overhang wall
M106 S255
G1 F1500
M204 S500
G1 X92 Y94.2 E.1722
M106 S175.95
; FEATURE: Outer wall
M106 S255
G1 F600
G1 X94 Y94.2 E.05938
M106 S175.95
; FEATURE: Overhang wall
M106 S255
G1 F1500
G1 X98.6 Y94.2 E.13658
M106 S175.95
; FEATURE: Outer wall
G1 F1680.343
G1 X98.7 Y94.2 E.00297
G1 X98.8 Y94.2 E.00297
G1 X98.9 Y94.2 E.00297
G1 X99 Y94.2 E.00297
G1 X99.1 Y94.2 E.00297
G1 X99.2 Y94.2 E.00297
G1 X99.3 Y94.2 E.00297
G1 X99.4 Y94.2 E.00297
G1 X99.5 Y94.2 E.00297
G1 X99.6 Y94.2 E.00297
G1 X99.7 Y94.2 E.00297
G1 X99.8 Y94.2 E.00297
G1 X99.9 Y94.2 E.00297
G1 X100 Y94.2 E.00297
G1 X100.1 Y94.2 E.00297
G1 X100.2 Y94.2 E.00297
G1 X100.3 Y94.2 E.00297
G1 X100.4 Y94.2 E.00297
G1 X100.5 Y94.2 E.00297
G1 X100.64 Y94.2 E.00416
G1 X100.68 Y94.2 E.00119
G1 X100.72 Y94.2 E.00119
G1 X100.76 Y94.2 E.00119
G1 X100.8 Y94.2 E.00119
G1 X100.84 Y94.2 E.00119
G1 X100.88 Y94.2 E.00119
G1 X100.92 Y94.2 E.00119
G1 X100.96 Y94.2 E.00119
G1 X101 Y94.2 E.00119
G1 X101.04 Y94.2 E.00119
G1 X101.08 Y94.2 E.00119
G1 X101.12 Y94.2 E.00119
G1 X101.16 Y94.2 E.00119
G1 X101.2 Y94.2 E.00119
G1 X101.24 Y94.2 E.00119
G1 X101.28 Y94.2 E.00119
G1 X101.32 Y94.2 E.00119
G1 X101.36 Y94.2 E.00119
G1 X101.4 Y94.2 E.00119
; FEATURE: Overhang wall
M106 S255
G1 F1500
G1 X105 Y94.2 E.10689
M106 S175.95
; FEATURE: Outer wall
G1 F1680.343
G1 X105.1 Y94.2 E.00297
G1 X105.2 Y94.2 E.00297
G1 X105.3 Y94.2 E.00297
G1 X105.4 Y94.2 E.00297
G1 X105.5 Y94.2 E.00297
G1 X105.6 Y94.2 E.00297
G1 X105.7 Y94.2 E.00297
G1 X105.8 Y94.2 E.00297
G1 X105.9 Y94.2 E.00297
G1 X106 Y94.2 E.00297
G1 X106.1 Y94.2 E.00297
G1 X106.2 Y94.2 E.00297
G1 X106.3 Y94.2 E.00297
G1 X106.4 Y94.2 E.00297
G1 X106.5 Y94.2 E.00297
G1 X106.6 Y94.2 E.00297
G1 X106.7 Y94.2 E.00297
G1 X106.8 Y94.2 E.00297
G1 X106.9 Y94.2 E.00297
G1 X107.1 Y94.2 E.00594
G1 X107.2 Y94.2 E.00297
G1 X107.3 Y94.2 E.00297
G1 X107.4 Y94.2 E.00297
G1 X107.5 Y94.2 E.00297
G1 X107.6 Y94.2 E.00297
G1 X107.7 Y94.2 E.00297
G1 X107.8 Y94.2 E.00297
G1 X107.9 Y94.2 E.00297
G1 X108 Y94.2 E.00297
G1 X108.1 Y94.2 E.00297
G1 X108.2 Y94.2 E.00297
G1 X108.3 Y94.2 E.00297
G1 X108.4 Y94.2 E.00297
G1 X108.5 Y94.2 E.00297
G1 X108.6 Y94.2 E.00297
G1 X108.7 Y94.2 E.00297
G1 X108.8 Y94.2 E.00297
G1 X108.9 Y94.2 E.00297
G1 X109 Y94.2 E.00297
; FEATURE: Overhang wall
M106 S255
G1 F1500
G1 X113.8 Y94.2 E.14251
M106 S175.95
; FEATURE: Outer wall
G1 F1680.343
G1 X113.9 Y94.2 E.00297
G1 X114 Y94.2 E.00297
G1 X114.1 Y94.2 E.00297
G1 X114.2 Y94.2 E.00297
G1 X114.3 Y94.2 E.00297
G1 X114.4 Y94.2 E.00297
G1 X114.5 Y94.2 E.00297
G1 X114.6 Y94.2 E.00297
G1 X114.7 Y94.2 E.00297
G1 X114.8 Y94.2 E.00297
G1 X114.9 Y94.2 E.00297
G1 X115 Y94.2 E.00297
G1 X115.1 Y94.2 E.00297
G1 X115.2 Y94.2 E.00297
G1 X115.3 Y94.2 E.00297
G1 X115.4 Y94.2 E.00297
G1 X115.5 Y94.2 E.00297
G1 X115.6 Y94.2 E.00297
G1 X115.7 Y94.2 E.00297
G1 X119.8 Y94.2 E.12173
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.8 E.17221
G1 X115.7 Y105.8 E.12173
G1 X115.6 Y105.8 E.00297
G1 X115.5 Y105.8 E.00297
G1 X115.4 Y105.8 E.00297
G1 X115.3 Y105.8 E.00297
G1 X115.2 Y105.8 E.00297
G1 X115.1 Y105.8 E.00297
G1 X115 Y105.8 E.00297
G1 X114.9 Y105.8 E.00297
G1 X114.8 Y105.8 E.00297
G1 X114.7 Y105.8 E.00297
G1 X114.6 Y105.8 E.00297
G1 X114.5 Y105.8 E.00297
G1 X114.4 Y105.8 E.00297
G1 X114.3 Y105.8 E.00297
G1 X114.259 Y105.8 E.00123
G1 E-.8 F1800
G17
G3 Z14.6 I1.217 J0 P1  F42000
G1 X114.739 Y105.134
G1 Z14.2
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40967
M106 S255
G1 F1500
M204 S6000
G1 X85.422 Y105.134 E.89405
G1 X85.422 Y104.768 E.01118
G1 X114.579 Y104.768 E.88915
G1 X114.579 Y104.401 E.01118
G1 X85.422 Y104.401 E.88915
G1 X85.422 Y104.034 E.01118
G1 X114.579 Y104.034 E.88915
G1 X114.579 Y103.667 E.01118
G1 X85.422 Y103.667 E.88915
G1 X85.422 Y103.301 E.01118
G1 X114.579 Y103.301 E.88915
G1 X114.579 Y102.934 E.01118
G1 X85.422 Y102.934 E.88915
G1 X85.422 Y102.567 E.01118
G1 X114.579 Y102.567 E.88915
G1 X114.579 Y102.2 E.01118
G1 X85.422 Y102.2 E.88915
G1 X85.422 Y101.834 E.01118
G1 X114.579 Y101.834 E.88915
M73 P80 R6
G1 X114.579 Y101.467 E.01118
G1 X85.422 Y101.467 E.88915
G1 X85.422 Y101.1 E.01118
G1 X114.579 Y101.1 E.88915
G1 X114.579 Y100.733 E.01118
G1 X85.422 Y100.733 E.88915
G1 X85.422 Y100.367 E.01118
G1 X114.579 Y100.367 E.88915
G1 X114.579 Y100 E.01118
G1 X85.422 Y100 E.88915
G1 X85.422 Y99.633 E.01118
G1 X114.579 Y99.633 E.88915
G1 X114.579 Y99.266 E.01118
G1 X85.422 Y99.266 E.88915
G1 X85.422 Y98.9 E.01118
G1 X114.579 Y98.9 E.88915
G1 X114.579 Y98.533 E.01118
G1 X85.422 Y98.533 E.88915
G1 X85.422 Y98.166 E.01118
G1 X114.579 Y98.166 E.88915
G1 X114.579 Y97.799 E.01118
G1 X85.422 Y97.799 E.88915
G1 X85.422 Y97.433 E.01118
G1 X114.579 Y97.433 E.88915
G1 X114.579 Y97.066 E.01118
G1 X85.422 Y97.066 E.88915
G1 X85.422 Y96.699 E.01118
G1 X114.739 Y96.699 E.89405
M106 S175.95
M204 S500
G1 X114.936 Y96.731 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.936 Y95.303 E.04241
G1 X116.586 Y94.861 E.05074
G1 X116.635 Y94.861 E.00146
G1 X119.139 Y97.365 E.10515
G1 X119.139 Y99.722 E.06998
G1 X114.936 Y100.848 E.12922
G1 X114.936 Y100.736 E.00333
G1 X119.139 Y104.939 E.17652
G1 X119.139 Y105.139 E.00594
G1 X115.953 Y105.139 E.0946
G1 X118.708 Y94.861 E.31596
G1 X119.139 Y94.861 E.01282
G1 X119.139 Y95.857 E.02959
M204 S500
G1 X114.739 Y94.865 F42000
; FEATURE: Bridge
; LINE_WIDTH: 0.40967
M106 S255
G1 F1500
M204 S6000
G1 X107.686 Y94.865 E.21509
G1 X107.686 Y95.232 E.01118
G1 X114.579 Y95.232 E.21019
G1 X114.579 Y95.599 E.01118
M73 P81 R6
G1 X107.686 Y95.599 E.21019
G1 X107.686 Y95.966 E.01118
G1 X114.579 Y95.966 E.21019
G1 X114.579 Y96.332 E.01118
G1 X85.422 Y96.332 E.88915
G1 X85.422 Y95.966 E.01118
G1 X106.314 Y95.966 E.63713
G1 X106.314 Y95.599 E.01118
G1 X85.422 Y95.599 E.63713
G1 X85.422 Y95.232 E.01118
G1 X106.314 Y95.232 E.63713
G1 X106.314 Y94.865 E.01118
G1 X85.261 Y94.865 E.64203
M106 S175.95
M204 S500
G1 X85.026 Y94.861 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.064 Y94.861 E.00113
G1 X85.064 Y96.251 E.04128
G1 X82.683 Y105.139 E.27323
G1 X81.465 Y105.139 E.03614
G1 X80.861 Y104.535 E.0254
G1 X80.861 Y104.433 E.00301
G1 X85.064 Y103.307 E.12922
G1 X85.064 Y101.164 E.06364
G1 X80.861 Y96.96 E.17652
G1 X80.861 Y98.888 E.05725
G1 X85.064 Y97.762 E.12922
G1 X85.064 Y99.19 E.04241
G1 E-.8 F1800
M204 S500
G17
G3 Z14.6 I.174 J1.204 P1  F42000
G1 X106.746 Y96.054 Z14.6
G1 Z14.2
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.55022
G1 F1182.732
M204 S6000
G1 X107.254 Y96.054 E.0214
G1 X107.254 Y94.989 E.0449
G1 X106.746 Y94.989 E.0214
G1 X106.746 Y95.994 E.04237
; CHANGE_LAYER
; Z_HEIGHT: 14.4
; LAYER_HEIGHT: 0.2
M106 S178.5
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z14.6 I-.727 J.976 P1  F42000
G1 X119.443 Y105.443 Z14.6
G1 Z14.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
M73 P81 R5
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z14.8 I1.217 J0 P1  F42000
G1 X113.974 Y105.3
G1 Z14.4
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40156
G1 F1672.987
M204 S6000
G1 X114.579 Y104.695 E.02551
G1 X114.579 Y104.188 E.01512
G1 X113.627 Y105.139 E.04012
G1 X113.12 Y105.139 E.01513
G1 X114.579 Y103.681 E.06151
G1 X114.579 Y103.174 E.01513
G1 X112.613 Y105.139 E.0829
G1 X112.106 Y105.139 E.01513
G1 X114.579 Y102.667 E.10429
G1 X114.579 Y102.159 E.01512
G1 X111.598 Y105.139 E.12568
G1 X111.091 Y105.139 E.01512
G1 X114.579 Y101.652 E.14707
G1 X114.579 Y101.145 E.01512
G1 X110.584 Y105.139 E.16846
G1 X110.077 Y105.139 E.01512
G1 X114.579 Y100.638 E.18985
G1 X114.579 Y100.131 E.01512
G1 X109.57 Y105.139 E.21124
G1 X109.062 Y105.139 E.01513
G1 X114.579 Y99.623 E.23263
G1 X114.579 Y99.116 E.01512
G1 X108.555 Y105.139 E.25402
G1 X108.048 Y105.139 E.01512
G1 X114.579 Y98.609 E.27541
G1 X114.579 Y98.102 E.01512
G1 X107.541 Y105.139 E.2968
G1 X107.034 Y105.139 E.01512
G1 X114.579 Y97.595 E.31819
G1 X114.579 Y97.087 E.01513
G1 X106.527 Y105.139 E.33958
G1 X106.019 Y105.139 E.01513
M73 P82 R5
G1 X114.579 Y96.58 E.36097
G1 X114.579 Y96.073 E.01512
G1 X105.512 Y105.139 E.38236
G1 X105.005 Y105.139 E.01512
G1 X114.579 Y95.566 E.40375
G1 X114.579 Y95.059 E.01512
G1 X104.498 Y105.139 E.42514
G1 X103.991 Y105.139 E.01512
G1 X114.269 Y94.861 E.43349
G1 X113.762 Y94.861 E.01512
G1 X103.483 Y105.139 E.43349
G1 X102.976 Y105.139 E.01512
G1 X113.255 Y94.861 E.43349
G1 X112.748 Y94.861 E.01512
G1 X102.469 Y105.139 E.43349
G1 X101.962 Y105.139 E.01513
G1 X112.241 Y94.861 E.43349
G1 X111.733 Y94.861 E.01512
G1 X101.455 Y105.139 E.43349
G1 X100.947 Y105.139 E.01512
G1 X111.226 Y94.861 E.43349
G1 X110.719 Y94.861 E.01513
G1 X100.44 Y105.139 E.43349
G1 X99.933 Y105.139 E.01513
G1 X110.212 Y94.861 E.43349
G1 X109.705 Y94.861 E.01512
G1 X99.426 Y105.139 E.43349
G1 X98.919 Y105.139 E.01512
G1 X109.197 Y94.861 E.43349
G1 X108.69 Y94.861 E.01512
G1 X98.411 Y105.139 E.43349
G1 X97.904 Y105.139 E.01512
G1 X108.183 Y94.861 E.43349
G1 X107.676 Y94.861 E.01513
G1 X97.397 Y105.139 E.43349
G1 X96.89 Y105.139 E.01512
G1 X107.169 Y94.861 E.43349
G1 X106.662 Y94.861 E.01512
G1 X96.383 Y105.139 E.43349
G1 X95.875 Y105.139 E.01513
G1 X106.154 Y94.861 E.43349
G1 X105.647 Y94.861 E.01512
G1 X95.368 Y105.139 E.43349
G1 X94.861 Y105.139 E.01512
G1 X105.14 Y94.861 E.43349
G1 X104.633 Y94.861 E.01512
G1 X94.354 Y105.139 E.43349
G1 X93.847 Y105.139 E.01512
G1 X104.126 Y94.861 E.43349
G1 X103.618 Y94.861 E.01513
G1 X93.339 Y105.139 E.43349
G1 X92.832 Y105.139 E.01513
G1 X103.111 Y94.861 E.43349
G1 X102.604 Y94.861 E.01512
G1 X92.325 Y105.139 E.43349
G1 X91.818 Y105.139 E.01512
G1 X102.097 Y94.861 E.43349
G1 X101.59 Y94.861 E.01512
G1 X91.311 Y105.139 E.43349
G1 X90.803 Y105.139 E.01512
G1 X101.082 Y94.861 E.43349
G1 X100.575 Y94.861 E.01513
G1 X90.296 Y105.139 E.43349
G1 X89.789 Y105.139 E.01512
G1 X100.068 Y94.861 E.43349
G1 X99.561 Y94.861 E.01513
G1 X89.282 Y105.139 E.43349
G1 X88.775 Y105.139 E.01513
G1 X99.054 Y94.861 E.43349
G1 X98.546 Y94.861 E.01513
G1 X88.268 Y105.139 E.43349
G1 X87.76 Y105.139 E.01512
M73 P83 R5
G1 X98.039 Y94.861 E.43349
G1 X97.532 Y94.861 E.01513
G1 X87.253 Y105.139 E.43349
G1 X86.746 Y105.139 E.01512
G1 X97.025 Y94.861 E.43349
G1 X96.518 Y94.861 E.01512
G1 X86.239 Y105.139 E.43349
G1 X85.732 Y105.139 E.01513
G1 X96.01 Y94.861 E.43349
G1 X95.503 Y94.861 E.01512
G1 X85.422 Y104.942 E.42518
G1 X85.422 Y104.435 E.01513
G1 X94.996 Y94.861 E.40379
G1 X94.489 Y94.861 E.01513
G1 X85.422 Y103.928 E.3824
G1 X85.422 Y103.421 E.01513
G1 X93.982 Y94.861 E.36101
G1 X93.474 Y94.861 E.01512
G1 X85.422 Y102.914 E.33962
G1 X85.422 Y102.406 E.01512
G1 X92.967 Y94.861 E.31823
G1 X92.46 Y94.861 E.01512
G1 X85.422 Y101.899 E.29684
G1 X85.422 Y101.392 E.01512
G1 X91.953 Y94.861 E.27545
G1 X91.446 Y94.861 E.01513
G1 X85.422 Y100.885 E.25406
G1 X85.422 Y100.378 E.01513
G1 X90.939 Y94.861 E.23267
G1 X90.431 Y94.861 E.01513
G1 X85.422 Y99.87 E.21128
G1 X85.422 Y99.363 E.01512
G1 X89.924 Y94.861 E.18989
G1 X89.417 Y94.861 E.01512
G1 X85.422 Y98.856 E.1685
G1 X85.422 Y98.349 E.01513
G1 X88.91 Y94.861 E.14711
G1 X88.403 Y94.861 E.01512
G1 X85.422 Y97.842 E.12572
G1 X85.422 Y97.334 E.01513
G1 X87.895 Y94.861 E.10433
G1 X87.388 Y94.861 E.01513
G1 X85.422 Y96.827 E.08294
G1 X85.422 Y96.32 E.01512
G1 X86.881 Y94.861 E.06155
G1 X86.374 Y94.861 E.01512
G1 X85.422 Y95.813 E.04016
G1 X85.422 Y95.306 E.01512
G1 X86.027 Y94.7 E.02555
M204 S500
G1 X84.48 Y94.861 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.064 Y94.861 E.01736
G1 X85.064 Y95.704 E.02505
G1 X82.536 Y105.139 E.29002
G1 X81.665 Y105.139 E.02585
G1 X80.861 Y104.335 E.0338
G1 X80.861 Y104.58 E.00728
G1 X85.064 Y103.453 E.12922
G1 X85.064 Y100.964 E.07392
G1 X80.861 Y96.76 E.17652
G1 X80.861 Y99.035 E.06754
G1 X85.064 Y97.908 E.12922
G1 X85.064 Y99.336 E.04241
M204 S500
G1 X114.936 Y96.878 F42000
G1 F1680.297
M204 S6000
G1 X114.936 Y95.449 E.04241
G1 X117.133 Y94.861 E.06753
G1 X116.835 Y94.861 E.00883
G1 X119.139 Y97.165 E.09675
G1 X119.139 Y99.868 E.08027
G1 X114.936 Y100.994 E.12922
G1 X114.936 Y100.536 E.01362
G1 X119.139 Y104.739 E.17652
G1 X119.139 Y105.139 E.01188
G1 X115.807 Y105.139 E.09894
G1 X118.561 Y94.861 E.31596
G1 X119.139 Y94.861 E.01717
G1 X119.139 Y95.711 E.02524
; CHANGE_LAYER
; Z_HEIGHT: 14.6
; LAYER_HEIGHT: 0.200001
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z14.8 I-1.216 J.038 P1  F42000
G1 X119.443 Y105.443 Z14.8
G1 Z14.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
M73 P84 R5
G3 Z15 I1.217 J0 P1  F42000
G1 X114.271 Y97.202
G1 Z14.6
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X114.271 Y95.774 E.04241
G1 X117.679 Y94.861 E.10475
G1 X118.415 Y94.861 E.02185
G1 X115.661 Y105.139 E.31596
G1 X119.139 Y105.139 E.10329
G1 X119.139 Y104.539 E.01781
G1 X114.271 Y99.671 E.20441
G1 X114.271 Y101.319 E.04891
G1 X119.139 Y100.014 E.14964
G1 X119.139 Y96.965 E.09055
G1 X117.035 Y94.861 E.08835
M204 S500
G1 X114.075 Y95.469 F42000
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.40336
G1 F1664.632
M204 S6000
G1 X113.466 Y94.861 E.02579
G1 X112.957 Y94.861 E.01528
G1 X113.914 Y95.818 E.04059
G1 X113.914 Y96.328 E.01528
G1 X112.447 Y94.861 E.06219
G1 X111.937 Y94.861 E.01528
G1 X113.914 Y96.838 E.0838
G1 X113.914 Y97.347 E.01528
G1 X111.427 Y94.861 E.1054
G1 X110.918 Y94.861 E.01528
G1 X113.914 Y97.857 E.12701
G1 X113.914 Y98.367 E.01528
G1 X110.408 Y94.861 E.14861
G1 X109.898 Y94.861 E.01528
G1 X113.914 Y98.877 E.17022
G1 X113.914 Y99.386 E.01528
G1 X109.388 Y94.861 E.19182
G1 X108.879 Y94.861 E.01528
G1 X113.914 Y99.896 E.21343
G1 X113.914 Y100.406 E.01528
G1 X108.369 Y94.861 E.23503
G1 X107.859 Y94.861 E.01528
G1 X113.914 Y100.916 E.25664
G1 X113.914 Y101.425 E.01528
G1 X107.35 Y94.861 E.27824
G1 X106.84 Y94.861 E.01528
G1 X113.914 Y101.935 E.29985
G1 X113.914 Y102.445 E.01528
G1 X106.33 Y94.861 E.32146
G1 X105.82 Y94.861 E.01528
G1 X113.914 Y102.954 E.34306
G1 X113.914 Y103.464 E.01528
G1 X105.311 Y94.861 E.36467
G1 X104.801 Y94.861 E.01528
G1 X113.914 Y103.974 E.38627
G1 X113.914 Y104.484 E.01528
G1 X104.291 Y94.861 E.40788
G1 X103.781 Y94.861 E.01528
G1 X113.914 Y104.993 E.42948
G1 X113.914 Y105.139 E.00438
G1 X113.55 Y105.139 E.0109
G1 X103.272 Y94.861 E.43567
G1 X102.762 Y94.861 E.01528
G1 X113.041 Y105.139 E.43567
G1 X112.531 Y105.139 E.01528
G1 X102.252 Y94.861 E.43567
G1 X101.742 Y94.861 E.01528
G1 X112.021 Y105.139 E.43567
G1 X111.512 Y105.139 E.01528
G1 X101.233 Y94.861 E.43567
G1 X100.723 Y94.861 E.01528
G1 X111.002 Y105.139 E.43567
G1 X110.492 Y105.139 E.01528
G1 X100.213 Y94.861 E.43567
G1 X99.703 Y94.861 E.01528
G1 X109.982 Y105.139 E.43567
G1 X109.473 Y105.139 E.01528
G1 X99.194 Y94.861 E.43567
G1 X98.684 Y94.861 E.01528
M73 P84 R4
G1 X108.963 Y105.139 E.43567
G1 X108.453 Y105.139 E.01528
G1 X98.174 Y94.861 E.43567
G1 X97.664 Y94.861 E.01528
G1 X107.943 Y105.139 E.43567
G1 X107.434 Y105.139 E.01528
G1 X97.155 Y94.861 E.43567
G1 X96.645 Y94.861 E.01528
G1 X106.924 Y105.139 E.43567
G1 X106.414 Y105.139 E.01528
G1 X96.135 Y94.861 E.43567
G1 X95.626 Y94.861 E.01528
G1 X105.904 Y105.139 E.43567
G1 X105.395 Y105.139 E.01528
G1 X95.116 Y94.861 E.43567
G1 X94.606 Y94.861 E.01528
G1 X104.885 Y105.139 E.43567
G1 X104.375 Y105.139 E.01528
G1 X94.096 Y94.861 E.43567
G1 X93.587 Y94.861 E.01528
G1 X103.865 Y105.139 E.43567
G1 X103.356 Y105.139 E.01528
G1 X93.077 Y94.861 E.43567
G1 X92.567 Y94.861 E.01528
M73 P85 R4
G1 X102.846 Y105.139 E.43567
G1 X102.336 Y105.139 E.01528
G1 X92.057 Y94.861 E.43567
G1 X91.548 Y94.861 E.01528
G1 X101.826 Y105.139 E.43567
G1 X101.317 Y105.139 E.01528
G1 X91.038 Y94.861 E.43567
G1 X90.528 Y94.861 E.01528
G1 X100.807 Y105.139 E.43567
G1 X100.297 Y105.139 E.01528
G1 X90.018 Y94.861 E.43567
G1 X89.509 Y94.861 E.01528
G1 X99.788 Y105.139 E.43567
G1 X99.278 Y105.139 E.01528
G1 X88.999 Y94.861 E.43567
G1 X88.489 Y94.861 E.01528
G1 X98.768 Y105.139 E.43567
G1 X98.258 Y105.139 E.01528
G1 X87.979 Y94.861 E.43567
G1 X87.47 Y94.861 E.01528
G1 X97.749 Y105.139 E.43567
G1 X97.239 Y105.139 E.01528
G1 X86.96 Y94.861 E.43567
G1 X86.45 Y94.861 E.01528
G1 X96.729 Y105.139 E.43567
G1 X96.219 Y105.139 E.01528
G1 X86.086 Y95.006 E.42951
G1 X86.086 Y95.516 E.01528
G1 X95.71 Y105.139 E.4079
G1 X95.2 Y105.139 E.01528
G1 X86.086 Y96.025 E.3863
G1 X86.086 Y96.535 E.01528
G1 X94.69 Y105.139 E.36469
G1 X94.18 Y105.139 E.01528
G1 X86.086 Y97.045 E.34309
G1 X86.086 Y97.555 E.01528
G1 X93.671 Y105.139 E.32148
G1 X93.161 Y105.139 E.01528
G1 X86.086 Y98.064 E.29988
G1 X86.086 Y98.574 E.01528
G1 X92.651 Y105.139 E.27827
G1 X92.141 Y105.139 E.01528
G1 X86.086 Y99.084 E.25667
G1 X86.086 Y99.594 E.01528
G1 X91.632 Y105.139 E.23506
G1 X91.122 Y105.139 E.01528
G1 X86.086 Y100.103 E.21346
G1 X86.086 Y100.613 E.01528
G1 X90.612 Y105.139 E.19185
G1 X90.102 Y105.139 E.01528
G1 X86.086 Y101.123 E.17025
G1 X86.086 Y101.633 E.01528
G1 X89.593 Y105.139 E.14864
G1 X89.083 Y105.139 E.01528
G1 X86.086 Y102.142 E.12704
G1 X86.086 Y102.652 E.01528
G1 X88.573 Y105.139 E.10543
G1 X88.064 Y105.139 E.01528
G1 X86.086 Y103.162 E.08382
G1 X86.086 Y103.671 E.01528
G1 X87.554 Y105.139 E.06222
G1 X87.044 Y105.139 E.01528
G1 X86.086 Y104.181 E.04061
G1 X86.086 Y104.691 E.01528
G1 X86.695 Y105.3 E.02582
M204 S500
G1 X85.729 Y96.448 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X85.729 Y97.877 E.04241
G1 X80.861 Y99.181 E.14964
G1 X80.861 Y96.56 E.07783
G1 X85.729 Y101.428 E.20441
G1 X85.729 Y103.422 E.0592
G1 X80.861 Y104.726 E.14964
G1 X80.861 Y104.135 E.01756
G1 X81.865 Y105.139 E.04219
G1 X82.39 Y105.139 E.01557
G1 X85.144 Y94.861 E.31596
G1 X83.716 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 14.8
; LAYER_HEIGHT: 0.2
M106 S193.8
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z15 I-.346 J1.167 P1  F42000
G1 X119.443 Y105.443 Z15
G1 Z14.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
M73 P86 R4
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z15.2 I1.217 J0 P1  F42000
G1 X117.235 Y94.861
G1 Z14.8
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X119.139 Y96.765 E.07995
G1 X119.139 Y100.161 E.10084
G1 X100.559 Y105.139 E.57114
G1 X99.131 Y105.139 E.04241
M204 S500
G1 X94.762 Y105.139 F42000
G1 F1680.297
M204 S6000
G1 X93.334 Y105.139 E.04241
G1 X96.088 Y94.861 E.31596
G1 X94.511 Y94.861 E.04682
G1 X104.79 Y105.139 E.43161
G1 X104.424 Y105.139 E.01086
G1 X107.178 Y94.861 E.31596
G1 X109.661 Y94.861 E.07371
G1 X119.139 Y104.339 E.39802
G1 X119.139 Y105.139 E.02375
G1 X115.514 Y105.139 E.10764
G1 X118.268 Y94.861 E.31596
G1 X118.226 Y94.861 E.00127
G1 X80.861 Y104.872 E1.14855
G1 X80.861 Y103.935 E.02785
G1 X82.065 Y105.139 E.05059
G1 X82.243 Y105.139 E.00528
G1 X84.998 Y94.861 E.31596
G1 X86.936 Y94.861 E.05756
G1 X97.215 Y105.139 E.43161
G1 X98.879 Y105.139 E.0494
G1 X101.633 Y94.861 E.31596
G1 X102.086 Y94.861 E.01344
G1 X112.365 Y105.139 E.43161
G1 X109.969 Y105.139 E.07113
G1 X112.723 Y94.861 E.31596
G1 X114.152 Y94.861 E.04241
M204 S500
G1 X98.959 Y94.861 F42000
G1 F1680.297
M204 S6000
G1 X97.531 Y94.861 E.04241
G1 X80.861 Y99.327 E.51242
G1 X80.861 Y96.36 E.08811
G1 X89.64 Y105.139 E.36866
G1 X87.789 Y105.139 E.05498
G1 X90.543 Y94.861 E.31596
G1 X91.971 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 15
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z15.2 I-.437 J1.136 P1  F42000
G1 X119.443 Y105.443 Z15.2
G1 Z15
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
M73 P87 R4
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z15.4 I1.217 J0 P1  F42000
G1 X116.796 Y105.139
G1 Z15
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.368 Y105.139 E.04241
G1 X118.122 Y94.861 E.31596
M204 S500
G1 X116.007 Y94.861 F42000
G1 F1680.297
M204 S6000
G1 X117.435 Y94.861 E.04241
G1 X119.139 Y96.565 E.07155
G1 X119.139 Y94.861 E.0506
G1 X118.772 Y94.861 E.01091
G1 X80.861 Y105.019 E1.16535
G1 X80.861 Y103.735 E.03813
G1 X82.265 Y105.139 E.05899
G1 X82.097 Y105.139 E.005
G1 X84.851 Y94.861 E.31596
G1 X87.136 Y94.861 E.06784
G1 X97.415 Y105.139 E.43161
G1 X98.732 Y105.139 E.03911
G1 X101.487 Y94.861 E.31596
G1 X102.286 Y94.861 E.02373
G1 X112.565 Y105.139 E.43161
G1 X109.823 Y105.139 E.08141
G1 X112.577 Y94.861 E.31596
G1 X109.861 Y94.861 E.08065
G1 X119.139 Y104.139 E.38962
G1 X119.139 Y100.307 E.11378
G1 X101.105 Y105.139 E.55434
G1 X99.677 Y105.139 E.04241
M204 S500
G1 X94.616 Y105.139 F42000
G1 F1680.297
M204 S6000
G1 X93.187 Y105.139 E.04241
G1 X95.941 Y94.861 E.31596
G1 X94.711 Y94.861 E.03654
G1 X104.99 Y105.139 E.43161
G1 X104.278 Y105.139 E.02115
G1 X107.032 Y94.861 E.31596
G1 X105.603 Y94.861 E.04241
M204 S500
G1 X99.506 Y94.861 F42000
G1 F1680.297
M204 S6000
G1 X98.077 Y94.861 E.04241
G1 X80.861 Y99.474 E.52922
G1 X80.861 Y96.16 E.0984
G1 X89.84 Y105.139 E.37706
G1 X87.642 Y105.139 E.06527
G1 X90.396 Y94.861 E.31596
G1 X91.825 Y94.861 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 15.2
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z15.4 I-.435 J1.136 P1  F42000
G1 X119.443 Y105.443 Z15.4
G1 Z15.2
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
M73 P87 R3
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
M73 P88 R3
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z15.6 I1.217 J0 P1  F42000
G1 X116.745 Y104.782
G1 Z15.2
G1 E.8 F1800
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X115.317 Y104.782 E.04241
G1 X117.88 Y95.218 E.294
G1 X117.638 Y95.218 E.00719
M204 S500
G1 X119.113 Y95.039 F42000
; FEATURE: Floating vertical shell
; LINE_WIDTH: 0.383004
G1 F1764.273
M204 S6000
G1 X119.087 Y94.913 E.00363
G1 X118.961 Y94.887 E.00363
G1 X81.039 Y94.887 E1.07235
G1 X80.913 Y94.913 E.00363
G1 X80.887 Y95.039 E.00363
G1 X80.887 Y104.961 E.28056
G1 X80.913 Y105.087 E.00363
G1 X81.039 Y105.113 E.00363
G1 X118.961 Y105.113 E1.07235
G1 X119.087 Y105.087 E.00363
G1 X119.113 Y104.961 E.00363
G1 X119.113 Y95.099 E.27887
M204 S500
G1 X118.782 Y97.436 F42000
; FEATURE: Sparse infill
; LINE_WIDTH: 0.4
G1 F1680.297
M204 S6000
G1 X118.782 Y96.007 E.04241
G1 X117.985 Y95.218 E.03331
G1 X82.29 Y104.782 E1.09723
G1 X82.638 Y104.782 E.01033
M204 S500
G1 X81.218 Y102.463 F42000
G1 F1680.297
M204 S6000
G1 X81.218 Y103.892 E.04241
G1 X82.108 Y104.782 E.03739
G1 X82.046 Y104.782 E.00184
G1 X84.609 Y95.218 E.294
G1 X83.181 Y95.218 E.04241
M204 S500
G1 X94.565 Y104.782 F42000
G1 F1680.297
M204 S6000
G1 X93.137 Y104.782 E.04241
G1 X95.699 Y95.218 E.294
G1 X95.268 Y95.218 E.0128
G1 X104.833 Y104.782 E.40161
G1 X104.227 Y104.782 E.01799
G1 X106.79 Y95.218 E.294
G1 X105.361 Y95.218 E.04241
M204 S500
G1 X98.719 Y95.218 F42000
G1 F1680.297
M204 S6000
G1 X97.291 Y95.218 E.04241
G1 X81.218 Y99.524 E.49406
G1 X81.218 Y96.317 E.09524
G1 X89.683 Y104.782 E.35546
G1 X87.591 Y104.782 E.0621
G1 X90.154 Y95.218 E.294
G1 X87.693 Y95.218 E.07307
G1 X97.258 Y104.782 E.40161
G1 X98.682 Y104.782 E.04228
G1 X101.245 Y95.218 E.294
G1 X102.843 Y95.218 E.04746
G1 X112.407 Y104.782 E.40161
G1 X109.772 Y104.782 E.07825
G1 X112.335 Y95.218 E.294
G1 X110.418 Y95.218 E.05692
G1 X118.782 Y103.582 E.35123
G1 X118.782 Y100.549 E.09005
G1 X102.985 Y104.782 E.48559
G1 X101.556 Y104.782 E.04241
; CHANGE_LAYER
; Z_HEIGHT: 15.4
; LAYER_HEIGHT: 0.2
M106 S163.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z15.6 I-.045 J1.216 P1  F42000
G1 X119.443 Y105.443 Z15.6
G1 Z15.4
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
M73 P89 R3
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z15.8 I1.217 J0 P1  F42000
G1 X119.295 Y95.376
G1 Z15.4
G1 E.8 F1800
; FEATURE: Bridge
; LINE_WIDTH: 0.40051
; LAYER_HEIGHT: 0.4
M106 S255
G1 F952.499
M204 S6000
G1 X117.546 Y94.907 E.09488
G1 X115.805 Y94.907 E.09117
G1 X119.093 Y95.788 E.17829
G1 X119.093 Y96.254 E.02443
G1 X114.064 Y94.907 E.27268
G1 X112.324 Y94.907 E.09117
G1 X119.093 Y96.721 E.36706
G1 X119.093 Y97.187 E.02443
G1 X110.583 Y94.907 E.46145
G1 X108.843 Y94.907 E.09117
G1 X119.093 Y97.654 E.55584
G1 X119.093 Y98.12 E.02443
G1 X107.102 Y94.907 E.65023
G1 X105.361 Y94.907 E.09117
G1 X119.093 Y98.586 E.74461
G1 X119.093 Y99.053 E.02443
G1 X103.621 Y94.907 E.839
G1 X101.88 Y94.907 E.09117
G1 X119.093 Y99.519 E.93339
G1 X119.093 Y99.986 E.02443
G1 X100.139 Y94.907 E1.02778
G1 X98.399 Y94.907 E.09117
G1 X119.093 Y100.452 E1.12216
G1 X119.093 Y100.918 E.02443
G1 X96.658 Y94.907 E1.21655
G1 X94.917 Y94.907 E.09117
G1 X119.093 Y101.385 E1.31094
G1 X119.093 Y101.851 E.02443
G1 X93.177 Y94.907 E1.40533
G1 X91.436 Y94.907 E.09117
G1 X119.093 Y102.318 E1.49971
G1 X119.093 Y102.784 E.02443
M73 P90 R3
G1 X89.696 Y94.907 E1.5941
G1 X87.955 Y94.907 E.09117
G1 X119.093 Y103.25 E1.68849
G1 X119.093 Y103.717 E.02443
G1 X86.214 Y94.907 E1.78288
G1 X84.474 Y94.907 E.09117
G1 X119.093 Y104.183 E1.87726
G1 X119.093 Y104.65 E.02443
G1 X82.733 Y94.907 E1.97165
G1 X80.992 Y94.907 E.09117
G1 X119.007 Y105.093 E2.06137
G1 X117.266 Y105.093 E.09117
G1 X80.907 Y95.351 E1.97161
G1 X80.907 Y95.817 E.02443
M73 P90 R2
G1 X115.526 Y105.093 E1.87722
G1 X113.785 Y105.093 E.09117
G1 X80.907 Y96.283 E1.78283
G1 X80.907 Y96.75 E.02443
M73 P91 R2
G1 X112.044 Y105.093 E1.68845
G1 X110.304 Y105.093 E.09117
G1 X80.907 Y97.216 E1.59406
G1 X80.907 Y97.683 E.02443
G1 X108.563 Y105.093 E1.49967
G1 X106.822 Y105.093 E.09117
G1 X80.907 Y98.149 E1.40528
G1 X80.907 Y98.615 E.02443
G1 X105.082 Y105.093 E1.3109
G1 X103.341 Y105.093 E.09117
G1 X80.907 Y99.082 E1.21651
G1 X80.907 Y99.548 E.02443
G1 X101.6 Y105.093 E1.12212
G1 X99.86 Y105.093 E.09117
G1 X80.907 Y100.015 E1.02773
G1 X80.907 Y100.481 E.02443
G1 X98.119 Y105.093 E.93335
G1 X96.379 Y105.093 E.09117
G1 X80.907 Y100.947 E.83896
G1 X80.907 Y101.414 E.02443
G1 X94.638 Y105.093 E.74457
G1 X92.897 Y105.093 E.09117
G1 X80.907 Y101.88 E.65018
G1 X80.907 Y102.347 E.02443
G1 X91.157 Y105.093 E.55579
G1 X89.416 Y105.093 E.09117
M73 P92 R2
G1 X80.907 Y102.813 E.46141
G1 X80.907 Y103.279 E.02443
G1 X87.675 Y105.093 E.36702
G1 X85.935 Y105.093 E.09117
G1 X80.907 Y103.746 E.27263
G1 X80.907 Y104.212 E.02443
G1 X84.194 Y105.093 E.17825
G1 X82.453 Y105.093 E.09117
G1 X80.705 Y104.624 E.09484
M106 S163.2
; CHANGE_LAYER
; Z_HEIGHT: 15.6
; LAYER_HEIGHT: 0.200001
M106 S173.4
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z15.8 I-.026 J1.217 P1  F42000
G1 X119.443 Y105.443 Z15.8
G1 Z15.6
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z16 I1.217 J0 P1  F42000
G1 X118.574 Y105.3
G1 Z15.6
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4021
G1 F1670.472
M204 S6000
G1 X119.139 Y104.735 E.02389
G1 X119.139 Y104.227 E.01517
G1 X118.227 Y105.139 E.03856
G1 X117.719 Y105.139 E.01517
G1 X119.139 Y103.719 E.06001
G1 X119.139 Y103.211 E.01517
G1 X117.211 Y105.139 E.08147
G1 X116.703 Y105.139 E.01517
G1 X119.139 Y102.703 E.10292
G1 X119.139 Y102.195 E.01517
G1 X116.195 Y105.139 E.12438
G1 X115.687 Y105.139 E.01517
G1 X119.139 Y101.687 E.14583
G1 X119.139 Y101.179 E.01517
G1 X115.179 Y105.139 E.16729
G1 X114.671 Y105.139 E.01517
G1 X119.139 Y100.671 E.18874
G1 X119.139 Y100.163 E.01517
G1 X114.163 Y105.139 E.21019
G1 X113.655 Y105.139 E.01517
G1 X119.139 Y99.655 E.23165
G1 X119.139 Y99.147 E.01517
G1 X113.147 Y105.139 E.2531
G1 X112.639 Y105.139 E.01517
G1 X119.139 Y98.639 E.27456
G1 X119.139 Y98.131 E.01517
G1 X112.131 Y105.139 E.29601
G1 X111.623 Y105.139 E.01517
G1 X119.139 Y97.623 E.31747
G1 X119.139 Y97.115 E.01517
G1 X111.115 Y105.139 E.33892
G1 X110.607 Y105.139 E.01517
G1 X119.139 Y96.607 E.36038
G1 X119.139 Y96.099 E.01517
G1 X110.099 Y105.139 E.38183
G1 X109.591 Y105.139 E.01517
G1 X119.139 Y95.591 E.40328
G1 X119.139 Y95.083 E.01517
G1 X109.083 Y105.139 E.42474
G1 X108.575 Y105.139 E.01517
G1 X118.854 Y94.861 E.43415
G1 X118.346 Y94.861 E.01517
G1 X108.067 Y105.139 E.43415
G1 X107.559 Y105.139 E.01517
G1 X117.838 Y94.861 E.43415
G1 X117.33 Y94.861 E.01517
G1 X107.051 Y105.139 E.43415
G1 X106.544 Y105.139 E.01517
G1 X116.822 Y94.861 E.43415
G1 X116.314 Y94.861 E.01517
G1 X106.036 Y105.139 E.43415
G1 X105.528 Y105.139 E.01517
M73 P93 R2
G1 X115.807 Y94.861 E.43415
G1 X115.299 Y94.861 E.01517
G1 X105.02 Y105.139 E.43415
G1 X104.512 Y105.139 E.01517
G1 X114.791 Y94.861 E.43415
G1 X114.283 Y94.861 E.01517
G1 X104.004 Y105.139 E.43415
G1 X103.496 Y105.139 E.01517
G1 X113.775 Y94.861 E.43415
G1 X113.267 Y94.861 E.01517
G1 X102.988 Y105.139 E.43415
G1 X102.48 Y105.139 E.01517
G1 X112.759 Y94.861 E.43415
G1 X112.251 Y94.861 E.01517
G1 X101.972 Y105.139 E.43415
G1 X101.464 Y105.139 E.01517
G1 X111.743 Y94.861 E.43415
G1 X111.235 Y94.861 E.01517
G1 X100.956 Y105.139 E.43415
G1 X100.448 Y105.139 E.01517
G1 X110.727 Y94.861 E.43415
G1 X110.219 Y94.861 E.01517
G1 X99.94 Y105.139 E.43415
G1 X99.432 Y105.139 E.01517
G1 X109.711 Y94.861 E.43415
G1 X109.203 Y94.861 E.01517
G1 X98.924 Y105.139 E.43415
G1 X98.416 Y105.139 E.01517
G1 X108.695 Y94.861 E.43415
G1 X108.187 Y94.861 E.01517
G1 X97.908 Y105.139 E.43415
G1 X97.4 Y105.139 E.01517
G1 X107.679 Y94.861 E.43415
G1 X107.171 Y94.861 E.01517
G1 X96.892 Y105.139 E.43415
G1 X96.384 Y105.139 E.01517
G1 X106.663 Y94.861 E.43415
G1 X106.155 Y94.861 E.01517
G1 X95.876 Y105.139 E.43415
G1 X95.368 Y105.139 E.01517
G1 X105.647 Y94.861 E.43415
G1 X105.139 Y94.861 E.01517
G1 X94.861 Y105.139 E.43415
G1 X94.353 Y105.139 E.01517
G1 X104.631 Y94.861 E.43415
G1 X104.123 Y94.861 E.01517
G1 X93.845 Y105.139 E.43415
G1 X93.337 Y105.139 E.01517
G1 X103.616 Y94.861 E.43415
G1 X103.108 Y94.861 E.01517
G1 X92.829 Y105.139 E.43415
G1 X92.321 Y105.139 E.01517
G1 X102.6 Y94.861 E.43415
G1 X102.092 Y94.861 E.01517
G1 X91.813 Y105.139 E.43415
G1 X91.305 Y105.139 E.01517
G1 X101.584 Y94.861 E.43415
G1 X101.076 Y94.861 E.01517
G1 X90.797 Y105.139 E.43415
G1 X90.289 Y105.139 E.01517
G1 X100.568 Y94.861 E.43415
G1 X100.06 Y94.861 E.01517
G1 X89.781 Y105.139 E.43415
G1 X89.273 Y105.139 E.01517
M73 P93 R1
G1 X99.552 Y94.861 E.43415
G1 X99.044 Y94.861 E.01517
G1 X88.765 Y105.139 E.43415
G1 X88.257 Y105.139 E.01517
G1 X98.536 Y94.861 E.43415
G1 X98.028 Y94.861 E.01517
G1 X87.749 Y105.139 E.43415
G1 X87.241 Y105.139 E.01517
M73 P94 R1
G1 X97.52 Y94.861 E.43415
G1 X97.012 Y94.861 E.01517
G1 X86.733 Y105.139 E.43415
G1 X86.225 Y105.139 E.01517
G1 X96.504 Y94.861 E.43415
G1 X95.996 Y94.861 E.01517
G1 X85.717 Y105.139 E.43415
G1 X85.209 Y105.139 E.01517
G1 X95.488 Y94.861 E.43415
G1 X94.98 Y94.861 E.01517
G1 X84.701 Y105.139 E.43415
G1 X84.193 Y105.139 E.01517
G1 X94.472 Y94.861 E.43415
G1 X93.964 Y94.861 E.01517
G1 X83.685 Y105.139 E.43415
G1 X83.178 Y105.139 E.01517
G1 X93.456 Y94.861 E.43415
G1 X92.948 Y94.861 E.01517
G1 X82.67 Y105.139 E.43415
G1 X82.162 Y105.139 E.01517
G1 X92.44 Y94.861 E.43415
G1 X91.933 Y94.861 E.01517
G1 X81.654 Y105.139 E.43415
G1 X81.146 Y105.139 E.01517
G1 X91.425 Y94.861 E.43415
G1 X90.917 Y94.861 E.01517
G1 X80.861 Y104.917 E.42473
G1 X80.861 Y104.409 E.01517
G1 X90.409 Y94.861 E.40328
G1 X89.901 Y94.861 E.01517
G1 X80.861 Y103.901 E.38183
G1 X80.861 Y103.393 E.01517
G1 X89.393 Y94.861 E.36037
G1 X88.885 Y94.861 E.01517
G1 X80.861 Y102.885 E.33892
G1 X80.861 Y102.377 E.01517
G1 X88.377 Y94.861 E.31746
G1 X87.869 Y94.861 E.01517
G1 X80.861 Y101.869 E.29601
G1 X80.861 Y101.361 E.01517
G1 X87.361 Y94.861 E.27455
G1 X86.853 Y94.861 E.01517
G1 X80.861 Y100.853 E.2531
G1 X80.861 Y100.345 E.01517
G1 X86.345 Y94.861 E.23164
G1 X85.837 Y94.861 E.01517
G1 X80.861 Y99.837 E.21019
G1 X80.861 Y99.329 E.01517
G1 X85.329 Y94.861 E.18873
G1 X84.821 Y94.861 E.01517
G1 X80.861 Y98.821 E.16728
G1 X80.861 Y98.313 E.01517
G1 X84.313 Y94.861 E.14583
G1 X83.805 Y94.861 E.01517
G1 X80.861 Y97.805 E.12437
G1 X80.861 Y97.297 E.01517
G1 X83.297 Y94.861 E.10292
G1 X82.789 Y94.861 E.01517
G1 X80.861 Y96.789 E.08146
G1 X80.861 Y96.281 E.01517
G1 X82.281 Y94.861 E.06001
G1 X81.773 Y94.861 E.01517
G1 X80.861 Y95.773 E.03855
G1 X80.861 Y95.265 E.01517
G1 X81.426 Y94.7 E.02389
; CHANGE_LAYER
; Z_HEIGHT: 15.8
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z16 I-.331 J1.171 P1  F42000
G1 X119.443 Y105.443 Z16
G1 Z15.8
G1 E.8 F1800
; FEATURE: Inner wall
; LINE_WIDTH: 0.39999
G1 F1680.343
M204 S6000
G1 X80.557 Y105.443 E1.15454
G1 X80.557 Y94.557 E.32321
G1 X119.443 Y94.557 E1.15454
G1 X119.443 Y100 E.1616
G1 X119.443 Y105.383 E.15982
M204 S250
G1 X119.8 Y105.8 F42000
; FEATURE: Outer wall
G1 F1680.343
M204 S500
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
M73 P95 R1
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z16.2 I1.217 J0 P1  F42000
G1 X119.3 Y95.426
G1 Z15.8
G1 E.8 F1800
; FEATURE: Internal solid infill
; LINE_WIDTH: 0.4021
G1 F1670.472
M204 S6000
G1 X118.735 Y94.861 E.02389
G1 X118.227 Y94.861 E.01517
G1 X119.139 Y95.773 E.03856
G1 X119.139 Y96.281 E.01517
G1 X117.719 Y94.861 E.06001
G1 X117.211 Y94.861 E.01517
G1 X119.139 Y96.789 E.08147
G1 X119.139 Y97.297 E.01517
G1 X116.703 Y94.861 E.10292
G1 X116.195 Y94.861 E.01517
G1 X119.139 Y97.805 E.12438
G1 X119.139 Y98.313 E.01517
G1 X115.687 Y94.861 E.14583
G1 X115.179 Y94.861 E.01517
G1 X119.139 Y98.821 E.16729
G1 X119.139 Y99.329 E.01517
G1 X114.671 Y94.861 E.18874
G1 X114.163 Y94.861 E.01517
G1 X119.139 Y99.837 E.21019
G1 X119.139 Y100.345 E.01517
G1 X113.655 Y94.861 E.23165
G1 X113.147 Y94.861 E.01517
G1 X119.139 Y100.853 E.2531
G1 X119.139 Y101.361 E.01517
G1 X112.639 Y94.861 E.27456
G1 X112.131 Y94.861 E.01517
G1 X119.139 Y101.869 E.29601
G1 X119.139 Y102.377 E.01517
G1 X111.623 Y94.861 E.31747
G1 X111.115 Y94.861 E.01517
G1 X119.139 Y102.885 E.33892
G1 X119.139 Y103.393 E.01517
G1 X110.607 Y94.861 E.36038
G1 X110.099 Y94.861 E.01517
G1 X119.139 Y103.901 E.38183
G1 X119.139 Y104.409 E.01517
G1 X109.591 Y94.861 E.40328
G1 X109.083 Y94.861 E.01517
G1 X119.139 Y104.917 E.42474
G1 X119.139 Y105.139 E.00665
G1 X118.854 Y105.139 E.00852
G1 X108.575 Y94.861 E.43415
G1 X108.067 Y94.861 E.01517
G1 X118.346 Y105.139 E.43415
G1 X117.838 Y105.139 E.01517
G1 X107.559 Y94.861 E.43415
G1 X107.051 Y94.861 E.01517
G1 X117.33 Y105.139 E.43415
G1 X116.822 Y105.139 E.01517
G1 X106.544 Y94.861 E.43415
G1 X106.036 Y94.861 E.01517
G1 X116.314 Y105.139 E.43415
G1 X115.807 Y105.139 E.01517
G1 X105.528 Y94.861 E.43415
G1 X105.02 Y94.861 E.01517
G1 X115.299 Y105.139 E.43415
G1 X114.791 Y105.139 E.01517
G1 X104.512 Y94.861 E.43415
G1 X104.004 Y94.861 E.01517
G1 X114.283 Y105.139 E.43415
G1 X113.775 Y105.139 E.01517
G1 X103.496 Y94.861 E.43415
G1 X102.988 Y94.861 E.01517
G1 X113.267 Y105.139 E.43415
G1 X112.759 Y105.139 E.01517
G1 X102.48 Y94.861 E.43415
G1 X101.972 Y94.861 E.01517
G1 X112.251 Y105.139 E.43415
G1 X111.743 Y105.139 E.01517
G1 X101.464 Y94.861 E.43415
G1 X100.956 Y94.861 E.01517
G1 X111.235 Y105.139 E.43415
G1 X110.727 Y105.139 E.01517
G1 X100.448 Y94.861 E.43415
G1 X99.94 Y94.861 E.01517
G1 X110.219 Y105.139 E.43415
G1 X109.711 Y105.139 E.01517
G1 X99.432 Y94.861 E.43415
G1 X98.924 Y94.861 E.01517
G1 X109.203 Y105.139 E.43415
G1 X108.695 Y105.139 E.01517
G1 X98.416 Y94.861 E.43415
G1 X97.908 Y94.861 E.01517
G1 X108.187 Y105.139 E.43415
G1 X107.679 Y105.139 E.01517
M73 P96 R1
G1 X97.4 Y94.861 E.43415
G1 X96.892 Y94.861 E.01517
G1 X107.171 Y105.139 E.43415
G1 X106.663 Y105.139 E.01517
G1 X96.384 Y94.861 E.43415
G1 X95.876 Y94.861 E.01517
G1 X106.155 Y105.139 E.43415
G1 X105.647 Y105.139 E.01517
G1 X95.368 Y94.861 E.43415
G1 X94.861 Y94.861 E.01517
G1 X105.139 Y105.139 E.43415
G1 X104.631 Y105.139 E.01517
G1 X94.353 Y94.861 E.43415
G1 X93.845 Y94.861 E.01517
G1 X104.123 Y105.139 E.43415
G1 X103.616 Y105.139 E.01517
G1 X93.337 Y94.861 E.43415
G1 X92.829 Y94.861 E.01517
G1 X103.108 Y105.139 E.43415
G1 X102.6 Y105.139 E.01517
G1 X92.321 Y94.861 E.43415
G1 X91.813 Y94.861 E.01517
G1 X102.092 Y105.139 E.43415
G1 X101.584 Y105.139 E.01517
G1 X91.305 Y94.861 E.43415
G1 X90.797 Y94.861 E.01517
G1 X101.076 Y105.139 E.43415
G1 X100.568 Y105.139 E.01517
G1 X90.289 Y94.861 E.43415
G1 X89.781 Y94.861 E.01517
G1 X100.06 Y105.139 E.43415
G1 X99.552 Y105.139 E.01517
G1 X89.273 Y94.861 E.43415
G1 X88.765 Y94.861 E.01517
G1 X99.044 Y105.139 E.43415
G1 X98.536 Y105.139 E.01517
G1 X88.257 Y94.861 E.43415
G1 X87.749 Y94.861 E.01517
G1 X98.028 Y105.139 E.43415
G1 X97.52 Y105.139 E.01517
G1 X87.241 Y94.861 E.43415
G1 X86.733 Y94.861 E.01517
G1 X97.012 Y105.139 E.43415
G1 X96.504 Y105.139 E.01517
G1 X86.225 Y94.861 E.43415
G1 X85.717 Y94.861 E.01517
G1 X95.996 Y105.139 E.43415
G1 X95.488 Y105.139 E.01517
G1 X85.209 Y94.861 E.43415
G1 X84.701 Y94.861 E.01517
G1 X94.98 Y105.139 E.43415
G1 X94.472 Y105.139 E.01517
G1 X84.193 Y94.861 E.43415
G1 X83.685 Y94.861 E.01517
G1 X93.964 Y105.139 E.43415
G1 X93.456 Y105.139 E.01517
G1 X83.178 Y94.861 E.43415
G1 X82.67 Y94.861 E.01517
G1 X92.948 Y105.139 E.43415
G1 X92.44 Y105.139 E.01517
G1 X82.162 Y94.861 E.43415
G1 X81.654 Y94.861 E.01517
G1 X91.933 Y105.139 E.43415
G1 X91.425 Y105.139 E.01517
G1 X81.146 Y94.861 E.43415
G1 X80.861 Y94.861 E.00852
G1 X80.861 Y95.083 E.00666
G1 X90.917 Y105.139 E.42473
G1 X90.409 Y105.139 E.01517
M73 P96 R0
G1 X80.861 Y95.591 E.40328
G1 X80.861 Y96.099 E.01517
G1 X89.901 Y105.139 E.38183
G1 X89.393 Y105.139 E.01517
M73 P97 R0
G1 X80.861 Y96.607 E.36037
G1 X80.861 Y97.115 E.01517
G1 X88.885 Y105.139 E.33892
G1 X88.377 Y105.139 E.01517
G1 X80.861 Y97.623 E.31746
G1 X80.861 Y98.131 E.01517
G1 X87.869 Y105.139 E.29601
G1 X87.361 Y105.139 E.01517
G1 X80.861 Y98.639 E.27455
G1 X80.861 Y99.147 E.01517
G1 X86.853 Y105.139 E.2531
G1 X86.345 Y105.139 E.01517
G1 X80.861 Y99.655 E.23164
G1 X80.861 Y100.163 E.01517
G1 X85.837 Y105.139 E.21019
G1 X85.329 Y105.139 E.01517
G1 X80.861 Y100.671 E.18873
G1 X80.861 Y101.179 E.01517
G1 X84.821 Y105.139 E.16728
G1 X84.313 Y105.139 E.01517
G1 X80.861 Y101.687 E.14583
G1 X80.861 Y102.195 E.01517
G1 X83.805 Y105.139 E.12437
G1 X83.297 Y105.139 E.01517
G1 X80.861 Y102.703 E.10292
G1 X80.861 Y103.211 E.01517
G1 X82.789 Y105.139 E.08146
G1 X82.281 Y105.139 E.01517
G1 X80.861 Y103.719 E.06001
G1 X80.861 Y104.227 E.01517
G1 X81.773 Y105.139 E.03855
G1 X81.265 Y105.139 E.01517
G1 X80.7 Y104.574 E.02389
; CHANGE_LAYER
; Z_HEIGHT: 16
; LAYER_HEIGHT: 0.2
; OBJECT_ID: 15
G1 E-.8 F1800
M204 S500
G17
G3 Z16.2 I-.038 J1.216 P1  F42000
G1 X119.8 Y105.8 Z16.2
G1 Z16
G1 E.8 F1800
; FEATURE: Outer wall
; LINE_WIDTH: 0.39999
G1 F1680.343
G1 X80.2 Y105.8 E1.17574
G1 X80.2 Y94.2 E.34441
G1 X119.8 Y94.2 E1.17574
G1 X119.8 Y100 E.17221
G1 X119.8 Y105.74 E.17042
G1 E-.8 F1800
G17
G3 Z16.4 I1.217 J0 P1  F42000
G1 X118.932 Y105.657
G1 Z16
G1 E.8 F1800
; FEATURE: Top surface
; LINE_WIDTH: 0.40142
G1 F1673.64
G1 X119.497 Y105.093 E.02378
G1 X119.497 Y104.586 E.01511
G1 X118.586 Y105.497 E.03838
G1 X118.079 Y105.497 E.01511
G1 X119.497 Y104.079 E.05976
G1 X119.497 Y103.572 E.01511
G1 X117.572 Y105.497 E.08113
G1 X117.065 Y105.497 E.01511
G1 X119.497 Y103.065 E.1025
G1 X119.497 Y102.558 E.01511
G1 X116.558 Y105.497 E.12388
G1 X116.051 Y105.497 E.01511
G1 X119.497 Y102.051 E.14525
G1 X119.497 Y101.544 E.01511
G1 X115.544 Y105.497 E.16662
G1 X115.037 Y105.497 E.01511
G1 X119.497 Y101.037 E.188
G1 X119.497 Y100.53 E.01511
G1 X114.53 Y105.497 E.20937
G1 X114.023 Y105.497 E.01511
G1 X119.497 Y100.023 E.23074
G1 X119.497 Y99.516 E.01511
G1 X113.516 Y105.497 E.25212
G1 X113.009 Y105.497 E.01511
G1 X119.497 Y99.009 E.27349
G1 X119.497 Y98.502 E.01511
G1 X112.502 Y105.497 E.29486
G1 X111.995 Y105.497 E.01511
G1 X119.497 Y97.995 E.31624
G1 X119.497 Y97.488 E.01511
G1 X111.488 Y105.497 E.33761
G1 X110.981 Y105.497 E.01511
G1 X119.497 Y96.981 E.35898
G1 X119.497 Y96.474 E.01511
G1 X110.474 Y105.497 E.38036
G1 X109.967 Y105.497 E.01511
G1 X119.497 Y95.967 E.40173
G1 X119.497 Y95.46 E.01511
G1 X109.46 Y105.497 E.4231
G1 X108.953 Y105.497 E.01511
G1 X119.497 Y94.953 E.44448
G1 X119.497 Y94.503 E.0134
G1 X119.439 Y94.503 E.00171
G1 X108.446 Y105.497 E.46343
G1 X107.939 Y105.497 E.01511
G1 X118.932 Y94.503 E.46343
G1 X118.425 Y94.503 E.01511
G1 X107.432 Y105.497 E.46343
G1 X106.925 Y105.497 E.01511
G1 X117.918 Y94.503 E.46343
G1 X117.411 Y94.503 E.01511
G1 X106.418 Y105.497 E.46343
G1 X105.911 Y105.497 E.01511
M73 P98 R0
G1 X116.904 Y94.503 E.46343
G1 X116.397 Y94.503 E.01511
G1 X105.404 Y105.497 E.46343
G1 X104.897 Y105.497 E.01511
G1 X115.89 Y94.503 E.46343
G1 X115.383 Y94.503 E.01511
G1 X104.39 Y105.497 E.46343
G1 X103.883 Y105.497 E.01511
G1 X114.876 Y94.503 E.46343
G1 X114.369 Y94.503 E.01511
G1 X103.376 Y105.497 E.46343
G1 X102.869 Y105.497 E.01511
G1 X113.862 Y94.503 E.46343
G1 X113.355 Y94.503 E.01511
G1 X102.362 Y105.497 E.46343
G1 X101.855 Y105.497 E.01511
G1 X112.848 Y94.503 E.46343
G1 X112.341 Y94.503 E.01511
G1 X101.348 Y105.497 E.46343
G1 X100.841 Y105.497 E.01511
G1 X111.834 Y94.503 E.46343
G1 X111.327 Y94.503 E.01511
G1 X100.334 Y105.497 E.46343
G1 X99.827 Y105.497 E.01511
G1 X110.82 Y94.503 E.46343
G1 X110.313 Y94.503 E.01511
G1 X99.32 Y105.497 E.46343
G1 X98.813 Y105.497 E.01511
G1 X109.806 Y94.503 E.46343
G1 X109.299 Y94.503 E.01511
G1 X98.306 Y105.497 E.46343
G1 X97.799 Y105.497 E.01511
G1 X108.792 Y94.503 E.46343
G1 X108.285 Y94.503 E.01511
G1 X97.292 Y105.497 E.46343
G1 X96.785 Y105.497 E.01511
G1 X107.778 Y94.503 E.46343
G1 X107.271 Y94.503 E.01511
G1 X96.278 Y105.497 E.46343
G1 X95.771 Y105.497 E.01511
G1 X106.764 Y94.503 E.46343
G1 X106.257 Y94.503 E.01511
G1 X95.264 Y105.497 E.46343
G1 X94.757 Y105.497 E.01511
G1 X105.75 Y94.503 E.46343
G1 X105.243 Y94.503 E.01511
G1 X94.25 Y105.497 E.46343
G1 X93.743 Y105.497 E.01511
G1 X104.736 Y94.503 E.46343
G1 X104.229 Y94.503 E.01511
G1 X93.236 Y105.497 E.46343
G1 X92.729 Y105.497 E.01511
G1 X103.722 Y94.503 E.46343
G1 X103.215 Y94.503 E.01511
G1 X92.222 Y105.497 E.46343
G1 X91.715 Y105.497 E.01511
G1 X102.708 Y94.503 E.46343
G1 X102.201 Y94.503 E.01511
G1 X91.208 Y105.497 E.46343
G1 X90.701 Y105.497 E.01511
G1 X101.694 Y94.503 E.46343
G1 X101.187 Y94.503 E.01511
G1 X90.194 Y105.497 E.46343
G1 X89.687 Y105.497 E.01511
G1 X100.68 Y94.503 E.46343
M73 P99 R0
G1 X100.173 Y94.503 E.01511
G1 X89.18 Y105.497 E.46343
G1 X88.673 Y105.497 E.01511
G1 X99.666 Y94.504 E.46343
G1 X99.159 Y94.504 E.01511
G1 X88.166 Y105.497 E.46343
G1 X87.659 Y105.497 E.01511
G1 X98.652 Y94.504 E.46343
G1 X98.145 Y94.504 E.01511
G1 X87.152 Y105.497 E.46343
G1 X86.645 Y105.497 E.01511
G1 X97.638 Y94.504 E.46343
G1 X97.131 Y94.504 E.01511
G1 X86.138 Y105.497 E.46343
G1 X85.631 Y105.497 E.01511
G1 X96.624 Y94.504 E.46343
G1 X96.117 Y94.504 E.01511
G1 X85.124 Y105.497 E.46343
G1 X84.617 Y105.497 E.01511
G1 X95.61 Y94.504 E.46343
G1 X95.103 Y94.504 E.01511
G1 X84.11 Y105.497 E.46343
G1 X83.603 Y105.497 E.01511
G1 X94.596 Y94.504 E.46343
G1 X94.089 Y94.504 E.01511
G1 X83.096 Y105.497 E.46343
G1 X82.589 Y105.497 E.01511
G1 X93.582 Y94.504 E.46343
G1 X93.075 Y94.504 E.01511
G1 X82.082 Y105.497 E.46343
G1 X81.575 Y105.497 E.01511
G1 X92.568 Y94.504 E.46343
G1 X92.061 Y94.504 E.01511
G1 X81.068 Y105.497 E.46343
G1 X80.561 Y105.497 E.01511
G1 X91.554 Y94.503 E.46343
G1 X91.047 Y94.503 E.01511
G1 X80.504 Y105.047 E.4445
G1 X80.504 Y104.54 E.01511
G1 X90.54 Y94.503 E.42312
G1 X90.033 Y94.503 E.01511
G1 X80.504 Y104.033 E.40175
G1 X80.504 Y103.526 E.01511
G1 X89.526 Y94.503 E.38038
G1 X89.019 Y94.503 E.01511
G1 X80.504 Y103.019 E.359
G1 X80.504 Y102.512 E.01511
G1 X88.512 Y94.503 E.33763
G1 X88.005 Y94.503 E.01511
G1 X80.504 Y102.005 E.31626
G1 X80.504 Y101.498 E.01511
G1 X87.498 Y94.503 E.29488
G1 X86.991 Y94.503 E.01511
G1 X80.504 Y100.991 E.27351
G1 X80.504 Y100.484 E.01511
G1 X86.484 Y94.503 E.25214
G1 X85.977 Y94.503 E.01511
G1 X80.504 Y99.977 E.23076
G1 X80.504 Y99.47 E.01511
G1 X85.47 Y94.503 E.20939
G1 X84.963 Y94.503 E.01511
G1 X80.504 Y98.963 E.18802
G1 X80.504 Y98.456 E.01511
G1 X84.456 Y94.503 E.16664
G1 X83.949 Y94.503 E.01511
G1 X80.504 Y97.949 E.14527
G1 X80.504 Y97.442 E.01511
G1 X83.442 Y94.503 E.1239
G1 X82.935 Y94.503 E.01511
G1 X80.504 Y96.935 E.10252
G1 X80.504 Y96.428 E.01511
G1 X82.428 Y94.503 E.08115
G1 X81.921 Y94.503 E.01511
G1 X80.504 Y95.921 E.05978
G1 X80.504 Y95.414 E.01511
G1 X81.414 Y94.503 E.0384
G1 X80.907 Y94.503 E.01511
G1 X80.343 Y95.068 E.0238
; close powerlost recovery
M1003 S0
G1 E-.8 F1800
G17
G3 Z16.4 I1.217 J0 P1  F42000
M106 S0
M981 S0 P20000 ; close spaghetti detector
; FEATURE: Custom
; MACHINE_END_GCODE_START
M104 S0 ; turn off temperature
G28 X0  ; home X axis
M84     ; disable motors
M73 P100 R0
; EXECUTABLE_BLOCK_END

